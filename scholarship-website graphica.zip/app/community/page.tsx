"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  BookOpen,
  MessageSquare,
  Users,
  Star,
  ThumbsUp,
  Reply,
  Search,
  Filter,
  Plus,
  Award,
  Clock,
  Eye,
  HelpCircle,
  Lightbulb,
  Share2,
  Pin,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface Post {
  id: string
  type: "question" | "experience" | "tip" | "review"
  title: string
  content: string
  author: {
    name: string
    avatar: string
    year: string
    branch: string
    reputation: number
  }
  createdAt: Date
  likes: number
  replies: number
  views: number
  tags: string[]
  isAnswered?: boolean
  isPinned?: boolean
  bestAnswer?: boolean
}

interface PostReply {
  id: string
  postId: string
  content: string
  author: {
    name: string
    avatar: string
    year: string
    branch: string
    reputation: number
  }
  createdAt: Date
  likes: number
  isBestAnswer?: boolean
}

export default function CommunityPage() {
  const [activeTab, setActiveTab] = useState("discussions")
  const [selectedPost, setSelectedPost] = useState<string | null>(null)

  const [posts, setPosts] = useState<Post[]>([
    {
      id: "1",
      type: "experience",
      title: "My Experience with Google Summer of Code 2024",
      content:
        "I recently completed GSoC 2024 and wanted to share my journey with fellow students. The application process was challenging but rewarding...",
      author: {
        name: "Priya Sharma",
        avatar: "/avatars/priya.jpg",
        year: "4th Year",
        branch: "Computer Science",
        reputation: 1250,
      },
      createdAt: new Date("2025-01-10"),
      likes: 45,
      replies: 12,
      views: 234,
      tags: ["GSoC", "Open Source", "Experience"],
      isPinned: true,
    },
    {
      id: "2",
      type: "question",
      title: "How to prepare for Microsoft internship interviews?",
      content:
        "I have an upcoming interview with Microsoft for their summer internship program. Can anyone share their experience and preparation tips?",
      author: {
        name: "Rahul Kumar",
        avatar: "/avatars/rahul.jpg",
        year: "3rd Year",
        branch: "Computer Science",
        reputation: 680,
      },
      createdAt: new Date("2025-01-12"),
      likes: 23,
      replies: 8,
      views: 156,
      tags: ["Microsoft", "Interview", "Internship"],
      isAnswered: true,
    },
    {
      id: "3",
      type: "tip",
      title: "5 Essential Tips for Scholarship Applications",
      content:
        "After successfully getting 3 scholarships, here are my top tips that helped me stand out from other applicants...",
      author: {
        name: "Ananya Patel",
        avatar: "/avatars/ananya.jpg",
        year: "4th Year",
        branch: "Mechanical Engineering",
        reputation: 890,
      },
      createdAt: new Date("2025-01-11"),
      likes: 67,
      replies: 15,
      views: 312,
      tags: ["Scholarships", "Tips", "Application"],
    },
    {
      id: "4",
      type: "review",
      title: "Review: Amazon Web Services Scholarship Program",
      content:
        "I recently completed the AWS scholarship program. Here's my detailed review of the application process, coursework, and overall experience...",
      author: {
        name: "Vikram Singh",
        avatar: "/avatars/vikram.jpg",
        year: "3rd Year",
        branch: "Information Technology",
        reputation: 540,
      },
      createdAt: new Date("2025-01-09"),
      likes: 34,
      replies: 6,
      views: 189,
      tags: ["AWS", "Scholarship", "Review"],
    },
  ])

  const [postReplies, setPostReplies] = useState<PostReply[]>([
    {
      id: "1",
      postId: "2",
      content:
        "I interviewed with Microsoft last year. Focus on data structures, algorithms, and system design. Practice on LeetCode and be ready to explain your thought process clearly.",
      author: {
        name: "Sneha Reddy",
        avatar: "/avatars/sneha.jpg",
        year: "4th Year",
        branch: "Computer Science",
        reputation: 920,
      },
      createdAt: new Date("2025-01-12"),
      likes: 15,
      isBestAnswer: true,
    },
  ])

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case "question":
        return <HelpCircle className="w-4 h-4" />
      case "experience":
        return <Star className="w-4 h-4" />
      case "tip":
        return <Lightbulb className="w-4 h-4" />
      case "review":
        return <MessageSquare className="w-4 h-4" />
      default:
        return <MessageSquare className="w-4 h-4" />
    }
  }

  const getPostTypeColor = (type: string) => {
    switch (type) {
      case "question":
        return "text-blue-600 bg-blue-100 dark:bg-blue-900/20"
      case "experience":
        return "text-green-600 bg-green-100 dark:bg-green-900/20"
      case "tip":
        return "text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20"
      case "review":
        return "text-purple-600 bg-purple-100 dark:bg-purple-900/20"
      default:
        return "text-gray-600 bg-gray-100 dark:bg-gray-900/20"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/20">
      {/* Navigation */}
      <nav className="glassmorphism bg-card/60 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">EduOpportunity</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/dashboard" className="text-muted-foreground hover:text-primary transition-colors">
                Dashboard
              </Link>
              <Link href="/community" className="text-foreground hover:text-primary transition-colors font-medium">
                Community
              </Link>
            </div>

            <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg pulse-glow">
              <Link href="/dashboard">Dashboard</Link>
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Community Hub</h1>
          <p className="text-muted-foreground">
            Connect with peers, share experiences, and get advice from seniors and experts.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar - Community Stats & Quick Actions */}
          <div className="lg:col-span-1 space-y-6">
            {/* Community Stats */}
            <Card className="glassmorphism bg-card/60 border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Users className="w-5 h-5 mr-2 text-primary" />
                  Community Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Total Members</span>
                  <span className="font-medium">12,450</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Active Today</span>
                  <span className="font-medium text-green-600">1,234</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Total Posts</span>
                  <span className="font-medium">8,967</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Questions Answered</span>
                  <span className="font-medium text-blue-600">6,543</span>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="glassmorphism bg-card/60">
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-primary hover:bg-primary/90">
                  <Plus className="w-4 h-4 mr-2" />
                  Ask Question
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Experience
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <Lightbulb className="w-4 h-4 mr-2" />
                  Share Tip
                </Button>
              </CardContent>
            </Card>

            {/* Top Contributors */}
            <Card className="glassmorphism bg-card/60">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Award className="w-5 h-5 mr-2 text-primary" />
                  Top Contributors
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src="/avatars/priya.jpg" />
                    <AvatarFallback>PS</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Priya Sharma</p>
                    <p className="text-xs text-muted-foreground">1,250 reputation</p>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    #1
                  </Badge>
                </div>
                <div className="flex items-center space-x-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src="/avatars/sneha.jpg" />
                    <AvatarFallback>SR</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Sneha Reddy</p>
                    <p className="text-xs text-muted-foreground">920 reputation</p>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    #2
                  </Badge>
                </div>
                <div className="flex items-center space-x-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src="/avatars/ananya.jpg" />
                    <AvatarFallback>AP</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Ananya Patel</p>
                    <p className="text-xs text-muted-foreground">890 reputation</p>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    #3
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <div className="flex items-center justify-between">
                <TabsList className="glassmorphism bg-card/60">
                  <TabsTrigger value="discussions" className="flex items-center space-x-2">
                    <MessageSquare className="w-4 h-4" />
                    <span>Discussions</span>
                  </TabsTrigger>
                  <TabsTrigger value="questions" className="flex items-center space-x-2">
                    <HelpCircle className="w-4 h-4" />
                    <span>Q&A</span>
                  </TabsTrigger>
                  <TabsTrigger value="experiences" className="flex items-center space-x-2">
                    <Star className="w-4 h-4" />
                    <span>Experiences</span>
                  </TabsTrigger>
                  <TabsTrigger value="tips" className="flex items-center space-x-2">
                    <Lightbulb className="w-4 h-4" />
                    <span>Tips & Tricks</span>
                  </TabsTrigger>
                </TabsList>

                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" size="sm">
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                </div>
              </div>

              {/* All Discussions Tab */}
              <TabsContent value="discussions" className="space-y-4">
                {posts.map((post) => (
                  <Card
                    key={post.id}
                    className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-[1.01]"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={post.author.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {post.author.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <Badge className={getPostTypeColor(post.type)}>
                              <div className="flex items-center space-x-1">
                                {getPostTypeIcon(post.type)}
                                <span className="capitalize">{post.type}</span>
                              </div>
                            </Badge>
                            {post.isPinned && (
                              <Badge variant="outline" className="text-orange-600 border-orange-600">
                                <Pin className="w-3 h-3 mr-1" />
                                Pinned
                              </Badge>
                            )}
                            {post.isAnswered && (
                              <Badge variant="outline" className="text-green-600 border-green-600">
                                ✓ Answered
                              </Badge>
                            )}
                          </div>
                          <h3 className="text-lg font-semibold text-foreground mb-2 hover:text-primary cursor-pointer">
                            {post.title}
                          </h3>
                          <p className="text-muted-foreground mb-3 line-clamp-2">{post.content}</p>
                          <div className="flex flex-wrap gap-2 mb-3">
                            {post.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                              <div className="flex items-center space-x-1">
                                <span className="font-medium">{post.author.name}</span>
                                <span>•</span>
                                <span>
                                  {post.author.year} {post.author.branch}
                                </span>
                                <span>•</span>
                                <span>{post.author.reputation} rep</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Clock className="w-4 h-4" />
                                <span>{post.createdAt.toLocaleDateString()}</span>
                              </div>
                            </div>
                            <div className="flex items-center space-x-4 text-sm">
                              <div className="flex items-center space-x-1">
                                <ThumbsUp className="w-4 h-4" />
                                <span>{post.likes}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Reply className="w-4 h-4" />
                                <span>{post.replies}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Eye className="w-4 h-4" />
                                <span>{post.views}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Questions Tab */}
              <TabsContent value="questions" className="space-y-4">
                {posts
                  .filter((post) => post.type === "question")
                  .map((post) => (
                    <Card
                      key={post.id}
                      className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-[1.01]"
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={post.author.avatar || "/placeholder.svg"} />
                            <AvatarFallback>
                              {post.author.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <Badge className={getPostTypeColor(post.type)}>
                                <div className="flex items-center space-x-1">
                                  {getPostTypeIcon(post.type)}
                                  <span>Question</span>
                                </div>
                              </Badge>
                              {post.isAnswered && (
                                <Badge variant="outline" className="text-green-600 border-green-600">
                                  ✓ Answered
                                </Badge>
                              )}
                            </div>
                            <h3 className="text-lg font-semibold text-foreground mb-2 hover:text-primary cursor-pointer">
                              {post.title}
                            </h3>
                            <p className="text-muted-foreground mb-3">{post.content}</p>
                            <div className="flex flex-wrap gap-2 mb-3">
                              {post.tags.map((tag, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                <span className="font-medium">{post.author.name}</span>
                                <span>{post.createdAt.toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center space-x-4 text-sm">
                                <div className="flex items-center space-x-1">
                                  <ThumbsUp className="w-4 h-4" />
                                  <span>{post.likes}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Reply className="w-4 h-4" />
                                  <span>{post.replies} answers</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </TabsContent>

              {/* Experiences Tab */}
              <TabsContent value="experiences" className="space-y-4">
                {posts
                  .filter((post) => post.type === "experience")
                  .map((post) => (
                    <Card
                      key={post.id}
                      className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-[1.01]"
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={post.author.avatar || "/placeholder.svg"} />
                            <AvatarFallback>
                              {post.author.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <Badge className={getPostTypeColor(post.type)}>
                                <div className="flex items-center space-x-1">
                                  {getPostTypeIcon(post.type)}
                                  <span>Experience</span>
                                </div>
                              </Badge>
                              {post.isPinned && (
                                <Badge variant="outline" className="text-orange-600 border-orange-600">
                                  <Pin className="w-3 h-3 mr-1" />
                                  Pinned
                                </Badge>
                              )}
                            </div>
                            <h3 className="text-lg font-semibold text-foreground mb-2 hover:text-primary cursor-pointer">
                              {post.title}
                            </h3>
                            <p className="text-muted-foreground mb-3">{post.content}</p>
                            <div className="flex flex-wrap gap-2 mb-3">
                              {post.tags.map((tag, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                <span className="font-medium">{post.author.name}</span>
                                <span>{post.createdAt.toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center space-x-4 text-sm">
                                <div className="flex items-center space-x-1">
                                  <ThumbsUp className="w-4 h-4" />
                                  <span>{post.likes}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Reply className="w-4 h-4" />
                                  <span>{post.replies}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Eye className="w-4 h-4" />
                                  <span>{post.views}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </TabsContent>

              {/* Tips Tab */}
              <TabsContent value="tips" className="space-y-4">
                {posts
                  .filter((post) => post.type === "tip")
                  .map((post) => (
                    <Card
                      key={post.id}
                      className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-[1.01]"
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={post.author.avatar || "/placeholder.svg"} />
                            <AvatarFallback>
                              {post.author.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <Badge className={getPostTypeColor(post.type)}>
                                <div className="flex items-center space-x-1">
                                  {getPostTypeIcon(post.type)}
                                  <span>Tip</span>
                                </div>
                              </Badge>
                            </div>
                            <h3 className="text-lg font-semibold text-foreground mb-2 hover:text-primary cursor-pointer">
                              {post.title}
                            </h3>
                            <p className="text-muted-foreground mb-3">{post.content}</p>
                            <div className="flex flex-wrap gap-2 mb-3">
                              {post.tags.map((tag, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                <span className="font-medium">{post.author.name}</span>
                                <span>{post.createdAt.toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center space-x-4 text-sm">
                                <div className="flex items-center space-x-1">
                                  <ThumbsUp className="w-4 h-4" />
                                  <span>{post.likes}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Reply className="w-4 h-4" />
                                  <span>{post.replies}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
