"use client"

import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Float, Text3D, Environment, Html, Ring } from "@react-three/drei"
import { Suspense, useRef, useMemo } from "react"
import type { Mesh, Group } from "three"

function AnimatedGeometry({
  position,
  geometry,
  color,
  speed = 1,
}: {
  position: [number, number, number]
  geometry: "sphere" | "torus" | "icosahedron" | "octahedron"
  color: string
  speed?: number
}) {
  const meshRef = useRef<Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += 0.01 * speed
      meshRef.current.rotation.y += 0.01 * speed
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * speed) * 0.3
    }
  })

  const GeometryComponent = () => {
    switch (geometry) {
      case "sphere":
        return <sphereGeometry args={[0.3, 16, 16]} />
      case "torus":
        return <torusGeometry args={[0.3, 0.1, 8, 16]} />
      case "icosahedron":
        return <icosahedronGeometry args={[0.3, 0]} />
      case "octahedron":
        return <octahedronGeometry args={[0.3, 0]} />
      default:
        return <sphereGeometry args={[0.3, 16, 16]} />
    }
  }

  return (
    <mesh ref={meshRef} position={position}>
      <GeometryComponent />
      <meshStandardMaterial color={color} transparent opacity={0.7} emissive={color} emissiveIntensity={0.2} />
    </mesh>
  )
}

function FloatingParticles() {
  const particlesRef = useRef<Group>(null)

  const particles = useMemo(() => {
    const temp = []
    for (let i = 0; i < 50; i++) {
      temp.push({
        position: [(Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20] as [
          number,
          number,
          number,
        ],
        scale: Math.random() * 0.1 + 0.05,
        speed: Math.random() * 0.02 + 0.01,
      })
    }
    return temp
  }, [])

  useFrame((state) => {
    if (particlesRef.current) {
      particlesRef.current.rotation.y += 0.001
      particlesRef.current.children.forEach((child, i) => {
        child.position.y += Math.sin(state.clock.elapsedTime * particles[i].speed) * 0.01
      })
    }
  })

  return (
    <group ref={particlesRef}>
      {particles.map((particle, i) => (
        <mesh key={i} position={particle.position} scale={particle.scale}>
          <sphereGeometry args={[1, 8, 8]} />
          <meshBasicMaterial color="#8b5cf6" transparent opacity={0.3} />
        </mesh>
      ))}
    </group>
  )
}

function AnimatedRings() {
  const ringsRef = useRef<Group>(null)

  useFrame((state) => {
    if (ringsRef.current) {
      ringsRef.current.rotation.x += 0.005
      ringsRef.current.rotation.z += 0.003
    }
  })

  return (
    <group ref={ringsRef}>
      <Ring args={[3, 3.2, 32]} position={[0, 0, -5]} rotation={[Math.PI / 2, 0, 0]}>
        <meshBasicMaterial color="#8b5cf6" transparent opacity={0.2} />
      </Ring>
      <Ring args={[4, 4.3, 32]} position={[0, 0, -6]} rotation={[Math.PI / 3, 0, 0]}>
        <meshBasicMaterial color="#06b6d4" transparent opacity={0.15} />
      </Ring>
      <Ring args={[5, 5.4, 32]} position={[0, 0, -7]} rotation={[Math.PI / 4, 0, 0]}>
        <meshBasicMaterial color="#f97316" transparent opacity={0.1} />
      </Ring>
    </group>
  )
}

function FloatingBook({ position }: { position: [number, number, number] }) {
  const meshRef = useRef<Mesh>(null)

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
      <group position={position}>
        <mesh ref={meshRef}>
          <boxGeometry args={[0.8, 1.2, 0.1]} />
          <meshStandardMaterial color="#8b5cf6" emissive="#8b5cf6" emissiveIntensity={0.1} />
        </mesh>
        <mesh>
          <boxGeometry args={[0.82, 1.22, 0.12]} />
          <meshBasicMaterial color="#a855f7" transparent opacity={0.3} wireframe />
        </mesh>
        <Html distanceFactor={10} position={[0, 0, 0.1]}>
          <div className="text-white text-xs font-bold px-3 py-2 bg-purple-900 border-2 border-purple-600 rounded-md shadow-xl backdrop-blur-none">
            📚 Study
          </div>
        </Html>
      </group>
    </Float>
  )
}

function FloatingLaptop({ position }: { position: [number, number, number] }) {
  return (
    <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.8}>
      <group position={position}>
        <mesh>
          <boxGeometry args={[1.5, 0.1, 1]} />
          <meshStandardMaterial color="#1f2937" emissive="#1f2937" emissiveIntensity={0.1} />
        </mesh>
        <mesh position={[0, 0.05, -0.3]}>
          <boxGeometry args={[1.5, 1, 0.1]} />
          <meshStandardMaterial color="#374151" emissive="#374151" emissiveIntensity={0.1} />
        </mesh>
        <mesh position={[0, 0.06, -0.29]}>
          <planeGeometry args={[1.3, 0.8]} />
          <meshBasicMaterial color="#06b6d4" transparent opacity={0.6} />
        </mesh>
        <Html distanceFactor={10} position={[0, 0.5, 0]}>
          <div className="text-white text-xs font-bold px-3 py-2 bg-gray-900 border-2 border-gray-600 rounded-md shadow-xl backdrop-blur-none">
            💻 Code
          </div>
        </Html>
      </group>
    </Float>
  )
}

function FloatingGraduationCap({ position }: { position: [number, number, number] }) {
  return (
    <Float speed={2.5} rotationIntensity={0.4} floatIntensity={0.6}>
      <group position={position}>
        <mesh>
          <cylinderGeometry args={[0.8, 0.8, 0.1, 8]} />
          <meshStandardMaterial color="#f97316" emissive="#f97316" emissiveIntensity={0.1} />
        </mesh>
        <mesh position={[0, 0.1, 0]}>
          <boxGeometry args={[0.1, 0.5, 0.1]} />
          <meshStandardMaterial color="#1f2937" />
        </mesh>
        <mesh position={[0.3, -0.2, 0]}>
          <sphereGeometry args={[0.05, 8, 8]} />
          <meshStandardMaterial color="#fbbf24" />
        </mesh>
        <Html distanceFactor={10} position={[0, 0.8, 0]}>
          <div className="text-white text-xs font-bold px-3 py-2 bg-orange-900 border-2 border-orange-600 rounded-md shadow-xl backdrop-blur-none">
            🎓 Graduate
          </div>
        </Html>
      </group>
    </Float>
  )
}

function FloatingBriefcase({ position }: { position: [number, number, number] }) {
  return (
    <Float speed={1.8} rotationIntensity={0.6} floatIntensity={0.4}>
      <group position={position}>
        <mesh>
          <boxGeometry args={[1.2, 0.8, 0.4]} />
          <meshStandardMaterial color="#06b6d4" emissive="#06b6d4" emissiveIntensity={0.1} />
        </mesh>
        <mesh position={[0, 0.5, 0]}>
          <boxGeometry args={[0.2, 0.3, 0.1]} />
          <meshStandardMaterial color="#0891b2" />
        </mesh>
        <mesh position={[-0.4, 0.2, 0.21]}>
          <boxGeometry args={[0.1, 0.1, 0.05]} />
          <meshStandardMaterial color="#fbbf24" metalness={0.8} roughness={0.2} />
        </mesh>
        <mesh position={[0.4, 0.2, 0.21]}>
          <boxGeometry args={[0.1, 0.1, 0.05]} />
          <meshStandardMaterial color="#fbbf24" metalness={0.8} roughness={0.2} />
        </mesh>
        <Html distanceFactor={10} position={[0, 1, 0]}>
          <div className="text-white text-xs font-bold px-3 py-2 bg-cyan-900 border-2 border-cyan-600 rounded-md shadow-xl backdrop-blur-none">
            💼 Career
          </div>
        </Html>
      </group>
    </Float>
  )
}

function FloatingTrophy({ position }: { position: [number, number, number] }) {
  return (
    <Float speed={2.2} rotationIntensity={0.3} floatIntensity={0.7}>
      <group position={position}>
        <mesh>
          <cylinderGeometry args={[0.3, 0.4, 0.6, 8]} />
          <meshStandardMaterial
            color="#fbbf24"
            metalness={0.8}
            roughness={0.2}
            emissive="#fbbf24"
            emissiveIntensity={0.1}
          />
        </mesh>
        <mesh position={[0, 0.4, 0]}>
          <sphereGeometry args={[0.2, 8, 8]} />
          <meshStandardMaterial color="#fbbf24" metalness={0.8} roughness={0.2} />
        </mesh>
        <mesh position={[0, -0.4, 0]}>
          <cylinderGeometry args={[0.5, 0.5, 0.1, 8]} />
          <meshStandardMaterial color="#1f2937" />
        </mesh>
        <Html distanceFactor={10} position={[0, 0.8, 0]}>
          <div className="text-black text-xs font-bold px-3 py-2 bg-yellow-300 border-2 border-yellow-600 rounded-md shadow-xl backdrop-blur-none">
            🏆 Success
          </div>
        </Html>
      </group>
    </Float>
  )
}

function FloatingRocket({ position }: { position: [number, number, number] }) {
  const rocketRef = useRef<Group>(null)

  useFrame((state) => {
    if (rocketRef.current) {
      rocketRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2) * 0.2
    }
  })

  return (
    <Float speed={3} rotationIntensity={0.2} floatIntensity={0.3}>
      <group ref={rocketRef} position={position}>
        <mesh>
          <coneGeometry args={[0.3, 1.2, 8]} />
          <meshStandardMaterial color="#ec4899" emissive="#ec4899" emissiveIntensity={0.1} />
        </mesh>
        <mesh position={[0, -0.8, 0]}>
          <cylinderGeometry args={[0.15, 0.15, 0.4, 8]} />
          <meshStandardMaterial color="#f97316" />
        </mesh>
        <mesh position={[0, -1.2, 0]}>
          <coneGeometry args={[0.1, 0.3, 6]} />
          <meshBasicMaterial color="#fbbf24" transparent opacity={0.8} />
        </mesh>
        <Html distanceFactor={10} position={[0, 1, 0]}>
          <div className="text-white text-xs font-bold px-3 py-2 bg-pink-900 border-2 border-pink-600 rounded-md shadow-xl backdrop-blur-none">
            🚀 Launch
          </div>
        </Html>
      </group>
    </Float>
  )
}

export default function Scene3D() {
  return (
    <div className="w-full h-full">
      <Canvas camera={{ position: [0, 0, 8], fov: 50 }}>
        <Suspense fallback={null}>
          <Environment preset="dawn" />
          <ambientLight intensity={0.4} />
          <pointLight position={[10, 10, 10]} intensity={1} color="#8b5cf6" />
          <pointLight position={[-10, -10, -10]} intensity={0.5} color="#06b6d4" />
          <spotLight position={[0, 10, 0]} intensity={0.8} color="#f97316" />

          <FloatingParticles />
          <AnimatedRings />

          <AnimatedGeometry position={[-4, 3, -2]} geometry="icosahedron" color="#8b5cf6" speed={1.2} />
          <AnimatedGeometry position={[4, -3, -2]} geometry="octahedron" color="#06b6d4" speed={0.8} />
          <AnimatedGeometry position={[-3, -3, -3]} geometry="torus" color="#f97316" speed={1.5} />
          <AnimatedGeometry position={[3, 3, -3]} geometry="sphere" color="#ec4899" speed={0.9} />
          <AnimatedGeometry position={[0, 4, -4]} geometry="icosahedron" color="#10b981" speed={1.1} />
          <AnimatedGeometry position={[0, -4, -4]} geometry="octahedron" color="#fbbf24" speed={1.3} />

          {/* Enhanced existing floating elements */}
          <FloatingBook position={[-3, 2, 0]} />
          <FloatingLaptop position={[3, -1, 0]} />
          <FloatingGraduationCap position={[-2, -2, 0]} />
          <FloatingBriefcase position={[2, 2, 0]} />

          <FloatingTrophy position={[-1, 3, 1]} />
          <FloatingRocket position={[1, -3, 1]} />

          <Text3D font="/fonts/Geist_Bold.json" size={0.5} height={0.1} position={[0, 0, 0]}>
            EduOpportunity
            <meshStandardMaterial color="#8b5cf6" emissive="#8b5cf6" emissiveIntensity={0.2} />
          </Text3D>

          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
        </Suspense>
      </Canvas>
    </div>
  )
}
