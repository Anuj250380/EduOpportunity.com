"use client"

import { Button } from "@/components/ui/button"
import {
  BookOpen,
  LayoutDashboard,
  FileText,
  Calendar,
  DollarSign,
  Users,
  Briefcase,
  Trophy,
  Search,
  Menu,
  X,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(false)

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Resume Builder", href: "/resume", icon: FileText },
    { name: "Deadlines", href: "/deadlines", icon: Calendar },
    { name: "Financial Aid", href: "/financial-aid", icon: DollarSign },
    { name: "Community", href: "/community", icon: Users },
    { name: "Applications", href: "/applications", icon: Briefcase },
    { name: "Achievements", href: "/achievements", icon: Trophy },
    { name: "Browse All", href: "/scholarships", icon: Search },
  ]

  return (
    <>
      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="sm"
        className="fixed top-4 left-4 z-50 md:hidden"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </Button>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 w-64 glassmorphism bg-card/90 backdrop-blur-xl border-r border-border/50 transform transition-transform duration-300 ease-in-out ${isOpen ? "translate-x-0" : "-translate-x-full"} md:translate-x-0`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center space-x-2 p-6 border-b border-border/50">
            <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.name}</span>
                </Link>
              )
            })}
          </nav>

          {/* Get Started Button */}
          <div className="p-4 border-t border-border/50">
            <Button
              asChild
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg pulse-glow"
            >
              <Link href="/dashboard">Get Started</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Overlay for mobile */}
      {isOpen && <div className="fixed inset-0 bg-black/50 z-30 md:hidden" onClick={() => setIsOpen(false)} />}
    </>
  )
}
