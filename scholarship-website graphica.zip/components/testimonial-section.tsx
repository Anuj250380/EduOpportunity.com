"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Star, Quote, Plus, X, Send, User, GraduationCap } from "lucide-react"

interface Testimonial {
  id: string
  name: string
  branch: string
  year: string
  rating: number
  message: string
  opportunity: string
  date: string
}

const initialTestimonials: Testimonial[] = [
  {
    id: "1",
    name: "Priya Sharma",
    branch: "Computer Science",
    year: "3rd Year",
    rating: 5,
    message:
      "EduOpportunity helped me secure a scholarship worth ₹2 lakhs! The 3D interface made browsing so engaging and the AI filters found exactly what I needed. Highly recommend to all B.Tech students!",
    opportunity: "Merit-based Scholarship",
    date: "2024-12-15",
  },
  {
    id: "2",
    name: "Arjun Patel",
    branch: "Mechanical Engineering",
    year: "4th Year",
    rating: 5,
    message:
      "Got my dream internship at a top tech company through this platform. The direct application feature saved me so much time. The futuristic design is just amazing!",
    opportunity: "Software Internship",
    date: "2024-12-10",
  },
  {
    id: "3",
    name: "Sneha Reddy",
    branch: "Electronics & Communication",
    year: "2nd Year",
    rating: 4,
    message:
      "Found multiple scholarship opportunities that I never knew existed. The platform is user-friendly and the notifications keep me updated on new opportunities.",
    opportunity: "Research Scholarship",
    date: "2024-12-08",
  },
]

export default function TestimonialSection() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>(initialTestimonials)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    branch: "",
    year: "",
    rating: 5,
    message: "",
    opportunity: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newTestimonial: Testimonial = {
      id: Date.now().toString(),
      ...formData,
      date: new Date().toISOString().split("T")[0],
    }

    setTestimonials([newTestimonial, ...testimonials])
    setFormData({
      name: "",
      branch: "",
      year: "",
      rating: 5,
      message: "",
      opportunity: "",
    })
    setShowForm(false)
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} className={`w-4 h-4 ${i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
    ))
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/5 via-purple-600/5 to-pink-600/5"></div>

      <div className="max-w-7xl mx-auto relative">
        <div className="text-center mb-16">
          <Badge className="mb-4 glassmorphism bg-primary/80 text-white border-primary/20 pulse-glow">
            <Quote className="w-4 h-4 mr-1" />
            Student Success Stories
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What Our Students Say</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Real experiences from B.Tech students who found their perfect opportunities through our platform.
          </p>

          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-primary hover:bg-primary/90 text-white shadow-xl pulse-glow border-0"
          >
            {showForm ? (
              <>
                <X className="w-4 h-4 mr-2" />
                Cancel
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                Share Your Experience
              </>
            )}
          </Button>
        </div>

        {showForm && (
          <div className="max-w-2xl mx-auto mb-16">
            <Card className="glassmorphism bg-card/80 border-primary/20 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-primary flex items-center">
                  <User className="w-5 h-5 mr-2" />
                  Share Your Success Story
                </CardTitle>
                <CardDescription>Help other students by sharing your experience with EduOpportunity</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Name</label>
                      <Input
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Your full name"
                        required
                        className="glassmorphism bg-background/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Branch</label>
                      <Input
                        value={formData.branch}
                        onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                        placeholder="e.g., Computer Science"
                        required
                        className="glassmorphism bg-background/50"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Year</label>
                      <Input
                        value={formData.year}
                        onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                        placeholder="e.g., 3rd Year"
                        required
                        className="glassmorphism bg-background/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Opportunity Type</label>
                      <Input
                        value={formData.opportunity}
                        onChange={(e) => setFormData({ ...formData, opportunity: e.target.value })}
                        placeholder="e.g., Merit Scholarship, Internship"
                        required
                        className="glassmorphism bg-background/50"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Rating</label>
                    <div className="flex gap-1">
                      {Array.from({ length: 5 }, (_, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setFormData({ ...formData, rating: i + 1 })}
                          className="p-1"
                        >
                          <Star
                            className={`w-6 h-6 ${
                              i < formData.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Your Experience</label>
                    <Textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Share your success story and how EduOpportunity helped you..."
                      rows={4}
                      required
                      className="glassmorphism bg-background/50"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 text-white shadow-xl pulse-glow"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Submit Testimonial
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card
              key={testimonial.id}
              className="glassmorphism bg-card/60 border-primary/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:-translate-y-2"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-primary to-purple-600 rounded-full flex items-center justify-center pulse-glow">
                      <GraduationCap className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg text-foreground">{testimonial.name}</CardTitle>
                      <CardDescription className="text-sm">
                        {testimonial.branch} • {testimonial.year}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">{renderStars(testimonial.rating)}</div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <Quote className="absolute -top-2 -left-2 w-8 h-8 text-primary/20" />
                  <p className="text-muted-foreground mb-4 pl-6 italic">"{testimonial.message}"</p>
                </div>
                <div className="flex items-center justify-between">
                  <Badge className="bg-primary text-white border-primary font-medium hover:bg-primary/90">
                    {testimonial.opportunity}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {new Date(testimonial.date).toLocaleDateString()}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground">
            Join thousands of successful B.Tech students who found their opportunities through EduOpportunity
          </p>
        </div>
      </div>
    </section>
  )
}
