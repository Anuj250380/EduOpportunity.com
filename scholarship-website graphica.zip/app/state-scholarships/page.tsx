"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Calendar,
  IndianRupee,
  ExternalLink,
  BookOpen,
  MapPin,
  Building,
  FileText,
  Users,
  GraduationCap,
} from "lucide-react"
import Link from "next/link"

const stateScholarships = [
  // Andhra Pradesh - Updated 2025
  {
    id: 1,
    title: "AP Post-Matric Scholarship (Jnanabhumi/ePASS)",
    state: "Andhra Pradesh",
    provider: "Government of Andhra Pradesh",
    amount: "₹800-₹1,200/month + Tuition reimbursement",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/BC/EBC/Minority/Disabled"],
    type: "Need-based",
    description:
      "Enhanced post-matric scholarship for SC/ST/BC/EBC/Minority/Disabled students with family income ≤ ₹3 lakh. Covers tuition reimbursement and increased maintenance allowance.",
    link: "https://jnanabhumi.ap.gov.in/",
    tags: ["SC/ST/BC/EBC", "Minority", "Disabled", "Post-matric"],
    category: "Social Welfare",
    documents: ["Aadhaar", "Income Certificate", "Caste Certificate", "Academic Records"],
    incomeLimit: "₹3 lakh",
  },
  {
    id: 2,
    title: "AP Digital India Scholarship 2025",
    state: "Andhra Pradesh",
    provider: "Government of Andhra Pradesh",
    amount: "₹25,000-₹50,000 per year",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Computer Science", "IT", "Electronics"],
    type: "Merit-based",
    description: "New digital skills scholarship for tech students with focus on AI, ML, and emerging technologies.",
    link: "https://jnanabhumi.ap.gov.in/",
    tags: ["Digital Skills", "AI/ML", "Tech Focus", "New 2025"],
    category: "Technology Education",
    documents: ["Academic Records", "Tech Skills Certificate", "Income Certificate"],
    incomeLimit: "₹5 lakh",
  },

  // Assam - Updated 2025
  {
    id: 3,
    title: "Post-Matric Scholarship for SC/ST/OBC/Minorities",
    state: "Assam",
    provider: "Government of Assam",
    amount: "Tuition + ₹1,500/month maintenance",
    deadline: "2025-12-15",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC/Minorities"],
    type: "Need-based",
    description: "Enhanced support for SC/ST/OBC/Minority students. Income limits: SC/ST ≤₹3L, OBC ≤₹1.5L.",
    link: "https://scholarships.gov.in/",
    tags: ["SC/ST/OBC", "Minorities", "Enhanced Amount", "Maintenance"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Domicile Certificate"],
    incomeLimit: "SC/ST: ₹3L, OBC: ₹1.5L",
  },
  {
    id: 4,
    title: "NEC Merit Scholarship Plus",
    state: "Assam",
    provider: "North Eastern Council",
    amount: "₹40,000 per year",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "NE Region", "60% marks"],
    type: "Merit-based",
    description: "Enhanced merit scholarship for BTech students from NE region with 60% marks and family income ≤₹10L.",
    link: "https://scholarships.gov.in/",
    tags: ["NE Region", "Merit", "Enhanced", "60% marks"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "Domicile Certificate"],
    incomeLimit: "₹10 lakh",
  },

  // Bihar - Updated 2025
  {
    id: 5,
    title: "Bihar Engineering Excellence Scholarship",
    state: "Bihar",
    provider: "Government of Bihar",
    amount: "₹60,000 per year + Laptop",
    deadline: "2025-12-31",
    eligibility: ["All Years", "Engineering", "75% marks"],
    type: "Merit-based",
    description:
      "New merit-based scholarship for engineering students with 75% marks, includes laptop and skill development programs.",
    link: "https://medhasoft.bih.nic.in/",
    tags: ["Engineering", "Merit", "Laptop", "Skill Development"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission Proof", "Income Certificate"],
    incomeLimit: "₹6 lakh",
  },
  {
    id: 6,
    title: "Post-Matric Scholarship for SC/ST/OBC",
    state: "Bihar",
    provider: "Government of Bihar",
    amount: "Tuition + Exam fees + ₹1,200/month maintenance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description:
      "Complete educational support including tuition, exam fees, and maintenance. Income limits: SC/ST ≤₹2.5L, OBC ≤₹1.5L.",
    link: "https://medhasoft.bih.nic.in/",
    tags: ["SC/ST/OBC", "Complete Support", "Maintenance"],
    category: "Social Welfare",
    documents: ["Domicile", "Caste Certificate", "Mark Sheet", "Bank Passbook", "Aadhaar"],
    incomeLimit: "SC/ST: ₹2.5L, OBC: ₹1.5L",
  },

  // Delhi - New 2025 Schemes
  {
    id: 7,
    title: "Delhi Tech Innovation Scholarship",
    state: "Delhi",
    provider: "Government of Delhi",
    amount: "₹75,000 per year + Internship guarantee",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Computer Science", "IT", "Electronics"],
    type: "Merit-based",
    description:
      "New scholarship for tech students with guaranteed internship placement in Delhi startups and tech companies.",
    link: "https://delhi.gov.in/",
    tags: ["Tech Innovation", "Internship Guarantee", "Startups", "New 2025"],
    category: "Technology Innovation",
    documents: ["Academic Records", "Delhi Domicile", "Tech Portfolio"],
    incomeLimit: "₹8 lakh",
  },
  {
    id: 8,
    title: "Merit Scholarship for SC/ST/OBC/Minority Students",
    state: "Delhi",
    provider: "Government of Delhi",
    amount: "Up to ₹30,000 per year",
    deadline: "2025-05-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC/Minority"],
    type: "Merit-based",
    description: "Enhanced merit scholarship with increased amounts for deserving students from reserved categories.",
    link: "https://delhi.gov.in/",
    tags: ["SC/ST/OBC", "Minority", "Merit", "Enhanced"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Academic Records"],
    incomeLimit: "₹6 lakh",
  },

  // Gujarat - Updated 2025
  {
    id: 9,
    title: "Digital Gujarat Scholarship Plus",
    state: "Gujarat",
    provider: "Government of Gujarat",
    amount: "Tuition + Exam + ₹15,000 maintenance + Digital skills training",
    deadline: "2025-12-15",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC/EWS"],
    type: "Need-based",
    description:
      "Enhanced comprehensive support with digital skills training. Income limits: SC/ST ≤₹2.5L, OBC ≤₹2L, EWS ≤₹8L.",
    link: "https://www.digitalgujarat.gov.in/",
    tags: ["Digital Skills", "Enhanced", "Training", "Comprehensive"],
    category: "Social Welfare",
    documents: ["Resident Certificate", "Caste Certificate", "Income Certificate", "Aadhaar"],
    incomeLimit: "SC/ST: ₹2.5L, OBC: ₹2L, EWS: ₹8L",
  },

  // Haryana - Updated 2025
  {
    id: 10,
    title: "Haryana Engineering Merit Scholarship",
    state: "Haryana",
    provider: "Government of Haryana",
    amount: "₹50,000 per year + Skill certification",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "70% marks"],
    type: "Merit-based",
    description:
      "New merit scholarship for engineering students with 70% marks, includes industry skill certification programs.",
    link: "https://haryanascbc.gov.in/",
    tags: ["Engineering", "Merit", "Skill Certification", "Industry"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission", "Domicile Certificate"],
    incomeLimit: "₹8 lakh",
  },
  {
    id: 11,
    title: "Post-Matric Scholarship (SC/BC/DNT/Minority/EWS)",
    state: "Haryana",
    provider: "Government of Haryana",
    amount: "Tuition + ₹15,000/year maintenance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/BC/DNT/Minority/EWS"],
    type: "Need-based",
    description:
      "Enhanced support for SC/BC/DNT/Minority/EWS students with family income ≤₹3L. Includes tuition and maintenance support.",
    link: "https://haryanascbc.gov.in/",
    tags: ["SC/BC/DNT", "Minority", "EWS", "Enhanced"],
    category: "Social Welfare",
    documents: ["Resident Certificate", "Caste Certificate", "Income Certificate", "Academic Records"],
    incomeLimit: "₹3 lakh",
  },

  // Karnataka - Updated 2025
  {
    id: 12,
    title: "Karnataka Innovation Scholarship",
    state: "Karnataka",
    provider: "Government of Karnataka",
    amount: "₹80,000 per year + Research grant",
    deadline: "2025-11-30",
    eligibility: ["Final Year", "Engineering", "Research project"],
    type: "Merit-based",
    description:
      "New scholarship for final year engineering students with innovative research projects and startup potential.",
    link: "https://ssp.postmatric.karnataka.gov.in/",
    tags: ["Innovation", "Research", "Startup", "Final Year"],
    category: "Innovation Excellence",
    documents: ["Research Proposal", "Academic Records", "Innovation Certificate"],
    incomeLimit: "₹10 lakh",
  },
  {
    id: 13,
    title: "SSP Scholarship (Post-Matric) Enhanced",
    state: "Karnataka",
    provider: "Government of Karnataka",
    amount: "Fee concession + ₹60,000/year merit",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC/EWS"],
    type: "Need-based",
    description:
      "Enhanced fee concession with increased merit component. Income limits: OBC/EWS ≤₹2L rural/₹2.5L urban.",
    link: "https://ssp.postmatric.karnataka.gov.in/",
    tags: ["SSP", "Enhanced", "Fee Concession", "Merit"],
    category: "Social Welfare",
    documents: ["Domicile Certificate", "Caste Certificate", "Income Certificate", "Academic Records"],
    incomeLimit: "₹2L rural/₹2.5L urban",
  },

  // Kerala - Updated 2025
  {
    id: 14,
    title: "Kerala Tech Excellence Scholarship",
    state: "Kerala",
    provider: "Government of Kerala",
    amount: "₹1,00,000 per year + Industry mentorship",
    deadline: "2025-10-31",
    eligibility: ["All Years", "Computer Science", "IT", "Electronics", "80% marks"],
    type: "Merit-based",
    description:
      "Premium scholarship for tech students with 80% marks, includes industry mentorship and placement assistance.",
    link: "https://egrantz.kerala.gov.in/",
    tags: ["Tech Excellence", "Industry Mentorship", "Placement", "Premium"],
    category: "Technology Excellence",
    documents: ["Mark Sheets", "Tech Skills Portfolio", "Domicile Certificate"],
    incomeLimit: "₹12 lakh",
  },
  {
    id: 15,
    title: "E-Grantz Post-Matric Scholarship Enhanced",
    state: "Kerala",
    provider: "Government of Kerala",
    amount: "Full/Partial fee + ₹2,000/month allowance",
    deadline: "2025-12-15",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description:
      "Enhanced comprehensive support covering full or partial fees with increased monthly allowances for SC/ST/OBC students.",
    link: "https://egrantz.kerala.gov.in/",
    tags: ["Enhanced", "Full Fee", "Increased Allowance", "SC/ST/OBC"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Academic Records"],
    incomeLimit: "As per category guidelines",
  },

  // Maharashtra - Updated 2025
  {
    id: 16,
    title: "Maharashtra AI/ML Scholarship",
    state: "Maharashtra",
    provider: "Government of Maharashtra",
    amount: "₹1,20,000 per year + AI certification",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Computer Science", "IT", "AI/ML courses"],
    type: "Merit-based",
    description:
      "New scholarship for AI/ML students with industry certification and placement assistance in tech companies.",
    link: "https://mahadbtmahait.gov.in/",
    tags: ["AI/ML", "Industry Certification", "Tech Companies", "New 2025"],
    category: "Artificial Intelligence",
    documents: ["AI/ML Course Certificate", "Academic Records", "Domicile Certificate"],
    incomeLimit: "₹15 lakh",
  },
  {
    id: 17,
    title: "Post-Matric Scholarship (MahaDBT) Enhanced",
    state: "Maharashtra",
    provider: "Government of Maharashtra",
    amount: "Tuition + Hostel + ₹1,500/month maintenance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC/VJNT/SBC", "≥60% marks"],
    type: "Need-based",
    description:
      "Enhanced comprehensive support through MahaDBT with increased maintenance. Income limits: SC/ST ≤₹3L, OBC/VJNT/SBC ≤₹1.5L/₹10L.",
    link: "https://mahadbtmahait.gov.in/",
    tags: ["MahaDBT", "Enhanced", "Increased Maintenance", "Comprehensive"],
    category: "Social Welfare",
    documents: ["Domicile Certificate", "Caste Certificate", "Income Certificate", "Mark Sheets"],
    incomeLimit: "SC/ST: ₹3L, OBC/VJNT/SBC: ₹1.5L/₹10L",
  },

  // Odisha - Updated 2025
  {
    id: 18,
    title: "PRERANA Post-Matric Scheme Enhanced",
    state: "Odisha",
    provider: "Government of Odisha",
    amount: "Tuition + ₹2,000/month allowance + Hostel + Skill training",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC/SEBC/EBC"],
    type: "Need-based",
    description:
      "Enhanced comprehensive support through PRERANA portal with skill training. Income caps: SC/ST ≤₹3L, OBC/SEBC ≤₹1.5L.",
    link: "https://preranaportal.odisha.gov.in/",
    tags: ["PRERANA", "Enhanced", "Skill Training", "Comprehensive"],
    category: "Social Welfare",
    documents: ["Domicile Certificate", "Caste Certificate", "Income Certificate", "Academic Records"],
    incomeLimit: "SC/ST: ₹3L, OBC/SEBC: ₹1.5L",
  },

  // Tamil Nadu - Updated 2025
  {
    id: 19,
    title: "Tamil Nadu Engineering Excellence Award",
    state: "Tamil Nadu",
    provider: "Directorate of Technical Education",
    amount: "₹1,50,000 per year + Research funding",
    deadline: "2025-11-30",
    eligibility: ["Final Year", "Engineering", "Research project", "85% marks"],
    type: "Merit-based",
    description:
      "Premium award for engineering students with exceptional academic performance and innovative research projects.",
    link: "https://www.tnscholarship.gov.in/",
    tags: ["Excellence Award", "Research Funding", "Innovation", "Premium"],
    category: "Research Excellence",
    documents: ["Research Proposal", "Mark Sheets", "Innovation Portfolio"],
    incomeLimit: "No limit",
  },
  {
    id: 20,
    title: "Post-Matric Scholarship for BC/MBC/DNC/SC/ST Enhanced",
    state: "Tamil Nadu",
    provider: "Directorate of Collegiate Education",
    amount: "Full tuition + ₹10,000/year maintenance + Books + Hostel + Digital device",
    deadline: "2025-12-15",
    eligibility: ["All Years", "All Branches", "BC/MBC/DNC/SC/ST"],
    type: "Need-based",
    description:
      "Enhanced comprehensive support with digital device provision. Income ≤₹3L for BC, others as per guidelines.",
    link: "https://www.tnscholarship.gov.in/",
    tags: ["Enhanced", "Digital Device", "Full Support", "Comprehensive"],
    category: "Social Welfare",
    documents: ["Domicile Certificate", "Caste Certificate", "Income Certificate", "Academic Records"],
    incomeLimit: "BC: ₹3L, others as per guidelines",
  },

  // Telangana - Updated 2025
  {
    id: 21,
    title: "Telangana Innovation Hub Scholarship",
    state: "Telangana",
    provider: "Government of Telangana",
    amount: "₹2,00,000 per year + Startup incubation",
    deadline: "2025-10-31",
    eligibility: ["Final Year", "Engineering", "Startup idea", "75% marks"],
    type: "Merit-based",
    description:
      "Premium scholarship for engineering students with viable startup ideas, includes incubation support and mentorship.",
    link: "https://telanganaepass.cgg.gov.in/",
    tags: ["Innovation Hub", "Startup Incubation", "Mentorship", "Premium"],
    category: "Entrepreneurship",
    documents: ["Startup Proposal", "Academic Records", "Business Plan"],
    incomeLimit: "₹20 lakh",
  },
  {
    id: 22,
    title: "ePASS Post-Matric Scholarship Enhanced",
    state: "Telangana",
    provider: "Government of Telangana",
    amount: "100% tuition + ₹8K-₹25K hostel/maintenance + Digital allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/BC/Minority/EBC/Disabled"],
    type: "Need-based",
    description:
      "Enhanced complete fee reimbursement with digital allowance. Income ≤₹2.5L/₹2L with minimum attendance requirement.",
    link: "https://telanganaepass.cgg.gov.in/",
    tags: ["ePASS", "Enhanced", "Digital Allowance", "Complete Support"],
    category: "Social Welfare",
    documents: ["Domicile Certificate", "Caste Certificate", "Income Certificate", "Attendance Certificate"],
    incomeLimit: "₹2.5L/₹2L",
  },

  // Uttar Pradesh - Updated 2025
  {
    id: 23,
    title: "UP Tech Innovation Scholarship",
    state: "Uttar Pradesh",
    provider: "Government of Uttar Pradesh",
    amount: "₹1,00,000 per year + Industry exposure",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Computer Science", "IT", "Electronics", "70% marks"],
    type: "Merit-based",
    description:
      "New tech-focused scholarship with industry exposure programs and placement assistance in UP's growing tech sector.",
    link: "https://scholarship.up.gov.in/",
    tags: ["Tech Innovation", "Industry Exposure", "Placement", "New 2025"],
    category: "Technology Innovation",
    documents: ["Academic Records", "Tech Skills Certificate", "Domicile Certificate"],
    incomeLimit: "₹10 lakh",
  },
  {
    id: 24,
    title: "Post-Matric for SC/ST/OBC/Minority/General Enhanced",
    state: "Uttar Pradesh",
    provider: "Government of Uttar Pradesh",
    amount: "Tuition + ₹1,500/month (hosteller) + ₹800/month (day scholar)",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC/Minority/General"],
    type: "Need-based",
    description:
      "Enhanced comprehensive support with increased rates for hostellers and day scholars. OTR registration compulsory.",
    link: "https://scholarship.up.gov.in/",
    tags: ["Enhanced", "Increased Rates", "Comprehensive", "OTR"],
    category: "Social Welfare",
    documents: ["Domicile Certificate", "Caste Certificate", "Income Certificate", "OTR Registration"],
    incomeLimit: "As per category",
  },

  // West Bengal - Updated 2025
  {
    id: 25,
    title: "Swami Vivekananda Merit-cum-Means (SVMCM) Enhanced",
    state: "West Bengal",
    provider: "Government of West Bengal",
    amount: "Up to ₹12,000 per month + Skill development",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "Minority/General", "60% (UG), 53% (PG)"],
    type: "Merit-cum-Need",
    description:
      "Enhanced high-value monthly scholarship with skill development programs. Income ≤₹3L with specific percentage requirements.",
    link: "https://svmcm.wbhed.gov.in/",
    tags: ["SVMCM", "Enhanced", "Skill Development", "High Value"],
    category: "Merit-cum-Need",
    documents: ["Resident Certificate", "Income Certificate", "Mark Sheets", "Community Certificate"],
    incomeLimit: "₹3 lakh",
  },

  // New States/UTs - 2025 Additions
  {
    id: 26,
    title: "Jammu & Kashmir Engineering Excellence Scholarship",
    state: "Jammu & Kashmir",
    provider: "Government of J&K",
    amount: "₹1,25,000 per year + Special allowance",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "J&K domicile", "70% marks"],
    type: "Merit-based",
    description:
      "Special scholarship for J&K engineering students with enhanced support and special allowances for border area students.",
    link: "https://jkscholarships.gov.in/",
    tags: ["J&K", "Engineering", "Border Area", "Special Allowance"],
    category: "Regional Development",
    documents: ["J&K Domicile", "Academic Records", "Border Area Certificate"],
    incomeLimit: "₹8 lakh",
  },
  {
    id: 27,
    title: "Ladakh STEM Scholarship",
    state: "Ladakh",
    provider: "UT Administration Ladakh",
    amount: "₹1,50,000 per year + Research grant",
    deadline: "2025-10-31",
    eligibility: ["All Years", "STEM fields", "Ladakh domicile"],
    type: "Merit-based",
    description:
      "Premium STEM scholarship for Ladakh students with research grants and special provisions for high-altitude region challenges.",
    link: "https://ladakh.gov.in/",
    tags: ["Ladakh", "STEM", "Research Grant", "High Altitude"],
    category: "STEM Excellence",
    documents: ["Ladakh Domicile", "STEM Course Certificate", "Academic Records"],
    incomeLimit: "₹15 lakh",
  },

  // Arunachal Pradesh
  {
    id: 28,
    title: "Arunachal Pradesh Post-Matric Scholarship",
    state: "Arunachal Pradesh",
    provider: "Government of Arunachal Pradesh",
    amount: "₹1,200/month + Tuition reimbursement",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "Arunachal domicile"],
    type: "Need-based",
    description:
      "Comprehensive support for ST/SC/OBC students with family income ≤₹2.5L. Special provisions for border area students.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Border Area", "NE Region", "Tribal"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "Domicile Certificate", "Academic Records"],
    incomeLimit: "₹2.5 lakh",
  },
  {
    id: 29,
    title: "NEC Merit Scholarship for Arunachal Pradesh",
    state: "Arunachal Pradesh",
    provider: "North Eastern Council",
    amount: "₹45,000 per year",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "60% marks", "NE domicile"],
    type: "Merit-based",
    description: "Enhanced merit scholarship for NE students with 60% marks and family income ≤₹10L.",
    link: "https://scholarships.gov.in/",
    tags: ["NE Region", "Merit", "Enhanced", "60% marks"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "Domicile Certificate"],
    incomeLimit: "₹10 lakh",
  },

  // Chhattisgarh
  {
    id: 30,
    title: "Chhattisgarh Post-Matric Scholarship Enhanced",
    state: "Chhattisgarh",
    provider: "Government of Chhattisgarh",
    amount: "Tuition + ₹1,500/month maintenance + Books allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description: "Enhanced comprehensive support with books allowance. Income limits: SC/ST ≤₹2.5L, OBC ≤₹1.5L.",
    link: "https://scholarshipportal.cg.nic.in/",
    tags: ["SC/ST/OBC", "Enhanced", "Books Allowance", "Comprehensive"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Domicile Certificate", "Academic Records"],
    incomeLimit: "SC/ST: ₹2.5L, OBC: ₹1.5L",
  },
  {
    id: 31,
    title: "Chhattisgarh Engineering Excellence Award",
    state: "Chhattisgarh",
    provider: "Government of Chhattisgarh",
    amount: "₹75,000 per year + Industry exposure",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "75% marks"],
    type: "Merit-based",
    description: "Merit award for engineering students with industry exposure programs and skill development.",
    link: "https://scholarshipportal.cg.nic.in/",
    tags: ["Engineering", "Merit", "Industry Exposure", "Skill Development"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission", "Income Certificate"],
    incomeLimit: "₹8 lakh",
  },

  // Goa
  {
    id: 32,
    title: "Goa Higher Education Scholarship",
    state: "Goa",
    provider: "Government of Goa",
    amount: "₹50,000 per year + Special allowance",
    deadline: "2025-12-15",
    eligibility: ["All Years", "All Branches", "Goa domicile", "60% marks"],
    type: "Merit-based",
    description:
      "Merit scholarship for Goan students with 60% marks and family income ≤₹6L. Special allowance for coastal area students.",
    link: "https://www.goa.gov.in/",
    tags: ["Goa Domicile", "Merit", "Coastal Area", "Special Allowance"],
    category: "Regional Development",
    documents: ["Goa Domicile", "Mark Sheets", "Income Certificate"],
    incomeLimit: "₹6 lakh",
  },
  {
    id: 33,
    title: "Post-Matric Scholarship for SC/ST/OBC",
    state: "Goa",
    provider: "Government of Goa",
    amount: "Tuition + ₹1,000/month maintenance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description: "Comprehensive support for SC/ST/OBC students with family income ≤₹2.5L.",
    link: "https://www.goa.gov.in/",
    tags: ["SC/ST/OBC", "Comprehensive", "Maintenance"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Domicile Certificate"],
    incomeLimit: "₹2.5 lakh",
  },

  // Himachal Pradesh
  {
    id: 34,
    title: "Himachal Pradesh Merit Scholarship",
    state: "Himachal Pradesh",
    provider: "Government of Himachal Pradesh",
    amount: "₹60,000 per year + Hill area allowance",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "HP domicile", "70% marks"],
    type: "Merit-based",
    description: "Merit scholarship with special hill area allowance for HP students with 70% marks and income ≤₹8L.",
    link: "https://hpepass.cgg.gov.in/",
    tags: ["HP Domicile", "Merit", "Hill Area", "Special Allowance"],
    category: "Regional Development",
    documents: ["HP Domicile", "Mark Sheets", "Income Certificate"],
    incomeLimit: "₹8 lakh",
  },
  {
    id: 35,
    title: "Post-Matric Scholarship for SC/ST/OBC",
    state: "Himachal Pradesh",
    provider: "Government of Himachal Pradesh",
    amount: "Tuition + ₹1,200/month + Hill allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description: "Enhanced support with hill area allowance. Income limits: SC/ST ≤₹2.5L, OBC ≤₹1.5L.",
    link: "https://hpepass.cgg.gov.in/",
    tags: ["SC/ST/OBC", "Hill Allowance", "Enhanced"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "HP Domicile"],
    incomeLimit: "SC/ST: ₹2.5L, OBC: ₹1.5L",
  },

  // Jharkhand
  {
    id: 36,
    title: "Jharkhand Post-Matric Scholarship Enhanced",
    state: "Jharkhand",
    provider: "Government of Jharkhand",
    amount: "Tuition + ₹1,500/month + Tribal allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC"],
    type: "Need-based",
    description: "Enhanced support with special tribal allowance. Income limits: ST/SC ≤₹2.5L, OBC ≤₹1.5L.",
    link: "https://ekalyan.cgg.gov.in/",
    tags: ["ST/SC/OBC", "Tribal Allowance", "Enhanced"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "Domicile Certificate"],
    incomeLimit: "ST/SC: ₹2.5L, OBC: ₹1.5L",
  },
  {
    id: 37,
    title: "Jharkhand Engineering Merit Award",
    state: "Jharkhand",
    provider: "Government of Jharkhand",
    amount: "₹80,000 per year + Skill training",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "75% marks"],
    type: "Merit-based",
    description: "Merit award for engineering students with skill training and industry exposure programs.",
    link: "https://ekalyan.cgg.gov.in/",
    tags: ["Engineering", "Merit", "Skill Training", "Industry"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission", "Income Certificate"],
    incomeLimit: "₹10 lakh",
  },

  // Madhya Pradesh
  {
    id: 38,
    title: "MP Post-Matric Scholarship Enhanced",
    state: "Madhya Pradesh",
    provider: "Government of Madhya Pradesh",
    amount: "Tuition + ₹1,200/month + Books + Hostel",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description: "Comprehensive enhanced support including books and hostel. Income limits: SC/ST ≤₹2.5L, OBC ≤₹1.5L.",
    link: "https://scholarshipportal.mp.gov.in/",
    tags: ["SC/ST/OBC", "Enhanced", "Books", "Hostel"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "MP Domicile", "Academic Records"],
    incomeLimit: "SC/ST: ₹2.5L, OBC: ₹1.5L",
  },
  {
    id: 39,
    title: "MP Engineering Excellence Scholarship",
    state: "Madhya Pradesh",
    provider: "Government of Madhya Pradesh",
    amount: "₹1,00,000 per year + Research grant",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "80% marks"],
    type: "Merit-based",
    description:
      "Premium scholarship for engineering students with 80% marks, includes research grants and industry mentorship.",
    link: "https://scholarshipportal.mp.gov.in/",
    tags: ["Engineering", "Premium", "Research Grant", "Mentorship"],
    category: "Research Excellence",
    documents: ["Mark Sheets", "Research Proposal", "Engineering Admission"],
    incomeLimit: "₹12 lakh",
  },

  // Manipur
  {
    id: 40,
    title: "Manipur Post-Matric Scholarship",
    state: "Manipur",
    provider: "Government of Manipur",
    amount: "₹1,500/month + Tuition + Special allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "Manipur domicile"],
    type: "Need-based",
    description: "Enhanced support with special allowance for border state students. Income ≤₹2.5L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Border State", "Special Allowance", "NE Region"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "Manipur Domicile"],
    incomeLimit: "₹2.5 lakh",
  },
  {
    id: 41,
    title: "NEC Merit Scholarship for Manipur",
    state: "Manipur",
    provider: "North Eastern Council",
    amount: "₹45,000 per year",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "60% marks", "NE domicile"],
    type: "Merit-based",
    description: "Enhanced merit scholarship for NE students with 60% marks and family income ≤₹10L.",
    link: "https://scholarships.gov.in/",
    tags: ["NE Region", "Merit", "Enhanced", "60% marks"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "Domicile Certificate"],
    incomeLimit: "₹10 lakh",
  },

  // Meghalaya
  {
    id: 42,
    title: "Meghalaya Post-Matric Scholarship",
    state: "Meghalaya",
    provider: "Government of Meghalaya",
    amount: "₹1,200/month + Tuition + Hill allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "Meghalaya domicile"],
    type: "Need-based",
    description: "Comprehensive support with hill area allowance for tribal students. Income ≤₹2.5L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Hill Allowance", "Tribal", "NE Region"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "Meghalaya Domicile"],
    incomeLimit: "₹2.5 lakh",
  },
  {
    id: 43,
    title: "Meghalaya Engineering Merit Scholarship",
    state: "Meghalaya",
    provider: "Government of Meghalaya",
    amount: "₹60,000 per year + Skill development",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "70% marks"],
    type: "Merit-based",
    description: "Merit scholarship for engineering students with skill development programs and industry exposure.",
    link: "https://scholarships.gov.in/",
    tags: ["Engineering", "Merit", "Skill Development", "Industry"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission", "Income Certificate"],
    incomeLimit: "₹8 lakh",
  },

  // Mizoram
  {
    id: 44,
    title: "Mizoram Post-Matric Scholarship",
    state: "Mizoram",
    provider: "Government of Mizoram",
    amount: "₹1,500/month + Tuition + Border allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "Mizoram domicile"],
    type: "Need-based",
    description: "Enhanced support with border area allowance for tribal students. Income ≤₹2.5L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Border Allowance", "Tribal", "NE Region"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "Mizoram Domicile"],
    incomeLimit: "₹2.5 lakh",
  },
  {
    id: 45,
    title: "NEC Merit Scholarship for Mizoram",
    state: "Mizoram",
    provider: "North Eastern Council",
    amount: "₹45,000 per year",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "60% marks", "NE domicile"],
    type: "Merit-based",
    description: "Enhanced merit scholarship for NE students with 60% marks and family income ≤₹10L.",
    link: "https://scholarships.gov.in/",
    tags: ["NE Region", "Merit", "Enhanced", "60% marks"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "Domicile Certificate"],
    incomeLimit: "₹10 lakh",
  },

  // Nagaland
  {
    id: 46,
    title: "Nagaland Post-Matric Scholarship",
    state: "Nagaland",
    provider: "Government of Nagaland",
    amount: "₹1,500/month + Tuition + Tribal allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "Nagaland domicile"],
    type: "Need-based",
    description: "Enhanced support with tribal allowance for indigenous students. Income ≤₹2.5L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Tribal Allowance", "Indigenous", "NE Region"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "Nagaland Domicile"],
    incomeLimit: "₹2.5 lakh",
  },
  {
    id: 47,
    title: "Nagaland Engineering Excellence Award",
    state: "Nagaland",
    provider: "Government of Nagaland",
    amount: "₹75,000 per year + Industry mentorship",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "75% marks"],
    type: "Merit-based",
    description: "Excellence award for engineering students with industry mentorship and placement assistance.",
    link: "https://scholarships.gov.in/",
    tags: ["Engineering", "Excellence", "Mentorship", "Placement"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission", "Income Certificate"],
    incomeLimit: "₹10 lakh",
  },

  // Punjab
  {
    id: 48,
    title: "Punjab Post-Matric Scholarship Enhanced",
    state: "Punjab",
    provider: "Government of Punjab",
    amount: "Tuition + ₹1,500/month + Books allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description: "Enhanced comprehensive support with books allowance. Income limits: SC/ST ≤₹2.5L, OBC ≤₹1.5L.",
    link: "https://punjabscholarships.gov.in/",
    tags: ["SC/ST/OBC", "Enhanced", "Books Allowance", "Comprehensive"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Punjab Domicile", "Academic Records"],
    incomeLimit: "SC/ST: ₹2.5L, OBC: ₹1.5L",
  },
  {
    id: 49,
    title: "Punjab Engineering Merit Scholarship",
    state: "Punjab",
    provider: "Government of Punjab",
    amount: "₹1,20,000 per year + Industry training",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "80% marks"],
    type: "Merit-based",
    description: "Premium merit scholarship for engineering students with industry training and placement support.",
    link: "https://punjabscholarships.gov.in/",
    tags: ["Engineering", "Premium", "Industry Training", "Placement"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission", "Income Certificate"],
    incomeLimit: "₹15 lakh",
  },

  // Rajasthan
  {
    id: 50,
    title: "Rajasthan Post-Matric Scholarship Enhanced",
    state: "Rajasthan",
    provider: "Government of Rajasthan",
    amount: "Tuition + ₹1,200/month + Desert allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC/MBC"],
    type: "Need-based",
    description: "Enhanced support with desert area allowance. Income limits: SC/ST ≤₹2.5L, OBC/MBC ≤₹1.5L.",
    link: "https://sje.rajasthan.gov.in/",
    tags: ["SC/ST/OBC/MBC", "Desert Allowance", "Enhanced"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Rajasthan Domicile", "Academic Records"],
    incomeLimit: "SC/ST: ₹2.5L, OBC/MBC: ₹1.5L",
  },
  {
    id: 51,
    title: "Rajasthan Engineering Excellence Award",
    state: "Rajasthan",
    provider: "Government of Rajasthan",
    amount: "₹1,50,000 per year + Research funding",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "85% marks"],
    type: "Merit-based",
    description: "Premium excellence award for engineering students with research funding and innovation support.",
    link: "https://sje.rajasthan.gov.in/",
    tags: ["Engineering", "Excellence", "Research Funding", "Innovation"],
    category: "Research Excellence",
    documents: ["Mark Sheets", "Research Proposal", "Engineering Admission"],
    incomeLimit: "₹20 lakh",
  },

  // Sikkim
  {
    id: 52,
    title: "Sikkim Post-Matric Scholarship",
    state: "Sikkim",
    provider: "Government of Sikkim",
    amount: "₹2,000/month + Tuition + Hill allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "Sikkim domicile"],
    type: "Need-based",
    description: "Enhanced support with hill area allowance for Himalayan state students. Income ≤₹3L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Hill Allowance", "Himalayan", "Enhanced"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Sikkim Domicile"],
    incomeLimit: "₹3 lakh",
  },
  {
    id: 53,
    title: "Sikkim Merit Scholarship",
    state: "Sikkim",
    provider: "Government of Sikkim",
    amount: "₹80,000 per year + Special allowance",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "75% marks", "Sikkim domicile"],
    type: "Merit-based",
    description: "Merit scholarship with special allowance for Sikkim students with 75% marks and income ≤₹10L.",
    link: "https://scholarships.gov.in/",
    tags: ["Merit", "Special Allowance", "Sikkim", "75% marks"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "Sikkim Domicile"],
    incomeLimit: "₹10 lakh",
  },

  // Tripura
  {
    id: 54,
    title: "Tripura Post-Matric Scholarship",
    state: "Tripura",
    provider: "Government of Tripura",
    amount: "₹1,200/month + Tuition + Border allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "Tripura domicile"],
    type: "Need-based",
    description: "Enhanced support with border area allowance for tribal students. Income ≤₹2.5L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Border Allowance", "Tribal", "NE Region"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "Tripura Domicile"],
    incomeLimit: "₹2.5 lakh",
  },
  {
    id: 55,
    title: "NEC Merit Scholarship for Tripura",
    state: "Tripura",
    provider: "North Eastern Council",
    amount: "₹45,000 per year",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "60% marks", "NE domicile"],
    type: "Merit-based",
    description: "Enhanced merit scholarship for NE students with 60% marks and family income ≤₹10L.",
    link: "https://scholarships.gov.in/",
    tags: ["NE Region", "Merit", "Enhanced", "60% marks"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "Domicile Certificate"],
    incomeLimit: "₹10 lakh",
  },

  // Uttarakhand
  {
    id: 56,
    title: "Uttarakhand Post-Matric Scholarship Enhanced",
    state: "Uttarakhand",
    provider: "Government of Uttarakhand",
    amount: "Tuition + ₹1,500/month + Hill allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description: "Enhanced support with hill area allowance. Income limits: SC/ST ≤₹2.5L, OBC ≤₹1.5L.",
    link: "https://scholarships.uk.gov.in/",
    tags: ["SC/ST/OBC", "Hill Allowance", "Enhanced"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "UK Domicile", "Academic Records"],
    incomeLimit: "SC/ST: ₹2.5L, OBC: ₹1.5L",
  },
  {
    id: 57,
    title: "Uttarakhand Engineering Merit Award",
    state: "Uttarakhand",
    provider: "Government of Uttarakhand",
    amount: "₹1,00,000 per year + Industry exposure",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "80% marks"],
    type: "Merit-based",
    description: "Merit award for engineering students with industry exposure and skill development programs.",
    link: "https://scholarships.uk.gov.in/",
    tags: ["Engineering", "Merit", "Industry Exposure", "Skill Development"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission", "Income Certificate"],
    incomeLimit: "₹12 lakh",
  },

  // Union Territories

  // Andaman & Nicobar Islands
  {
    id: 58,
    title: "A&N Islands Post-Matric Scholarship",
    state: "Andaman & Nicobar Islands",
    provider: "UT Administration A&N Islands",
    amount: "₹2,500/month + Tuition + Island allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "A&N domicile"],
    type: "Need-based",
    description: "Enhanced support with special island allowance for remote area students. Income ≤₹3L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Island Allowance", "Remote Area", "Enhanced"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "A&N Domicile"],
    incomeLimit: "₹3 lakh",
  },
  {
    id: 59,
    title: "A&N Islands Merit Scholarship",
    state: "Andaman & Nicobar Islands",
    provider: "UT Administration A&N Islands",
    amount: "₹1,00,000 per year + Special support",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "70% marks", "A&N domicile"],
    type: "Merit-based",
    description: "Premium merit scholarship with special support for island students with 70% marks.",
    link: "https://scholarships.gov.in/",
    tags: ["Merit", "Island Students", "Special Support", "Premium"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "A&N Domicile"],
    incomeLimit: "₹15 lakh",
  },

  // Chandigarh
  {
    id: 60,
    title: "Chandigarh Post-Matric Scholarship",
    state: "Chandigarh",
    provider: "UT Administration Chandigarh",
    amount: "Tuition + ₹1,000/month maintenance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC", "Chandigarh domicile"],
    type: "Need-based",
    description: "Comprehensive support for SC/ST/OBC students with family income ≤₹2.5L.",
    link: "https://chandigarh.gov.in/",
    tags: ["SC/ST/OBC", "Comprehensive", "UT"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Chandigarh Domicile"],
    incomeLimit: "₹2.5 lakh",
  },
  {
    id: 61,
    title: "Chandigarh Merit Scholarship",
    state: "Chandigarh",
    provider: "UT Administration Chandigarh",
    amount: "₹50,000 per year",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "75% marks", "Chandigarh domicile"],
    type: "Merit-based",
    description: "Merit scholarship for Chandigarh students with 75% marks and family income ≤₹8L.",
    link: "https://chandigarh.gov.in/",
    tags: ["Merit", "UT", "75% marks"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "Chandigarh Domicile"],
    incomeLimit: "₹8 lakh",
  },

  // Dadra & Nagar Haveli and Daman & Diu
  {
    id: 62,
    title: "DNH & DD Post-Matric Scholarship",
    state: "Dadra & Nagar Haveli and Daman & Diu",
    provider: "UT Administration DNH & DD",
    amount: "₹1,500/month + Tuition + Special allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "DNH & DD domicile"],
    type: "Need-based",
    description: "Enhanced support with special allowance for tribal and coastal area students. Income ≤₹2.5L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Special Allowance", "Tribal", "Coastal"],
    category: "Social Welfare",
    documents: ["Tribal Certificate", "Income Certificate", "DNH & DD Domicile"],
    incomeLimit: "₹2.5 lakh",
  },
  {
    id: 63,
    title: "DNH & DD Merit Scholarship",
    state: "Dadra & Nagar Haveli and Daman & Diu",
    provider: "UT Administration DNH & DD",
    amount: "₹60,000 per year",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "70% marks", "DNH & DD domicile"],
    type: "Merit-based",
    description: "Merit scholarship for UT students with 70% marks and family income ≤₹6L.",
    link: "https://scholarships.gov.in/",
    tags: ["Merit", "UT", "70% marks"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "DNH & DD Domicile"],
    incomeLimit: "₹6 lakh",
  },

  // Lakshadweep
  {
    id: 64,
    title: "Lakshadweep Post-Matric Scholarship",
    state: "Lakshadweep",
    provider: "UT Administration Lakshadweep",
    amount: "₹3,000/month + Tuition + Island allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "ST/SC/OBC", "Lakshadweep domicile"],
    type: "Need-based",
    description: "Premium support with island allowance for remote island students. Income ≤₹4L.",
    link: "https://scholarships.gov.in/",
    tags: ["ST/SC/OBC", "Island Allowance", "Remote Island", "Premium"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Lakshadweep Domicile"],
    incomeLimit: "₹4 lakh",
  },
  {
    id: 65,
    title: "Lakshadweep Merit Scholarship",
    state: "Lakshadweep",
    provider: "UT Administration Lakshadweep",
    amount: "₹1,50,000 per year + Special support",
    deadline: "2025-11-30",
    eligibility: ["All Years", "All Branches", "65% marks", "Lakshadweep domicile"],
    type: "Merit-based",
    description: "Premium merit scholarship with special support for island students with 65% marks.",
    link: "https://scholarships.gov.in/",
    tags: ["Merit", "Island Students", "Special Support", "Premium"],
    category: "Regional Development",
    documents: ["Mark Sheets", "Income Certificate", "Lakshadweep Domicile"],
    incomeLimit: "₹20 lakh",
  },

  // Puducherry
  {
    id: 66,
    title: "Puducherry Post-Matric Scholarship Enhanced",
    state: "Puducherry",
    provider: "Government of Puducherry",
    amount: "Tuition + ₹1,200/month + Coastal allowance",
    deadline: "2025-12-31",
    eligibility: ["All Years", "All Branches", "SC/ST/OBC"],
    type: "Need-based",
    description: "Enhanced support with coastal area allowance. Income limits: SC/ST ≤₹2.5L, OBC ≤₹1.5L.",
    link: "https://py.gov.in/",
    tags: ["SC/ST/OBC", "Coastal Allowance", "Enhanced"],
    category: "Social Welfare",
    documents: ["Caste Certificate", "Income Certificate", "Puducherry Domicile"],
    incomeLimit: "SC/ST: ₹2.5L, OBC: ₹1.5L",
  },
  {
    id: 67,
    title: "Puducherry Engineering Merit Award",
    state: "Puducherry",
    provider: "Government of Puducherry",
    amount: "₹80,000 per year + Industry training",
    deadline: "2025-11-30",
    eligibility: ["All Years", "Engineering", "75% marks"],
    type: "Merit-based",
    description: "Merit award for engineering students with industry training and placement assistance.",
    link: "https://py.gov.in/",
    tags: ["Engineering", "Merit", "Industry Training", "Placement"],
    category: "Merit Excellence",
    documents: ["Mark Sheets", "Engineering Admission", "Income Certificate"],
    incomeLimit: "₹10 lakh",
  },
]

export default function StateScholarshipsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedState, setSelectedState] = useState("all")
  const [selectedType, setSelectedType] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const filteredScholarships = useMemo(() => {
    return stateScholarships.filter((scholarship) => {
      const matchesSearch =
        scholarship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        scholarship.state.toLowerCase().includes(searchTerm.toLowerCase()) ||
        scholarship.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        scholarship.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

      const matchesState = selectedState === "all" || scholarship.state === selectedState
      const matchesType = selectedType === "all" || scholarship.type === selectedType
      const matchesCategory = selectedCategory === "all" || scholarship.category === selectedCategory

      return matchesSearch && matchesState && matchesType && matchesCategory
    })
  }, [searchTerm, selectedState, selectedType, selectedCategory])

  const uniqueStates = [...new Set(stateScholarships.map((s) => s.state))].sort()
  const uniqueCategories = [...new Set(stateScholarships.map((s) => s.category))].sort()

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 dark:from-gray-900 dark:via-emerald-900 dark:to-teal-900">
      {/* Navigation */}
      <nav className="border-b bg-white/90 dark:bg-gray-900/90 backdrop-blur-md sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-lg flex items-center justify-center shadow-lg">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400">EduOpportunity</span>
              </Link>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-600 dark:text-gray-300 hover:text-emerald-600 transition-colors">
                Home
              </Link>
              <Link
                href="/scholarships"
                className="text-gray-600 dark:text-gray-300 hover:text-emerald-600 transition-colors"
              >
                Scholarships
              </Link>
              <Link
                href="/internships"
                className="text-gray-600 dark:text-gray-300 hover:text-emerald-600 transition-colors"
              >
                Internships
              </Link>
              <Link
                href="/state-scholarships"
                className="text-gray-900 dark:text-white hover:text-emerald-600 transition-colors font-medium border-b-2 border-emerald-500"
              >
                State Scholarships
              </Link>
            </div>

            <Button
              asChild
              className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg"
            >
              <Link href="/scholarships">All Scholarships</Link>
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <Badge className="mb-4 bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-800 border-emerald-200 shadow-sm">
            <MapPin className="w-4 h-4 mr-1" />
            State Government Scholarships 2025-26
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-emerald-600 dark:text-emerald-400 mb-4 text-balance">
            Complete Guide to State Scholarships for B.Tech Students
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-6 text-pretty">
            Discover {stateScholarships.length}+ comprehensive state government scholarship opportunities across all
            Indian states
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <div className="flex items-center bg-white/80 dark:bg-gray-800/80 px-4 py-2 rounded-full shadow-sm">
              <Users className="w-4 h-4 mr-2 text-emerald-600" />
              <span className="font-medium">All Categories Covered</span>
            </div>
            <div className="flex items-center bg-white/80 dark:bg-gray-800/80 px-4 py-2 rounded-full shadow-sm">
              <GraduationCap className="w-4 h-4 mr-2 text-teal-600" />
              <span className="font-medium">B.Tech Focused</span>
            </div>
            <div className="flex items-center bg-white/80 dark:bg-gray-800/80 px-4 py-2 rounded-full shadow-sm">
              <FileText className="w-4 h-4 mr-2 text-cyan-600" />
              <span className="font-medium">Complete Application Guide</span>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-md rounded-xl border border-emerald-200 p-6 mb-8 shadow-xl">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {/* Search */}
            <div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-emerald-500 w-4 h-4" />
                <Input
                  placeholder="Search state scholarships..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-emerald-200 focus:border-emerald-400 focus:ring-emerald-400"
                />
              </div>
            </div>

            {/* State Filter */}
            <Select value={selectedState} onValueChange={setSelectedState}>
              <SelectTrigger className="border-emerald-200 focus:border-emerald-400">
                <SelectValue placeholder="Select State" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All States ({uniqueStates.length})</SelectItem>
                {uniqueStates.map((state) => (
                  <SelectItem key={state} value={state}>
                    {state}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Type Filter */}
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="border-emerald-200 focus:border-emerald-400">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Merit-based">Merit-based</SelectItem>
                <SelectItem value="Need-based">Need-based</SelectItem>
                <SelectItem value="Merit-cum-Need">Merit-cum-Need</SelectItem>
              </SelectContent>
            </Select>

            {/* Category Filter */}
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="border-emerald-200 focus:border-emerald-400">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {uniqueCategories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between mt-6 pt-4 border-t border-emerald-200">
            <div className="text-sm text-gray-600 dark:text-gray-300">
              Showing <span className="font-semibold text-emerald-600">{filteredScholarships.length}</span> of{" "}
              <span className="font-semibold">{stateScholarships.length}</span> state scholarships
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSearchTerm("")
                setSelectedState("all")
                setSelectedType("all")
                setSelectedCategory("all")
              }}
              className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"
            >
              Clear Filters
            </Button>
          </div>
        </div>

        {/* Scholarship Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredScholarships.map((scholarship) => (
            <Card
              key={scholarship.id}
              className="hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-0 shadow-lg hover:shadow-emerald-200/50 dark:hover:shadow-emerald-900/50"
            >
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge
                        variant="outline"
                        className="bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-800 border-emerald-200 shadow-sm"
                      >
                        <MapPin className="w-3 h-3 mr-1" />
                        {scholarship.state}
                      </Badge>
                      <Badge
                        variant={
                          scholarship.type === "Merit-based"
                            ? "default"
                            : scholarship.type === "Merit-cum-Need"
                              ? "secondary"
                              : "outline"
                        }
                        className={
                          scholarship.type === "Merit-based"
                            ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm border-0"
                            : scholarship.type === "Merit-cum-Need"
                              ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-sm border-0"
                              : "bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm border-0"
                        }
                      >
                        {scholarship.type}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg mb-2 text-balance text-gray-900 dark:text-white leading-tight">
                      {scholarship.title}
                    </CardTitle>
                    <CardDescription className="flex items-center text-sm mb-2 text-gray-600 dark:text-gray-300">
                      <Building className="w-4 h-4 mr-1 flex-shrink-0" />
                      <span className="text-pretty">{scholarship.provider}</span>
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                <div className="space-y-4">
                  <p className="text-sm text-gray-600 dark:text-gray-300 text-pretty leading-relaxed">
                    {scholarship.description}
                  </p>

                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex items-center justify-between text-sm bg-emerald-50 dark:bg-emerald-900/20 p-3 rounded-lg">
                      <div className="flex items-center text-emerald-700 dark:text-emerald-300 font-semibold">
                        <IndianRupee className="w-4 h-4 mr-1" />
                        <span className="text-xs">Amount</span>
                      </div>
                      <div className="text-emerald-800 dark:text-emerald-200 font-medium text-right text-xs">
                        {scholarship.amount}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm bg-orange-50 dark:bg-orange-900/20 p-3 rounded-lg">
                      <div className="flex items-center text-orange-700 dark:text-orange-300 font-semibold">
                        <Calendar className="w-4 h-4 mr-1" />
                        <span className="text-xs">Deadline</span>
                      </div>
                      <div className="text-orange-800 dark:text-orange-200 font-medium text-xs">
                        {new Date(scholarship.deadline).toLocaleDateString()}
                      </div>
                    </div>

                    {scholarship.incomeLimit && (
                      <div className="flex items-center justify-between text-sm bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                        <div className="flex items-center text-blue-700 dark:text-blue-300 font-semibold">
                          <IndianRupee className="w-4 h-4 mr-1" />
                          <span className="text-xs">Income Limit</span>
                        </div>
                        <div className="text-blue-800 dark:text-blue-200 font-medium text-xs">
                          {scholarship.incomeLimit}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">Eligibility:</div>
                    <div className="flex flex-wrap gap-1">
                      {scholarship.eligibility.map((item, index) => (
                        <Badge
                          key={index}
                          variant="outline"
                          className="text-xs border-emerald-200 text-emerald-700 bg-emerald-50/50"
                        >
                          {item}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">Required Documents:</div>
                    <div className="flex flex-wrap gap-1">
                      {scholarship.documents?.map((doc, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="text-xs bg-gradient-to-r from-teal-100 to-cyan-100 text-teal-700 border-teal-200"
                        >
                          {doc}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {scholarship.tags.map((tag, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="text-xs bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <Button
                    asChild
                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-lg hover:shadow-xl transition-all duration-300 text-white"
                  >
                    <a href={scholarship.link} target="_blank" rel="noopener noreferrer" className="text-white">
                      Apply Now
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredScholarships.length === 0 && (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Search className="w-10 h-10 text-emerald-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">No state scholarships found</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6 text-pretty max-w-md mx-auto">
              Try adjusting your filters or search terms to discover more scholarship opportunities across Indian
              states.
            </p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchTerm("")
                setSelectedState("all")
                setSelectedType("all")
                setSelectedCategory("all")
              }}
              className="border-emerald-300 text-emerald-700 hover:bg-emerald-50 shadow-sm"
            >
              Clear All Filters
            </Button>
          </div>
        )}

        <div className="mt-16 bg-white/90 dark:bg-gray-800/90 backdrop-blur-md rounded-xl border border-emerald-200 p-8 shadow-xl">
          <h2 className="text-2xl font-bold text-center mb-6 bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
            Complete Application Guide
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Common Required Documents</h3>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-3"></span>Income Certificate (recent and
                  authorized)
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-3"></span>Caste/Community Certificate (if
                  applicable)
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-3"></span>Domicile/Resident Certificate
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-3"></span>Last Passed Examination Marksheet
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-3"></span>Admission letter/fee receipt
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-3"></span>Bank Passbook (student's account)
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-3"></span>Aadhaar Card & Photograph
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Typical Application Steps</h3>
              <ol className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <li className="flex items-start">
                  <span className="bg-emerald-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">
                    1
                  </span>
                  Read eligibility and scheme guidelines
                </li>
                <li className="flex items-start">
                  <span className="bg-emerald-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">
                    2
                  </span>
                  Register on the official portal (OTP/email verification)
                </li>
                <li className="flex items-start">
                  <span className="bg-emerald-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">
                    3
                  </span>
                  Fill personal, academic, family, and income details
                </li>
                <li className="flex items-start">
                  <span className="bg-emerald-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">
                    4
                  </span>
                  Upload required scanned documents
                </li>
                <li className="flex items-start">
                  <span className="bg-emerald-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">
                    5
                  </span>
                  Submit application and download/print form
                </li>
                <li className="flex items-start">
                  <span className="bg-emerald-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">
                    6
                  </span>
                  College/institutional verification and forwarding
                </li>
                <li className="flex items-start">
                  <span className="bg-emerald-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">
                    7
                  </span>
                  Track application status and receive DBT payout
                </li>
              </ol>
            </div>
          </div>

          <div className="mt-8 p-4 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20 rounded-lg border border-emerald-200">
            <h4 className="font-semibold text-emerald-800 dark:text-emerald-200 mb-2">Important Notes:</h4>
            <ul className="text-sm text-emerald-700 dark:text-emerald-300 space-y-1">
              <li>• Applications typically open between July and December</li>
              <li>• Renewal required for subsequent academic years with updated marksheets</li>
              <li>• Only one government scholarship of the same type permitted per academic year</li>
              <li>• BTech lateral entry students are generally eligible if they meet other criteria</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
