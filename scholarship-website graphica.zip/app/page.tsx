"use client"

import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  BookOpen,
  Briefcase,
  Users,
  TrendingUp,
  Clock,
  Award,
  MapPin,
  Sparkles,
  GraduationCap,
  Star,
  Calendar,
} from "lucide-react"
import Link from "next/link"
import { Suspense, useEffect, useState } from "react"
import dynamic from "next/dynamic"
import TestimonialSection from "@/components/testimonial-section"
import Sidebar from "@/components/sidebar"

const Scene3D = dynamic(() => import("@/components/3d-scene"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full bg-gradient-to-br from-purple-400/20 to-cyan-400/20 rounded-lg animate-pulse" />
  ),
})

export default function HomePage() {
  const [mounted, setMounted] = useState(false)
  const [activeTab, setActiveTab] = useState("scholarships")

  useEffect(() => {
    setMounted(true)
  }, [])

  const scholarships = [
    {
      title: "Merit-based Scholarship",
      amount: "₹50,000",
      deadline: "March 15, 2025",
      eligibility: "CGPA > 8.0",
      type: "Merit",
      category: "Academic Excellence",
    },
    {
      title: "Need-based Financial Aid",
      amount: "₹75,000",
      deadline: "April 10, 2025",
      eligibility: "Family Income < ₹3L",
      type: "Need-based",
      category: "Financial Support",
    },
    {
      title: "Research Excellence Grant",
      amount: "₹1,00,000",
      deadline: "May 20, 2025",
      eligibility: "Research Publications",
      type: "Research",
      category: "Innovation",
    },
    // Government Scholarships
    {
      title: "National Scholarship Portal (NSP)",
      amount: "₹12,000 - ₹2,00,000",
      deadline: "March 31, 2025",
      eligibility: "All Categories, Income Based",
      type: "Government",
      category: "Central Government",
    },
    {
      title: "AICTE Pragati Scholarship",
      amount: "₹30,000/year",
      deadline: "February 28, 2025",
      eligibility: "Girl Students, Family Income < ₹8L",
      type: "Government",
      category: "Women Empowerment",
    },
    {
      title: "AICTE Saksham Scholarship",
      amount: "₹50,000/year",
      deadline: "February 28, 2025",
      eligibility: "Differently Abled Students",
      type: "Government",
      category: "Disability Support",
    },
    {
      title: "UGC Merit Scholarship",
      amount: "₹500/month",
      deadline: "April 15, 2025",
      eligibility: "Top 2% in Class XII",
      type: "Government",
      category: "Merit Based",
    },
    {
      title: "INSPIRE Scholarship (DST)",
      amount: "₹80,000/year + ₹20,000 Mentorship",
      deadline: "July 31, 2025",
      eligibility: "Top 1% in Class XII Science",
      type: "Government",
      category: "Science Excellence",
    },
    {
      title: "Post Matric Scholarship SC/ST",
      amount: "₹2,30,000/year",
      deadline: "March 31, 2025",
      eligibility: "SC/ST Students, Income < ₹2.5L",
      type: "Government",
      category: "Social Welfare",
    },
    {
      title: "OBC Post Matric Scholarship",
      amount: "₹1,60,000/year",
      deadline: "March 31, 2025",
      eligibility: "OBC Students, Income < ₹1L",
      type: "Government",
      category: "Social Welfare",
    },
    {
      title: "Minority Affairs Scholarship",
      amount: "₹1,20,000/year",
      deadline: "December 31, 2024",
      eligibility: "Minority Community Students",
      type: "Government",
      category: "Minority Welfare",
    },
    {
      title: "KVPY Fellowship",
      amount: "₹7,000/month + ₹28,000 Annual",
      deadline: "September 15, 2025",
      eligibility: "Science Stream, Aptitude Test",
      type: "Government",
      category: "Research Excellence",
    },
    {
      title: "Prime Minister's Scholarship",
      amount: "₹25,000/year",
      deadline: "June 30, 2025",
      eligibility: "Armed Forces Personnel Children",
      type: "Government",
      category: "Defense Personnel",
    },

    // Private Scholarships - Corporate
    {
      title: "Tata Scholarship Program",
      amount: "₹2,00,000/year",
      deadline: "May 31, 2025",
      eligibility: "Merit + Need, Family Income < ₹4L",
      type: "Private",
      category: "Corporate CSR",
    },
    {
      title: "Reliance Foundation Scholarship",
      amount: "₹2,00,000/year",
      deadline: "April 30, 2025",
      eligibility: "JEE Advanced Qualified, Income < ₹6L",
      type: "Private",
      category: "Corporate CSR",
    },
    {
      title: "Aditya Birla Scholarship",
      amount: "₹1,75,000/year",
      deadline: "June 15, 2025",
      eligibility: "Top IIT/NIT Students",
      type: "Private",
      category: "Corporate CSR",
    },
    {
      title: "Bajaj Auto Scholarship",
      amount: "₹1,50,000/year",
      deadline: "March 15, 2025",
      eligibility: "Engineering Students, Merit Based",
      type: "Private",
      category: "Corporate CSR",
    },
    {
      title: "L&T Build India Scholarship",
      amount: "₹1,50,000/year",
      deadline: "July 31, 2025",
      eligibility: "Civil/Mechanical Engineering",
      type: "Private",
      category: "Industry Specific",
    },
    {
      title: "Infosys Foundation Scholarship",
      amount: "₹1,00,000/year",
      deadline: "August 31, 2025",
      eligibility: "Computer Science/IT Students",
      type: "Private",
      category: "Technology Focus",
    },
    {
      title: "TCS Scholarship Program",
      amount: "₹80,000/year",
      deadline: "September 30, 2025",
      eligibility: "Engineering Students, All Branches",
      type: "Private",
      category: "Technology Focus",
    },
    {
      title: "Wipro Scholarship",
      amount: "₹1,20,000/year",
      deadline: "June 30, 2025",
      eligibility: "STEM Students, Merit + Need",
      type: "Private",
      category: "Technology Focus",
    },
    {
      title: "HDFC Bank Educational Crisis Scholarship",
      amount: "₹75,000/year",
      deadline: "December 31, 2024",
      eligibility: "Financial Crisis, Merit Based",
      type: "Private",
      category: "Financial Support",
    },
    {
      title: "Mahindra Scholarship",
      amount: "₹2,00,000/year",
      deadline: "May 15, 2025",
      eligibility: "Automotive/Mechanical Engineering",
      type: "Private",
      category: "Industry Specific",
    },

    // Private Scholarships - Foundations
    {
      title: "Kishore Vaigyanik Protsahan Yojana",
      amount: "₹7,000/month",
      deadline: "November 30, 2024",
      eligibility: "Science Students, Research Aptitude",
      type: "Private",
      category: "Research Foundation",
    },
    {
      title: "JN Tata Endowment Scholarship",
      amount: "Up to ₹10,00,000",
      deadline: "March 31, 2025",
      eligibility: "Higher Studies Abroad",
      type: "Private",
      category: "International Studies",
    },
    {
      title: "K.C. Mahindra Scholarship",
      amount: "Up to ₹5,00,000",
      deadline: "June 30, 2025",
      eligibility: "Post Graduate Studies Abroad",
      type: "Private",
      category: "International Studies",
    },
    {
      title: "Narotam Sekhsaria Foundation",
      amount: "₹2,00,000/year",
      deadline: "April 15, 2025",
      eligibility: "Engineering Students, Merit Based",
      type: "Private",
      category: "Educational Foundation",
    },
    {
      title: "Sitaram Jindal Foundation",
      amount: "₹48,000/year",
      deadline: "July 31, 2025",
      eligibility: "Meritorious Students, All Branches",
      type: "Private",
      category: "Educational Foundation",
    },
    {
      title: "Ratan Tata Trust Scholarship",
      amount: "₹2,00,000/year",
      deadline: "May 31, 2025",
      eligibility: "Cornell University Students",
      type: "Private",
      category: "International Partnership",
    },
    {
      title: "Inlaks Scholarship",
      amount: "Up to $1,00,000",
      deadline: "January 31, 2025",
      eligibility: "Studies in USA/Europe",
      type: "Private",
      category: "International Studies",
    },
    {
      title: "Azim Premji Foundation Scholarship",
      amount: "₹1,20,000/year",
      deadline: "June 15, 2025",
      eligibility: "Rural Background Students",
      type: "Private",
      category: "Social Impact",
    },

    // Year-specific Scholarships
    {
      title: "First Year Merit Scholarship",
      amount: "₹25,000",
      deadline: "October 31, 2024",
      eligibility: "JEE Main Score > 95 percentile",
      type: "Merit",
      category: "First Year Only",
    },
    {
      title: "Second Year Excellence Award",
      amount: "₹40,000",
      deadline: "August 31, 2025",
      eligibility: "CGPA > 8.5 in First Year",
      type: "Merit",
      category: "Second Year Only",
    },
    {
      title: "Third Year Innovation Grant",
      amount: "₹60,000",
      deadline: "September 30, 2025",
      eligibility: "Project/Research Work",
      type: "Innovation",
      category: "Third Year Only",
    },
    {
      title: "Final Year Placement Support",
      amount: "₹50,000",
      deadline: "November 30, 2024",
      eligibility: "Job Search Support",
      type: "Career",
      category: "Final Year Only",
    },

    // Branch-specific Scholarships
    {
      title: "Computer Science Excellence",
      amount: "₹1,00,000/year",
      deadline: "July 15, 2025",
      eligibility: "CS/IT Students, Coding Skills",
      type: "Branch Specific",
      category: "Computer Science",
    },
    {
      title: "Mechanical Engineering Innovation",
      amount: "₹80,000/year",
      deadline: "August 15, 2025",
      eligibility: "Mechanical Engineering Students",
      type: "Branch Specific",
      category: "Mechanical Engineering",
    },
    {
      title: "Electrical Engineering Scholarship",
      amount: "₹75,000/year",
      deadline: "September 15, 2025",
      eligibility: "Electrical/Electronics Students",
      type: "Branch Specific",
      category: "Electrical Engineering",
    },
    {
      title: "Civil Engineering Development",
      amount: "₹70,000/year",
      deadline: "June 30, 2025",
      eligibility: "Civil Engineering Students",
      type: "Branch Specific",
      category: "Civil Engineering",
    },
    {
      title: "Chemical Engineering Research",
      amount: "₹85,000/year",
      deadline: "July 31, 2025",
      eligibility: "Chemical Engineering Students",
      type: "Branch Specific",
      category: "Chemical Engineering",
    },
  ]

  const internships = [
    {
      title: "Software Development Intern",
      company: "Tech Corp",
      duration: "3 months",
      stipend: "₹25,000/month",
      location: "Bangalore",
      skills: "React, Node.js",
    },
    {
      title: "Data Science Intern",
      company: "Analytics Pro",
      duration: "6 months",
      stipend: "₹30,000/month",
      location: "Hyderabad",
      skills: "Python, ML",
    },
    {
      title: "Product Management Intern",
      company: "StartupX",
      duration: "4 months",
      stipend: "₹20,000/month",
      location: "Mumbai",
      skills: "Strategy, Analytics",
    },
  ]

  const stateScholarships = [
    {
      title: "Karnataka State Merit Scholarship",
      amount: "₹40,000",
      deadline: "March 30, 2025",
      eligibility: "Karnataka Domicile",
      state: "Karnataka",
    },
    {
      title: "Tamil Nadu Excellence Award",
      amount: "₹60,000",
      deadline: "April 15, 2025",
      eligibility: "Tamil Nadu Resident",
      state: "Tamil Nadu",
    },
    {
      title: "Maharashtra Innovation Grant",
      amount: "₹80,000",
      deadline: "May 5, 2025",
      eligibility: "Maharashtra Student",
      state: "Maharashtra",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/30">
      <Sidebar />

      <div className="md:ml-64">
        <nav className="glassmorphism bg-white/80 dark:bg-slate-900/80 border-b border-border/50 sticky top-0 z-50 backdrop-blur-xl">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              {/* Logo */}
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-primary">EduOpportunity</span>
              </div>

              {/* Navigation Links */}
              <div className="hidden md:flex items-center space-x-8 flex-1 justify-center">
                <Link href="/" className="text-foreground hover:text-primary transition-colors font-medium">
                  Home
                </Link>
                <Link href="/scholarships" className="text-muted-foreground hover:text-primary transition-colors">
                  Scholarships
                </Link>
                <Link href="/internships" className="text-muted-foreground hover:text-primary transition-colors">
                  Internships
                </Link>
                <Link href="/state-scholarships" className="text-muted-foreground hover:text-primary transition-colors">
                  State Scholarships
                </Link>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  About
                </Link>
              </div>

              {/* Browse Internships Button */}
              <Button
                variant="outline"
                asChild
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
              >
                <Link href="/internships">Browse Internships</Link>
              </Button>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-r from-primary/30 to-purple-500/30 rounded-full blur-3xl float-animation"></div>
            <div
              className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-r from-cyan-400/30 to-blue-500/30 rounded-full blur-3xl float-animation"
              style={{ animationDelay: "2s" }}
            ></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-gradient-to-r from-orange-400/20 to-pink-500/20 rounded-full blur-3xl rotate-animation"></div>
          </div>

          <div className="max-w-7xl mx-auto relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="text-center lg:text-left">
                <Badge
                  variant="secondary"
                  className="mb-6 glassmorphism bg-primary/80 text-white border-primary/20 pulse-glow"
                >
                  <Sparkles className="w-4 h-4 mr-1" />
                  For B.Tech Students - All Years
                </Badge>

                <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
                  Your Gateway to
                  <span className="block text-primary mt-2">Scholarships & Internships</span>
                </h1>

                <p className="text-xl text-muted-foreground mb-8 max-w-2xl text-pretty">
                  Experience the future of opportunity discovery with our interactive 3D platform designed specifically
                  for B.Tech students.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
                  <Button
                    size="lg"
                    asChild
                    className="text-lg px-8 bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl pulse-glow"
                  >
                    <Link href="/dashboard">
                      <Search className="w-5 h-5 mr-2" />
                      Get Started
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    asChild
                    className="text-lg px-8 glassmorphism border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground shadow-xl bg-transparent"
                  >
                    <Link href="/resume">
                      <Briefcase className="w-5 h-5 mr-2" />
                      Build Resume
                    </Link>
                  </Button>
                </div>
              </div>

              <div className="h-96 lg:h-[500px] relative">
                {mounted && (
                  <Suspense
                    fallback={
                      <div className="w-full h-full glassmorphism bg-gradient-to-br from-primary/10 to-cyan-400/10 rounded-2xl flex items-center justify-center">
                        <div className="text-center">
                          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4 mx-auto animate-pulse">
                            <GraduationCap className="w-8 h-8 text-primary" />
                          </div>
                          <p className="text-muted-foreground">Loading 3D Experience...</p>
                        </div>
                      </div>
                    }
                  >
                    <div className="w-full h-full glassmorphism rounded-2xl overflow-hidden">
                      <Scene3D />
                    </div>
                  </Suspense>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Explore Opportunities Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Explore Opportunities</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Discover scholarships, internships, and state-specific opportunities tailored for B.Tech students.
              </p>
            </div>

            <div className="text-center mb-12">
              <div className="glassmorphism bg-card/60 p-8 rounded-2xl shadow-lg max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-purple-600 rounded-full flex items-center justify-center mb-6 mx-auto pulse-glow">
                  <Search className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Browse All Opportunities</h3>
                <p className="text-muted-foreground mb-6">
                  Access our comprehensive database of {scholarships.length}+ scholarships, internships, and
                  state-specific opportunities with advanced filtering and search capabilities.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    size="lg"
                    asChild
                    className="text-lg px-8 bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl pulse-glow"
                  >
                    <Link href="/scholarships">
                      <Award className="w-5 h-5 mr-2" />
                      Browse All Scholarships
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    asChild
                    className="text-lg px-8 glassmorphism border-orange-500/30 text-orange-600 hover:bg-orange-500 hover:text-white shadow-xl bg-transparent"
                  >
                    <Link href="/internships">
                      <Briefcase className="w-5 h-5 mr-2" />
                      Browse All Internships
                    </Link>
                  </Button>
                </div>
              </div>
            </div>

            <div className="mb-12">
              <h3 className="text-2xl font-bold text-foreground text-center mb-8">Featured Opportunities</h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Featured Scholarships */}
                {scholarships.slice(0, 3).map((scholarship, index) => (
                  <Card
                    key={index}
                    className="glassmorphism bg-card/60 border-primary/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <Badge variant="secondary" className="bg-primary/10 text-primary border border-primary/20">
                          {scholarship.type}
                        </Badge>
                        <div className="text-right">
                          <div className="text-lg font-bold text-primary">{scholarship.amount}</div>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{scholarship.title}</CardTitle>
                      <CardDescription className="space-y-2">
                        <div className="flex items-center text-sm">
                          <Calendar className="w-4 h-4 mr-2 text-orange-500" />
                          Deadline: {scholarship.deadline}
                        </div>
                        <div className="flex items-center text-sm">
                          <Star className="w-4 h-4 mr-2 text-yellow-500" />
                          {scholarship.eligibility}
                        </div>
                        <div className="text-xs text-muted-foreground">{scholarship.category}</div>
                      </CardDescription>
                      <Button asChild className="w-full mt-4">
                        <Link href="/dashboard">Apply Now</Link>
                      </Button>
                    </CardHeader>
                  </Card>
                ))}

                {/* Featured Internships */}
                {internships.slice(0, 2).map((internship, index) => (
                  <Card
                    key={`internship-${index}`}
                    className="glassmorphism bg-card/60 border-orange-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <Badge
                          variant="secondary"
                          className="bg-orange-50 text-orange-700 border border-orange-200 dark:bg-orange-950 dark:text-orange-300 dark:border-orange-800"
                        >
                          {internship.duration}
                        </Badge>
                        <div className="text-right">
                          <div className="text-lg font-bold text-orange-600">{internship.stipend}</div>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{internship.title}</CardTitle>
                      <CardDescription className="space-y-2">
                        <div className="font-medium text-foreground">{internship.company}</div>
                        <div className="flex items-center text-sm">
                          <MapPin className="w-4 h-4 mr-2 text-blue-500" />
                          {internship.location}
                        </div>
                        <div className="text-xs text-muted-foreground">Skills: {internship.skills}</div>
                      </CardDescription>
                      <Button asChild className="w-full mt-4 bg-orange-500 hover:bg-orange-600">
                        <Link href="/dashboard">Apply Now</Link>
                      </Button>
                    </CardHeader>
                  </Card>
                ))}

                {/* Featured State Scholarship */}
                {stateScholarships.slice(0, 1).map((scholarship, index) => (
                  <Card
                    key={`state-${index}`}
                    className="glassmorphism bg-card/60 border-cyan-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <Badge
                          variant="secondary"
                          className="bg-cyan-50 text-cyan-700 border border-cyan-200 dark:bg-cyan-950 dark:text-cyan-300 dark:border-cyan-800"
                        >
                          {scholarship.state}
                        </Badge>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-cyan-600">{scholarship.amount}</div>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{scholarship.title}</CardTitle>
                      <CardDescription className="space-y-2">
                        <div className="flex items-center text-sm">
                          <Calendar className="w-4 h-4 mr-2 text-orange-500" />
                          Deadline: {scholarship.deadline}
                        </div>
                        <div className="flex items-center text-sm">
                          <Star className="w-4 h-4 mr-2 text-yellow-500" />
                          {scholarship.eligibility}
                        </div>
                      </CardDescription>
                      <Button asChild className="w-full mt-4 bg-cyan-500 hover:bg-cyan-600">
                        <Link href="/dashboard">Apply Now</Link>
                      </Button>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </div>

            <div className="text-center">
              <div className="glassmorphism bg-gradient-to-r from-primary/10 to-purple-600/10 p-8 rounded-2xl">
                <h3 className="text-xl font-bold text-foreground mb-4">Want to See More?</h3>
                <p className="text-muted-foreground mb-6">
                  Explore our complete database with advanced filters for year, branch, type, and location.
                </p>
                <Button
                  asChild
                  size="lg"
                  className="glassmorphism bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl"
                >
                  <Link href="/scholarships">
                    <Search className="w-5 h-5 mr-2" />
                    Browse All {scholarships.length}+ Opportunities
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose EduOpportunity Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 glassmorphism bg-card/30">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Why Choose EduOpportunity?</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Experience the future of opportunity discovery with our cutting-edge platform.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="glassmorphism bg-card/60 border-primary/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-primary to-purple-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-primary">Save Time</CardTitle>
                  <CardDescription>
                    No more browsing multiple websites. Everything you need in one futuristic platform.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="glassmorphism bg-card/60 border-orange-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-orange-600 dark:text-orange-400">Always Updated</CardTitle>
                  <CardDescription>Fresh opportunities added daily with real-time notifications.</CardDescription>
                </CardHeader>
              </Card>

              <Card className="glassmorphism bg-card/60 border-cyan-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-cyan-600 dark:text-cyan-400">B.Tech Focused</CardTitle>
                  <CardDescription>
                    AI-curated opportunities specifically for B.Tech students across all branches.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="glassmorphism bg-card/60 border-green-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                    <Search className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-green-600 dark:text-green-400">Smart Filters</CardTitle>
                  <CardDescription>Advanced AI-powered filtering to find your perfect match instantly.</CardDescription>
                </CardHeader>
              </Card>

              <Card className="glassmorphism bg-card/60 border-pink-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-rose-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-pink-600 dark:text-pink-400">Verified Opportunities</CardTitle>
                  <CardDescription>
                    All opportunities are AI-verified and constantly monitored for authenticity.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="glassmorphism bg-card/60 border-indigo-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 hover:-translate-y-2">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                    <Briefcase className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-indigo-600 dark:text-indigo-400">Direct Access</CardTitle>
                  <CardDescription>
                    One-click application process with integrated tracking and reminders.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>

        {/* Testimonial Section */}
        <TestimonialSection />

        {/* Ready to Experience the Future Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-purple-600/10 to-cyan-600/10"></div>
          <div className="max-w-4xl mx-auto text-center relative">
            <div className="glassmorphism bg-card/40 p-12 rounded-3xl shadow-2xl">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Ready to Experience the Future?</h2>
              <p className="text-xl text-muted-foreground mb-8">
                Join the next generation of B.Tech students discovering opportunities through our revolutionary
                platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  asChild
                  className="text-lg px-8 bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl pulse-glow"
                >
                  <Link href="/dashboard">Start Your Journey</Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  asChild
                  className="text-lg px-8 glassmorphism border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground shadow-xl bg-transparent"
                >
                  <Link href="/resume">Build Resume</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Footer Section */}
        <footer className="glassmorphism bg-card/60 border-t border-border/50 py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="grid md:grid-cols-4 gap-8">
              <div>
                <div className="flex items-center space-x-2 mb-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-xl font-bold text-foreground">EduOpportunity</span>
                </div>
                <p className="text-muted-foreground">Your one-stop platform for B.Tech scholarships and internships.</p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-4">Quick Links</h3>
                <div className="space-y-2">
                  <Link href="/dashboard" className="block text-muted-foreground hover:text-primary transition-colors">
                    Dashboard
                  </Link>
                  <Link href="/resume" className="block text-muted-foreground hover:text-primary transition-colors">
                    Resume Builder
                  </Link>
                  <Link
                    href="/financial-aid"
                    className="block text-muted-foreground hover:text-primary transition-colors"
                  >
                    Financial Aid
                  </Link>
                  <Link href="/community" className="block text-muted-foreground hover:text-primary transition-colors">
                    Community
                  </Link>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-4">Categories</h3>
                <div className="space-y-2">
                  <div className="text-muted-foreground">Merit-based</div>
                  <div className="text-muted-foreground">Need-based</div>
                  <div className="text-muted-foreground">Research</div>
                  <div className="text-muted-foreground">Industry</div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-4">Support</h3>
                <div className="space-y-2">
                  <div className="text-muted-foreground">Help Center</div>
                  <div className="text-muted-foreground">Contact Us</div>
                  <div className="text-muted-foreground">Privacy Policy</div>
                  <div className="text-muted-foreground">Terms of Service</div>
                </div>
              </div>
            </div>

            <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
              <p>&copy; 2025 EduOpportunity. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}
