"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BookOpen,
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Send,
  Download,
  Upload,
  User,
  GraduationCap,
  Calendar,
  Eye,
  Edit,
  Trash2,
  Filter,
  Search,
  Plus,
  ExternalLink,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface Application {
  id: string
  opportunityTitle: string
  type: "scholarship" | "internship"
  company?: string
  amount?: string
  appliedDate: Date
  deadline: Date
  status: "draft" | "submitted" | "under-review" | "accepted" | "rejected" | "waitlisted"
  progress: number
  documents: string[]
  notes: string
}

interface UserProfile {
  personalInfo: {
    fullName: string
    email: string
    phone: string
    address: string
    dateOfBirth: string
  }
  academic: {
    institution: string
    branch: string
    year: string
    cgpa: string
    percentage: string
  }
  documents: {
    resume: string
    transcripts: string
    idProof: string
    photo: string
  }
}

export default function ApplicationsPage() {
  const [activeTab, setActiveTab] = useState("tracker")
  const [selectedApplication, setSelectedApplication] = useState<string | null>(null)

  const [userProfile, setUserProfile] = useState<UserProfile>({
    personalInfo: {
      fullName: "Alex Kumar",
      email: "alex.kumar@email.com",
      phone: "+91 9876543210",
      address: "Mumbai, Maharashtra",
      dateOfBirth: "2002-05-15",
    },
    academic: {
      institution: "Indian Institute of Technology, Mumbai",
      branch: "Computer Science Engineering",
      year: "3rd Year",
      cgpa: "8.5",
      percentage: "85%",
    },
    documents: {
      resume: "resume_alex_kumar.pdf",
      transcripts: "transcripts_2024.pdf",
      idProof: "aadhar_card.pdf",
      photo: "passport_photo.jpg",
    },
  })

  const [applications, setApplications] = useState<Application[]>([
    {
      id: "1",
      opportunityTitle: "Google AI Research Scholarship",
      type: "scholarship",
      amount: "₹2,00,000",
      appliedDate: new Date("2025-01-10"),
      deadline: new Date("2025-02-15"),
      status: "under-review",
      progress: 100,
      documents: ["Resume", "Transcripts", "Research Proposal"],
      notes: "Submitted research proposal on machine learning applications",
    },
    {
      id: "2",
      opportunityTitle: "Microsoft Software Engineering Internship",
      type: "internship",
      company: "Microsoft",
      appliedDate: new Date("2025-01-08"),
      deadline: new Date("2025-01-30"),
      status: "submitted",
      progress: 100,
      documents: ["Resume", "Cover Letter", "Portfolio"],
      notes: "Applied for summer internship program",
    },
    {
      id: "3",
      opportunityTitle: "Amazon Web Services Scholarship",
      type: "scholarship",
      amount: "₹1,50,000",
      appliedDate: new Date("2025-01-12"),
      deadline: new Date("2025-02-28"),
      status: "draft",
      progress: 60,
      documents: ["Resume", "Transcripts"],
      notes: "Need to complete online assessment",
    },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "accepted":
        return "text-green-600 bg-green-100 dark:bg-green-900/20"
      case "rejected":
        return "text-red-600 bg-red-100 dark:bg-red-900/20"
      case "under-review":
        return "text-blue-600 bg-blue-100 dark:bg-blue-900/20"
      case "submitted":
        return "text-purple-600 bg-purple-100 dark:bg-purple-900/20"
      case "waitlisted":
        return "text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20"
      case "draft":
        return "text-gray-600 bg-gray-100 dark:bg-gray-900/20"
      default:
        return "text-gray-600 bg-gray-100 dark:bg-gray-900/20"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "accepted":
        return <CheckCircle className="w-4 h-4" />
      case "rejected":
        return <XCircle className="w-4 h-4" />
      case "under-review":
        return <Clock className="w-4 h-4" />
      case "submitted":
        return <Send className="w-4 h-4" />
      case "waitlisted":
        return <AlertCircle className="w-4 h-4" />
      case "draft":
        return <FileText className="w-4 h-4" />
      default:
        return <FileText className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/20">
      {/* Navigation */}
      <nav className="glassmorphism bg-card/60 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">EduOpportunity</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/dashboard" className="text-muted-foreground hover:text-primary transition-colors">
                Dashboard
              </Link>
              <Link href="/applications" className="text-foreground hover:text-primary transition-colors font-medium">
                Applications
              </Link>
            </div>

            <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg pulse-glow">
              <Link href="/dashboard">Dashboard</Link>
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Application Center</h1>
          <p className="text-muted-foreground">
            Manage your applications with one-click apply and real-time status tracking.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="glassmorphism bg-card/60">
            <TabsTrigger value="tracker" className="flex items-center space-x-2">
              <FileText className="w-4 h-4" />
              <span>Application Tracker</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="w-4 h-4" />
              <span>Profile & Documents</span>
            </TabsTrigger>
            <TabsTrigger value="quick-apply" className="flex items-center space-x-2">
              <Send className="w-4 h-4" />
              <span>Quick Apply</span>
            </TabsTrigger>
          </TabsList>

          {/* Application Tracker Tab */}
          <TabsContent value="tracker" className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h2 className="text-2xl font-semibold text-foreground">Your Applications</h2>
                <Badge variant="secondary" className="bg-primary/10 text-primary">
                  {applications.length} Total
                </Badge>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
                <Button variant="outline" size="sm">
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Button>
              </div>
            </div>

            {/* Application Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="glassmorphism bg-card/60">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600 mb-1">
                    {applications.filter((a) => a.status === "submitted" || a.status === "under-review").length}
                  </div>
                  <div className="text-sm text-muted-foreground">Active</div>
                </CardContent>
              </Card>
              <Card className="glassmorphism bg-card/60">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-600 mb-1">
                    {applications.filter((a) => a.status === "accepted").length}
                  </div>
                  <div className="text-sm text-muted-foreground">Accepted</div>
                </CardContent>
              </Card>
              <Card className="glassmorphism bg-card/60">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-600 mb-1">
                    {applications.filter((a) => a.status === "draft").length}
                  </div>
                  <div className="text-sm text-muted-foreground">Drafts</div>
                </CardContent>
              </Card>
              <Card className="glassmorphism bg-card/60">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    {Math.round(applications.reduce((acc, app) => acc + app.progress, 0) / applications.length)}%
                  </div>
                  <div className="text-sm text-muted-foreground">Avg Progress</div>
                </CardContent>
              </Card>
            </div>

            {/* Applications List */}
            <div className="space-y-4">
              {applications.map((application) => (
                <Card
                  key={application.id}
                  className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-[1.01]"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <Badge variant={application.type === "scholarship" ? "default" : "secondary"}>
                            {application.type}
                          </Badge>
                          <Badge className={getStatusColor(application.status)}>
                            <div className="flex items-center space-x-1">
                              {getStatusIcon(application.status)}
                              <span className="capitalize">{application.status.replace("-", " ")}</span>
                            </div>
                          </Badge>
                          {application.amount && (
                            <Badge variant="outline" className="text-green-600 border-green-600">
                              {application.amount}
                            </Badge>
                          )}
                        </div>
                        <h3 className="text-xl font-semibold text-foreground mb-2">{application.opportunityTitle}</h3>
                        {application.company && (
                          <p className="text-muted-foreground mb-2">Company: {application.company}</p>
                        )}
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-4 h-4" />
                            <span>Applied: {application.appliedDate.toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>Deadline: {application.deadline.toLocaleDateString()}</span>
                          </div>
                        </div>
                        <div className="mb-3">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Application Progress</span>
                            <span>{application.progress}%</span>
                          </div>
                          <Progress value={application.progress} className="h-2" />
                        </div>
                        <div className="text-sm">
                          <p className="font-medium mb-1">Documents Submitted:</p>
                          <div className="flex flex-wrap gap-1">
                            {application.documents.map((doc, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {doc}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        {application.notes && (
                          <div className="mt-3 text-sm">
                            <p className="font-medium mb-1">Notes:</p>
                            <p className="text-muted-foreground">{application.notes}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </Button>
                        {application.status === "draft" && (
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4 mr-2" />
                            Continue
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      </div>
                      <div className="flex space-x-2">
                        {application.status === "draft" && (
                          <Button size="sm" className="bg-primary hover:bg-primary/90">
                            <Send className="w-4 h-4 mr-2" />
                            Submit Application
                          </Button>
                        )}
                        <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Profile & Documents Tab */}
          <TabsContent value="profile" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Personal Information */}
              <Card className="glassmorphism bg-card/60">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="w-5 h-5 mr-2 text-primary" />
                    Personal Information
                  </CardTitle>
                  <CardDescription>This information will be auto-filled in applications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input id="fullName" value={userProfile.personalInfo.fullName} />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" value={userProfile.personalInfo.email} />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input id="phone" value={userProfile.personalInfo.phone} />
                    </div>
                    <div>
                      <Label htmlFor="dob">Date of Birth</Label>
                      <Input id="dob" type="date" value={userProfile.personalInfo.dateOfBirth} />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Textarea id="address" value={userProfile.personalInfo.address} />
                  </div>
                  <Button className="w-full bg-primary hover:bg-primary/90">Update Personal Info</Button>
                </CardContent>
              </Card>

              {/* Academic Information */}
              <Card className="glassmorphism bg-card/60">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <GraduationCap className="w-5 h-5 mr-2 text-primary" />
                    Academic Information
                  </CardTitle>
                  <CardDescription>Your educational background and achievements</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="institution">Institution</Label>
                    <Input id="institution" value={userProfile.academic.institution} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="branch">Branch</Label>
                      <Select value={userProfile.academic.branch}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Computer Science Engineering">Computer Science Engineering</SelectItem>
                          <SelectItem value="Mechanical Engineering">Mechanical Engineering</SelectItem>
                          <SelectItem value="Electrical Engineering">Electrical Engineering</SelectItem>
                          <SelectItem value="Civil Engineering">Civil Engineering</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="year">Year</Label>
                      <Select value={userProfile.academic.year}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1st Year">1st Year</SelectItem>
                          <SelectItem value="2nd Year">2nd Year</SelectItem>
                          <SelectItem value="3rd Year">3rd Year</SelectItem>
                          <SelectItem value="4th Year">4th Year</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="cgpa">CGPA</Label>
                      <Input id="cgpa" value={userProfile.academic.cgpa} />
                    </div>
                    <div>
                      <Label htmlFor="percentage">Percentage</Label>
                      <Input id="percentage" value={userProfile.academic.percentage} />
                    </div>
                  </div>
                  <Button className="w-full bg-primary hover:bg-primary/90">Update Academic Info</Button>
                </CardContent>
              </Card>

              {/* Documents */}
              <Card className="glassmorphism bg-card/60 lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-primary" />
                    Documents
                  </CardTitle>
                  <CardDescription>Upload and manage your documents for quick application submission</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-5 h-5 text-primary" />
                          <div>
                            <p className="font-medium">Resume</p>
                            <p className="text-sm text-muted-foreground">{userProfile.documents.resume}</p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Upload className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-5 h-5 text-primary" />
                          <div>
                            <p className="font-medium">Academic Transcripts</p>
                            <p className="text-sm text-muted-foreground">{userProfile.documents.transcripts}</p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Upload className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-5 h-5 text-primary" />
                          <div>
                            <p className="font-medium">ID Proof</p>
                            <p className="text-sm text-muted-foreground">{userProfile.documents.idProof}</p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Upload className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-5 h-5 text-primary" />
                          <div>
                            <p className="font-medium">Passport Photo</p>
                            <p className="text-sm text-muted-foreground">{userProfile.documents.photo}</p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Upload className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 flex justify-center">
                    <Button variant="outline" className="bg-transparent">
                      <Plus className="w-4 h-4 mr-2" />
                      Add New Document
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Quick Apply Tab */}
          <TabsContent value="quick-apply" className="space-y-6">
            <Card className="glassmorphism bg-gradient-to-r from-primary/10 to-purple-600/10 border-primary/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-primary to-purple-600 rounded-full flex items-center justify-center pulse-glow">
                    <Send className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">One-Click Apply</h3>
                    <p className="text-sm text-muted-foreground">
                      Apply to opportunities instantly using your saved profile and documents
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-1">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span>Profile Complete</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span>Documents Ready</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span>Auto-fill Enabled</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glassmorphism bg-card/60">
              <CardContent className="p-8 text-center">
                <Send className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Ready to Apply Instantly</h3>
                <p className="text-muted-foreground mb-6">
                  Browse opportunities and apply with one click using your pre-filled profile and documents.
                </p>
                <div className="flex justify-center space-x-4">
                  <Button asChild className="bg-primary hover:bg-primary/90">
                    <Link href="/scholarships">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Browse Scholarships
                    </Link>
                  </Button>
                  <Button variant="outline" asChild className="bg-transparent">
                    <Link href="/internships">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Browse Internships
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
