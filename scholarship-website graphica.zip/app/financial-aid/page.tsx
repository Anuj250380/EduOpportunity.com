"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Progress } from "@/components/ui/progress"
import {
  BookOpen,
  Calculator,
  PieChart,
  AlertCircle,
  CheckCircle,
  Info,
  Target,
  Users,
  Home,
  GraduationCap,
  FileText,
  Lightbulb,
  ArrowRight,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface FinancialProfile {
  familyIncome: number
  familySize: number
  parentsEducation: string
  category: string
  state: string
  cgpa: number
  year: string
  branch: string
  hasDisability: boolean
  isSingleParent: boolean
  isRural: boolean
}

interface EligibilityResult {
  category: string
  eligible: boolean
  estimatedAmount: number
  confidence: number
  requirements: string[]
  tips: string[]
}

interface ScholarshipRecommendation {
  id: string
  name: string
  provider: string
  amount: string
  eligibility: number
  type: "merit" | "need" | "minority" | "state"
  deadline: string
  requirements: string[]
}

export default function FinancialAidPage() {
  const [activeTab, setActiveTab] = useState("estimator")
  const [currentStep, setCurrentStep] = useState(1)
  const [showResults, setShowResults] = useState(false)

  const [financialProfile, setFinancialProfile] = useState<FinancialProfile>({
    familyIncome: 300000,
    familySize: 4,
    parentsEducation: "graduate",
    category: "general",
    state: "maharashtra",
    cgpa: 8.5,
    year: "3rd",
    branch: "computer-science",
    hasDisability: false,
    isSingleParent: false,
    isRural: false,
  })

  const [eligibilityResults, setEligibilityResults] = useState<EligibilityResult[]>([])
  const [recommendations, setRecommendations] = useState<ScholarshipRecommendation[]>([])

  const calculateEligibility = () => {
    const results: EligibilityResult[] = []

    // Merit-based scholarships
    if (financialProfile.cgpa >= 8.0) {
      results.push({
        category: "Merit-Based Scholarships",
        eligible: true,
        estimatedAmount: Math.min(200000, financialProfile.cgpa * 25000),
        confidence: financialProfile.cgpa >= 9.0 ? 90 : 75,
        requirements: ["CGPA ≥ 8.0", "Academic transcripts", "Recommendation letters"],
        tips: ["Maintain high CGPA", "Participate in extracurricular activities", "Build strong portfolio"],
      })
    }

    // Need-based scholarships
    if (financialProfile.familyIncome <= 800000) {
      const needScore = Math.max(0, (800000 - financialProfile.familyIncome) / 800000)
      results.push({
        category: "Need-Based Scholarships",
        eligible: true,
        estimatedAmount: Math.floor(needScore * 150000),
        confidence: financialProfile.familyIncome <= 500000 ? 85 : 65,
        requirements: ["Family income certificate", "Bank statements", "Affidavit"],
        tips: ["Gather all financial documents", "Apply early", "Consider multiple programs"],
      })
    }

    // Minority scholarships
    if (financialProfile.category !== "general") {
      results.push({
        category: "Minority Scholarships",
        eligible: true,
        estimatedAmount: 100000,
        confidence: 80,
        requirements: ["Caste certificate", "Income certificate", "Academic records"],
        tips: ["Check state-specific schemes", "Apply for central government programs", "Maintain documentation"],
      })
    }

    // State scholarships
    results.push({
      category: "State Scholarships",
      eligible: true,
      estimatedAmount: 75000,
      confidence: 70,
      requirements: ["Domicile certificate", "Academic performance", "Income proof"],
      tips: ["Check state government portals", "Apply before deadlines", "Follow up on applications"],
    })

    // Special category scholarships
    if (financialProfile.hasDisability || financialProfile.isSingleParent || financialProfile.isRural) {
      results.push({
        category: "Special Category Scholarships",
        eligible: true,
        estimatedAmount: 120000,
        confidence: 75,
        requirements: ["Relevant certificates", "Income proof", "Academic records"],
        tips: ["Explore NGO scholarships", "Check corporate CSR programs", "Apply for multiple schemes"],
      })
    }

    setEligibilityResults(results)

    // Generate recommendations
    const recs: ScholarshipRecommendation[] = [
      {
        id: "1",
        name: "National Merit Scholarship",
        provider: "Government of India",
        amount: "₹2,00,000",
        eligibility: financialProfile.cgpa >= 8.5 ? 95 : 70,
        type: "merit",
        deadline: "2025-03-15",
        requirements: ["CGPA ≥ 8.0", "Entrance exam", "Interview"],
      },
      {
        id: "2",
        name: "Post Matric Scholarship",
        provider: "State Government",
        amount: "₹1,20,000",
        eligibility: financialProfile.familyIncome <= 600000 ? 90 : 50,
        type: "need",
        deadline: "2025-02-28",
        requirements: ["Income certificate", "Caste certificate", "Bank details"],
      },
      {
        id: "3",
        name: "Inspire Scholarship",
        provider: "DST, Government of India",
        amount: "₹80,000",
        eligibility: financialProfile.branch === "computer-science" ? 85 : 75,
        type: "merit",
        deadline: "2025-04-30",
        requirements: ["Science background", "Top 1% in board exams", "Pursuing higher education"],
      },
    ]

    setRecommendations(recs)
    setShowResults(true)
  }

  const getTotalEstimatedAmount = () => {
    return eligibilityResults.reduce((total, result) => total + result.estimatedAmount, 0)
  }

  const getIncomeCategory = () => {
    if (financialProfile.familyIncome <= 250000) return "Below Poverty Line"
    if (financialProfile.familyIncome <= 500000) return "Low Income"
    if (financialProfile.familyIncome <= 800000) return "Lower Middle Class"
    if (financialProfile.familyIncome <= 1500000) return "Middle Class"
    return "Upper Middle Class"
  }

  const getEligibilityColor = (eligible: boolean) => {
    return eligible ? "text-green-600 bg-green-100 dark:bg-green-900/20" : "text-red-600 bg-red-100 dark:bg-red-900/20"
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "merit":
        return "text-blue-600 bg-blue-100 dark:bg-blue-900/20"
      case "need":
        return "text-green-600 bg-green-100 dark:bg-green-900/20"
      case "minority":
        return "text-purple-600 bg-purple-100 dark:bg-purple-900/20"
      case "state":
        return "text-orange-600 bg-orange-100 dark:bg-orange-900/20"
      default:
        return "text-gray-600 bg-gray-100 dark:bg-gray-900/20"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/20">
      {/* Navigation */}
      <nav className="glassmorphism bg-card/60 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">EduOpportunity</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/dashboard" className="text-muted-foreground hover:text-primary transition-colors">
                Dashboard
              </Link>
              <Link href="/financial-aid" className="text-foreground hover:text-primary transition-colors font-medium">
                Financial Aid
              </Link>
            </div>

            <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg pulse-glow">
              <Link href="/dashboard">Dashboard</Link>
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Financial Aid Estimator</h1>
          <p className="text-muted-foreground">
            Calculate your eligibility for scholarships and financial aid programs based on your profile.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="glassmorphism bg-card/60">
            <TabsTrigger value="estimator" className="flex items-center space-x-2">
              <Calculator className="w-4 h-4" />
              <span>Estimator</span>
            </TabsTrigger>
            <TabsTrigger value="results" className="flex items-center space-x-2" disabled={!showResults}>
              <PieChart className="w-4 h-4" />
              <span>Results</span>
            </TabsTrigger>
            <TabsTrigger value="recommendations" className="flex items-center space-x-2" disabled={!showResults}>
              <Target className="w-4 h-4" />
              <span>Recommendations</span>
            </TabsTrigger>
            <TabsTrigger value="guide" className="flex items-center space-x-2">
              <Lightbulb className="w-4 h-4" />
              <span>Guide</span>
            </TabsTrigger>
          </TabsList>

          {/* Estimator Tab */}
          <TabsContent value="estimator" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Form */}
              <div className="lg:col-span-2">
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Calculator className="w-5 h-5 mr-2 text-primary" />
                      Financial Profile Assessment
                    </CardTitle>
                    <CardDescription>Provide your details to get personalized financial aid estimates</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Step 1: Family Information */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center">
                        <Home className="w-5 h-5 mr-2 text-primary" />
                        Family Information
                      </h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="familyIncome">Annual Family Income (₹)</Label>
                          <Input
                            id="familyIncome"
                            type="number"
                            value={financialProfile.familyIncome}
                            onChange={(e) =>
                              setFinancialProfile((prev) => ({
                                ...prev,
                                familyIncome: Number.parseInt(e.target.value) || 0,
                              }))
                            }
                          />
                          <p className="text-xs text-muted-foreground mt-1">Category: {getIncomeCategory()}</p>
                        </div>
                        <div>
                          <Label htmlFor="familySize">Family Size</Label>
                          <Select
                            value={financialProfile.familySize.toString()}
                            onValueChange={(value) =>
                              setFinancialProfile((prev) => ({ ...prev, familySize: Number.parseInt(value) }))
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="2">2 members</SelectItem>
                              <SelectItem value="3">3 members</SelectItem>
                              <SelectItem value="4">4 members</SelectItem>
                              <SelectItem value="5">5 members</SelectItem>
                              <SelectItem value="6">6+ members</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="parentsEducation">Parents' Education</Label>
                          <Select
                            value={financialProfile.parentsEducation}
                            onValueChange={(value) =>
                              setFinancialProfile((prev) => ({ ...prev, parentsEducation: value }))
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="below-10th">Below 10th</SelectItem>
                              <SelectItem value="10th-12th">10th-12th</SelectItem>
                              <SelectItem value="graduate">Graduate</SelectItem>
                              <SelectItem value="postgraduate">Post Graduate</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="category">Category</Label>
                          <Select
                            value={financialProfile.category}
                            onValueChange={(value) => setFinancialProfile((prev) => ({ ...prev, category: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="general">General</SelectItem>
                              <SelectItem value="obc">OBC</SelectItem>
                              <SelectItem value="sc">SC</SelectItem>
                              <SelectItem value="st">ST</SelectItem>
                              <SelectItem value="ews">EWS</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Step 2: Academic Information */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center">
                        <GraduationCap className="w-5 h-5 mr-2 text-primary" />
                        Academic Information
                      </h3>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="cgpa">Current CGPA</Label>
                          <div className="space-y-2">
                            <Slider
                              value={[financialProfile.cgpa]}
                              onValueChange={(value) => setFinancialProfile((prev) => ({ ...prev, cgpa: value[0] }))}
                              max={10}
                              min={5}
                              step={0.1}
                              className="w-full"
                            />
                            <div className="text-center font-medium">{financialProfile.cgpa.toFixed(1)}</div>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="year">Current Year</Label>
                          <Select
                            value={financialProfile.year}
                            onValueChange={(value) => setFinancialProfile((prev) => ({ ...prev, year: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1st">1st Year</SelectItem>
                              <SelectItem value="2nd">2nd Year</SelectItem>
                              <SelectItem value="3rd">3rd Year</SelectItem>
                              <SelectItem value="4th">4th Year</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="branch">Branch</Label>
                          <Select
                            value={financialProfile.branch}
                            onValueChange={(value) => setFinancialProfile((prev) => ({ ...prev, branch: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="computer-science">Computer Science</SelectItem>
                              <SelectItem value="mechanical">Mechanical</SelectItem>
                              <SelectItem value="electrical">Electrical</SelectItem>
                              <SelectItem value="civil">Civil</SelectItem>
                              <SelectItem value="electronics">Electronics</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Step 3: Additional Information */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center">
                        <Users className="w-5 h-5 mr-2 text-primary" />
                        Additional Information
                      </h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="state">State</Label>
                          <Select
                            value={financialProfile.state}
                            onValueChange={(value) => setFinancialProfile((prev) => ({ ...prev, state: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="maharashtra">Maharashtra</SelectItem>
                              <SelectItem value="karnataka">Karnataka</SelectItem>
                              <SelectItem value="tamil-nadu">Tamil Nadu</SelectItem>
                              <SelectItem value="gujarat">Gujarat</SelectItem>
                              <SelectItem value="rajasthan">Rajasthan</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="hasDisability"
                            checked={financialProfile.hasDisability}
                            onChange={(e) =>
                              setFinancialProfile((prev) => ({ ...prev, hasDisability: e.target.checked }))
                            }
                            className="rounded"
                          />
                          <Label htmlFor="hasDisability">Person with Disability (PWD)</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="isSingleParent"
                            checked={financialProfile.isSingleParent}
                            onChange={(e) =>
                              setFinancialProfile((prev) => ({ ...prev, isSingleParent: e.target.checked }))
                            }
                            className="rounded"
                          />
                          <Label htmlFor="isSingleParent">Single Parent Family</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="isRural"
                            checked={financialProfile.isRural}
                            onChange={(e) => setFinancialProfile((prev) => ({ ...prev, isRural: e.target.checked }))}
                            className="rounded"
                          />
                          <Label htmlFor="isRural">Rural Background</Label>
                        </div>
                      </div>
                    </div>

                    <Button onClick={calculateEligibility} className="w-full bg-primary hover:bg-primary/90">
                      <Calculator className="w-4 h-4 mr-2" />
                      Calculate Financial Aid Eligibility
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Quick Info */}
              <div className="space-y-6">
                <Card className="glassmorphism bg-gradient-to-br from-primary/10 to-purple-600/10 border-primary/20">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Info className="w-5 h-5 mr-2 text-primary" />
                      Quick Tips
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Keep all financial documents ready</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Apply early to increase chances</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Maintain good academic performance</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Check multiple scholarship programs</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="text-lg">Income Categories</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span>Below Poverty Line</span>
                      <span className="font-medium">≤ ₹2.5L</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Low Income</span>
                      <span className="font-medium">₹2.5L - ₹5L</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Lower Middle Class</span>
                      <span className="font-medium">₹5L - ₹8L</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Middle Class</span>
                      <span className="font-medium">₹8L - ₹15L</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Upper Middle Class</span>
                      <span className="font-medium">{"> ₹15L"}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-6">
            {showResults && (
              <>
                {/* Summary Card */}
                <Card className="glassmorphism bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 border-green-200 dark:border-green-800">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-2xl font-bold text-green-700 dark:text-green-300">Total Estimated Aid</h3>
                        <p className="text-green-600 dark:text-green-400">Based on your profile</p>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold text-green-700 dark:text-green-300">
                          ₹{getTotalEstimatedAmount().toLocaleString()}
                        </div>
                        <p className="text-sm text-green-600 dark:text-green-400">per year</p>
                      </div>
                    </div>
                    <div className="grid md:grid-cols-3 gap-4 text-sm">
                      <div className="text-center">
                        <div className="font-semibold">Eligible Programs</div>
                        <div className="text-lg font-bold text-primary">{eligibilityResults.length}</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold">Average Confidence</div>
                        <div className="text-lg font-bold text-primary">
                          {Math.round(
                            eligibilityResults.reduce((acc, result) => acc + result.confidence, 0) /
                              eligibilityResults.length,
                          )}
                          %
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold">Income Category</div>
                        <div className="text-lg font-bold text-primary">{getIncomeCategory()}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Detailed Results */}
                <div className="grid md:grid-cols-2 gap-6">
                  {eligibilityResults.map((result, index) => (
                    <Card key={index} className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="text-lg font-semibold mb-2">{result.category}</h4>
                            <Badge className={getEligibilityColor(result.eligible)}>
                              {result.eligible ? "Eligible" : "Not Eligible"}
                            </Badge>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-primary">
                              ₹{result.estimatedAmount.toLocaleString()}
                            </div>
                            <div className="text-sm text-muted-foreground">{result.confidence}% confidence</div>
                          </div>
                        </div>
                        <div className="mb-4">
                          <Progress value={result.confidence} className="h-2" />
                        </div>
                        <div className="space-y-3">
                          <div>
                            <h5 className="font-medium mb-2">Requirements:</h5>
                            <ul className="text-sm text-muted-foreground space-y-1">
                              {result.requirements.map((req, reqIndex) => (
                                <li key={reqIndex} className="flex items-center space-x-2">
                                  <FileText className="w-3 h-3" />
                                  <span>{req}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-medium mb-2">Tips:</h5>
                            <ul className="text-sm text-muted-foreground space-y-1">
                              {result.tips.map((tip, tipIndex) => (
                                <li key={tipIndex} className="flex items-center space-x-2">
                                  <Lightbulb className="w-3 h-3" />
                                  <span>{tip}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            )}
          </TabsContent>

          {/* Recommendations Tab */}
          <TabsContent value="recommendations" className="space-y-6">
            {showResults && (
              <div className="space-y-4">
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Target className="w-5 h-5 mr-2 text-primary" />
                      Recommended Scholarships
                    </CardTitle>
                    <CardDescription>Based on your profile and eligibility</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recommendations.map((scholarship) => (
                        <Card key={scholarship.id} className="border hover:shadow-lg transition-all duration-300">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div>
                                <h4 className="font-semibold text-lg">{scholarship.name}</h4>
                                <p className="text-muted-foreground">{scholarship.provider}</p>
                              </div>
                              <div className="text-right">
                                <div className="text-xl font-bold text-primary">{scholarship.amount}</div>
                                <Badge className={getTypeColor(scholarship.type)}>{scholarship.type}</Badge>
                              </div>
                            </div>
                            <div className="mb-3">
                              <div className="flex justify-between text-sm mb-1">
                                <span>Eligibility Match</span>
                                <span>{scholarship.eligibility}%</span>
                              </div>
                              <Progress value={scholarship.eligibility} className="h-2" />
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="text-sm text-muted-foreground">Deadline: {scholarship.deadline}</div>
                              <Button size="sm" className="bg-primary hover:bg-primary/90">
                                <ArrowRight className="w-4 h-4 mr-2" />
                                Apply Now
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Guide Tab */}
          <TabsContent value="guide" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="glassmorphism bg-card/60">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-primary" />
                    Required Documents
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Income Certificate</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Caste Certificate (if applicable)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Academic Transcripts</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Bank Account Details</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Domicile Certificate</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Passport Size Photographs</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="glassmorphism bg-card/60">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Lightbulb className="w-5 h-5 mr-2 text-primary" />
                    Application Tips
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Apply early to avoid last-minute rush</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Keep digital copies of all documents</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Follow up on application status regularly</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Apply to multiple schemes to increase chances</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Maintain good academic performance</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
