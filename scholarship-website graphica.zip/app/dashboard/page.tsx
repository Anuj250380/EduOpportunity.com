"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  User,
  BookOpen,
  Star,
  TrendingUp,
  MapPin,
  DollarSign,
  Target,
  Award,
  Clock,
  Heart,
  Sparkles,
  Brain,
  Zap,
  Bell,
  Settings,
  Trophy,
  Crown,
  Calculator,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { ProfileEditModal } from "@/components/profile-edit-modal"

interface UserProfile {
  name: string
  branch: string
  year: string
  cgpa: string
  location: string
  interests: string[]
  level: number
  points: number
  streak: number
  email: string
  phone: string
  bio: string
}

interface Opportunity {
  id: string
  title: string
  type: "scholarship" | "internship"
  amount?: string
  company?: string
  location: string
  deadline: string
  matchScore: number
  tags: string[]
  description: string
  requirements: string[]
  isBookmarked: boolean
}

export default function DashboardPage() {
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: "Alex Kumar",
    branch: "Computer Science",
    year: "3rd Year",
    cgpa: "8.5",
    location: "Mumbai",
    interests: ["AI/ML", "Web Development", "Data Science"],
    level: 12,
    points: 2450,
    streak: 7,
    email: "alex.kumar@example.com",
    phone: "+91 98765 43210",
    bio: "Passionate computer science student interested in AI/ML and web development. Looking for opportunities to apply my skills in real-world projects.",
  })

  const [recommendations, setRecommendations] = useState<Opportunity[]>([
    {
      id: "1",
      title: "Google AI Research Scholarship",
      type: "scholarship",
      amount: "₹2,00,000",
      location: "Pan India",
      deadline: "2025-02-15",
      matchScore: 95,
      tags: ["AI/ML", "Research", "Computer Science"],
      description: "Scholarship for outstanding students pursuing AI/ML research projects.",
      requirements: ["CGPA > 8.0", "Research project", "Computer Science background"],
      isBookmarked: false,
    },
    {
      id: "2",
      title: "Microsoft Software Engineering Internship",
      type: "internship",
      company: "Microsoft",
      location: "Bangalore",
      deadline: "2025-01-30",
      matchScore: 92,
      tags: ["Software Engineering", "Full-time", "Tech"],
      description: "3-month internship program for software engineering roles.",
      requirements: ["3rd/4th year student", "Programming skills", "CGPA > 7.5"],
      isBookmarked: true,
    },
    {
      id: "3",
      title: "Amazon Web Services Cloud Scholarship",
      type: "scholarship",
      amount: "₹1,50,000",
      location: "Online",
      deadline: "2025-02-28",
      matchScore: 88,
      tags: ["Cloud Computing", "AWS", "Technology"],
      description: "Scholarship for students interested in cloud computing and AWS technologies.",
      requirements: ["Technical background", "Interest in cloud", "Online course completion"],
      isBookmarked: false,
    },
  ])

  const [profileCompletion, setProfileCompletion] = useState(75)
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false)

  const toggleBookmark = (id: string) => {
    setRecommendations((prev) => prev.map((opp) => (opp.id === id ? { ...opp, isBookmarked: !opp.isBookmarked } : opp)))
  }

  const getNextLevelPoints = () => {
    return (userProfile.level + 1) * 250
  }

  const getCurrentLevelPoints = () => {
    return userProfile.level * 250
  }

  const getProgressToNextLevel = () => {
    const currentLevelPoints = getCurrentLevelPoints()
    const nextLevelPoints = getNextLevelPoints()
    const pointsInCurrentLevel = userProfile.points - currentLevelPoints
    const pointsNeededForLevel = nextLevelPoints - currentLevelPoints
    return (pointsInCurrentLevel / pointsNeededForLevel) * 100
  }

  const handleProfileUpdate = (updatedProfile: UserProfile) => {
    setUserProfile(updatedProfile)
    const fields = [
      updatedProfile.name,
      updatedProfile.email,
      updatedProfile.phone,
      updatedProfile.branch,
      updatedProfile.year,
      updatedProfile.cgpa,
      updatedProfile.location,
      updatedProfile.bio,
    ]
    const filledFields = fields.filter((field) => field && field.trim() !== "").length
    const interestsFilled = updatedProfile.interests.length > 0 ? 1 : 0
    const newCompletion = Math.round(((filledFields + interestsFilled) / 9) * 100)
    setProfileCompletion(newCompletion)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/20">
      {/* Navigation */}
      <nav className="glassmorphism bg-card/60 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">EduOpportunity</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/dashboard" className="text-foreground hover:text-primary transition-colors font-medium">
                Dashboard
              </Link>
              <Link href="/community" className="text-muted-foreground hover:text-primary transition-colors">
                Community
              </Link>
              <Link href="/applications" className="text-muted-foreground hover:text-primary transition-colors">
                Applications
              </Link>
              <Link href="/deadlines" className="text-muted-foreground hover:text-primary transition-colors">
                Deadlines
              </Link>
              <Link href="/achievements" className="text-muted-foreground hover:text-primary transition-colors">
                Achievements
              </Link>
              <Link href="/financial-aid" className="text-muted-foreground hover:text-primary transition-colors">
                Financial Aid
              </Link>
              <Link href="/scholarships" className="text-muted-foreground hover:text-primary transition-colors">
                Browse All
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Welcome back, {userProfile.name}! 👋</h1>
          <p className="text-muted-foreground">
            Here are your personalized recommendations based on your profile and interests.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar - Profile & Stats */}
          <div className="lg:col-span-1 space-y-6">
            {/* Profile Card */}
            <Card className="glassmorphism bg-card/60 border-primary/20">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-r from-primary to-purple-600 rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{userProfile.name}</CardTitle>
                    <CardDescription>
                      {userProfile.branch} • {userProfile.year}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Profile Completion</span>
                    <span>{profileCompletion}%</span>
                  </div>
                  <Progress value={profileCompletion} className="h-2" />
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <Award className="w-4 h-4 text-primary" />
                    <span>CGPA: {userProfile.cgpa}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-primary" />
                    <span>{userProfile.location}</span>
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium mb-2">Interests</p>
                  <div className="flex flex-wrap gap-1">
                    {userProfile.interests.map((interest, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full bg-transparent"
                  onClick={() => setIsProfileModalOpen(true)}
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              </CardContent>
            </Card>

            {/* Gamification Level Card */}
            <Card className="glassmorphism bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border-yellow-200 dark:border-yellow-800">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center">
                    <Crown className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-yellow-700 dark:text-yellow-300">
                      Level {userProfile.level}
                    </CardTitle>
                    <CardDescription className="text-yellow-600 dark:text-yellow-400">
                      {userProfile.points.toLocaleString()} points
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Next Level Progress</span>
                    <span>{Math.round(getProgressToNextLevel())}%</span>
                  </div>
                  <Progress value={getProgressToNextLevel()} className="h-2" />
                  <p className="text-xs text-muted-foreground mt-1">
                    {getNextLevelPoints() - userProfile.points} points to Level {userProfile.level + 1}
                  </p>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Current Streak</span>
                  <div className="flex items-center space-x-1">
                    <span className="text-lg">🔥</span>
                    <span className="font-bold text-orange-600">{userProfile.streak} days</span>
                  </div>
                </div>
                <Button
                  asChild
                  size="sm"
                  className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                >
                  <Link href="/achievements">
                    <Trophy className="w-4 h-4 mr-2" />
                    View Achievements
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Financial Aid Card */}
            <Card className="glassmorphism bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                    <Calculator className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-green-700 dark:text-green-300">Financial Aid</CardTitle>
                    <CardDescription className="text-green-600 dark:text-green-400">
                      Estimate your eligibility
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-700 dark:text-green-300">₹4.5L+</div>
                  <p className="text-sm text-green-600 dark:text-green-400">Potential aid available</p>
                </div>
                <Button
                  asChild
                  size="sm"
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                >
                  <Link href="/financial-aid">
                    <Calculator className="w-4 h-4 mr-2" />
                    Calculate Eligibility
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="glassmorphism bg-card/60">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-primary" />
                  Your Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Applications</span>
                  <span className="font-medium">12</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Bookmarked</span>
                  <span className="font-medium">8</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Success Rate</span>
                  <span className="font-medium text-green-600">67%</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="recommendations" className="space-y-6">
              <TabsList className="glassmorphism bg-card/60">
                <TabsTrigger value="recommendations" className="flex items-center space-x-2">
                  <Brain className="w-4 h-4" />
                  <span>For You</span>
                </TabsTrigger>
                <TabsTrigger value="bookmarked" className="flex items-center space-x-2">
                  <Heart className="w-4 h-4" />
                  <span>Bookmarked</span>
                </TabsTrigger>
                <TabsTrigger value="applied" className="flex items-center space-x-2">
                  <Target className="w-4 h-4" />
                  <span>Applied</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="recommendations" className="space-y-6">
                {/* AI Recommendation Header */}
                <Card className="glassmorphism bg-gradient-to-r from-primary/10 to-purple-600/10 border-primary/20">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-primary to-purple-600 rounded-full flex items-center justify-center pulse-glow">
                        <Sparkles className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">AI-Powered Recommendations</h3>
                        <p className="text-sm text-muted-foreground">
                          Personalized opportunities based on your profile, interests, and success patterns
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm">
                      <div className="flex items-center space-x-1">
                        <Zap className="w-4 h-4 text-yellow-500" />
                        <span>Updated daily</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Target className="w-4 h-4 text-green-500" />
                        <span>95% match accuracy</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Recommendations List */}
                <div className="space-y-4">
                  {recommendations.map((opportunity) => (
                    <Card
                      key={opportunity.id}
                      className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <Badge
                                variant={opportunity.type === "scholarship" ? "default" : "secondary"}
                                className="capitalize"
                              >
                                {opportunity.type}
                              </Badge>
                              <div className="flex items-center space-x-1">
                                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                                <span className="text-sm font-medium text-green-600">
                                  {opportunity.matchScore}% match
                                </span>
                              </div>
                            </div>
                            <h3 className="text-xl font-semibold text-foreground mb-2">{opportunity.title}</h3>
                            <p className="text-muted-foreground mb-3">{opportunity.description}</p>
                            <div className="flex flex-wrap gap-2 mb-3">
                              {opportunity.tags.map((tag, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                              {opportunity.amount && (
                                <div className="flex items-center space-x-1">
                                  <DollarSign className="w-4 h-4" />
                                  <span>{opportunity.amount}</span>
                                </div>
                              )}
                              <div className="flex items-center space-x-1">
                                <MapPin className="w-4 h-4" />
                                <span>{opportunity.location}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Clock className="w-4 h-4" />
                                <span>Due: {opportunity.deadline}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex flex-col space-y-2 ml-4">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleBookmark(opportunity.id)}
                              className={opportunity.isBookmarked ? "text-red-500" : "text-muted-foreground"}
                            >
                              <Heart className={`w-4 h-4 ${opportunity.isBookmarked ? "fill-current" : ""}`} />
                            </Button>
                          </div>
                        </div>
                        <div className="flex space-x-3">
                          <Button className="flex-1 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90">
                            Apply Now
                          </Button>
                          <Button variant="outline" className="bg-transparent">
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="bookmarked" className="space-y-4">
                <div className="text-center py-12">
                  <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No bookmarked opportunities yet</h3>
                  <p className="text-muted-foreground">
                    Start bookmarking opportunities you're interested in to see them here.
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="applied" className="space-y-4">
                <div className="text-center py-12">
                  <Target className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No applications yet</h3>
                  <p className="text-muted-foreground">
                    Your applied opportunities will appear here once you start applying.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
      <ProfileEditModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        profile={userProfile}
        onSave={handleProfileUpdate}
      />
    </div>
  )
}
