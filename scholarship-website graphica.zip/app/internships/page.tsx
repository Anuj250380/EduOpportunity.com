"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Calendar, MapPin, ExternalLink, BookOpen, Building, Clock, Sparkles, IndianRupee } from "lucide-react"
import Link from "next/link"

const internships = [
  // FAANG Companies - Updated for 2025
  {
    id: 1,
    title: "Software Development Engineer Intern",
    company: "Google",
    location: "Bangalore, India",
    duration: "12 weeks",
    stipend: "₹95,000 per month",
    deadline: "2025-11-30",
    eligibility: ["3rd Year", "4th Year", "Computer Science"],
    type: "Tech",
    mode: "On-site",
    description:
      "Work on cutting-edge AI/ML projects with Google's engineering teams. Build scalable systems used by billions of users worldwide.",
    link: "https://careers.google.com/students/",
    tags: ["FAANG", "Software", "AI/ML", "Global Impact"],
    requirements: [
      "Strong programming skills in Java/Python/C++",
      "Data structures and algorithms",
      "System design basics",
    ],
    category: "Software Development",
  },
  {
    id: 2,
    title: "Data Science & AI Intern",
    company: "Microsoft",
    location: "Hyderabad, India",
    duration: "16 weeks",
    stipend: "₹90,000 per month",
    deadline: "2025-12-15",
    eligibility: ["Final Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "Hybrid",
    description:
      "Join Microsoft's AI and Data Platform team to work on Copilot, machine learning models and Azure AI solutions.",
    link: "https://careers.microsoft.com/students/",
    tags: ["FAANG", "AI/ML", "Copilot", "Azure"],
    requirements: ["Python/R programming", "Machine learning frameworks", "Statistics and probability"],
    category: "Data Science",
  },
  {
    id: 3,
    title: "Frontend Engineer Intern",
    company: "Meta (Facebook)",
    location: "Remote, India",
    duration: "12 weeks",
    stipend: "₹1,00,000 per month",
    deadline: "2025-10-31",
    eligibility: ["3rd Year", "4th Year", "Computer Science"],
    type: "Tech",
    mode: "Remote",
    description: "Build user interfaces for Facebook, Instagram, and WhatsApp used by billions of people globally.",
    link: "https://www.metacareers.com/students/",
    tags: ["FAANG", "Frontend", "React", "Remote", "Social Media"],
    requirements: ["JavaScript/TypeScript", "React/React Native", "CSS and responsive design"],
    category: "Frontend Development",
  },
  {
    id: 4,
    title: "Cloud Solutions Intern",
    company: "Amazon Web Services",
    location: "Mumbai, India",
    duration: "14 weeks",
    stipend: "₹85,000 per month",
    deadline: "2025-11-15",
    eligibility: ["3rd Year", "4th Year", "All Branches"],
    type: "Tech",
    mode: "On-site",
    description: "Work with AWS services and help customers build scalable cloud solutions with GenAI integration.",
    link: "https://amazon.jobs/en/teams/university-programs",
    tags: ["FAANG", "Cloud", "AWS", "GenAI"],
    requirements: ["Cloud computing basics", "Linux/Unix systems", "Networking fundamentals"],
    category: "Cloud Computing",
  },
  {
    id: 5,
    title: "iOS Development Intern",
    company: "Apple",
    location: "Bangalore, India",
    duration: "12 weeks",
    stipend: "₹1,05,000 per month",
    deadline: "2025-12-01",
    eligibility: ["3rd Year", "4th Year", "Computer Science"],
    type: "Tech",
    mode: "On-site",
    description: "Develop innovative iOS applications and contribute to Apple Intelligence ecosystem.",
    link: "https://jobs.apple.com/en-us/search?team=internships-STDNT-INTRN",
    tags: ["FAANG", "iOS", "Swift", "Apple Intelligence"],
    requirements: ["Swift programming", "iOS SDK", "Xcode development environment"],
    category: "Mobile Development",
  },
  {
    id: 6,
    title: "Engineering Campus Intern",
    company: "Goldman Sachs",
    location: "Bangalore, India",
    duration: "10 weeks",
    stipend: "₹75,000 per month",
    deadline: "2025-11-30",
    eligibility: ["3rd Year", "4th Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "On-site",
    description:
      "Work on high-frequency trading systems, risk management platforms, and financial technology solutions.",
    link: "https://www.goldmansachs.com/careers/students/programs-and-internships/india/engineers-campus-hiring-program",
    tags: ["FinTech", "Trading Systems", "Risk Management", "Global Finance"],
    requirements: ["Strong programming skills", "Data structures", "Financial markets knowledge"],
    category: "Financial Technology",
  },
  {
    id: 7,
    title: "Software Engineer Intern",
    company: "PayPal",
    location: "Bangalore, Chennai",
    duration: "12 weeks",
    stipend: "₹70,000 per month",
    deadline: "2025-12-31",
    eligibility: ["3rd Year", "4th Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "Hybrid",
    description: "Build secure payment solutions and digital wallet technologies used by millions globally.",
    link: "https://paypal.eightfold.ai/careers",
    tags: ["Payments", "Security", "Digital Wallet", "Global"],
    requirements: ["Java/Python", "Security protocols", "API development"],
    category: "Payment Technology",
  },
  {
    id: 8,
    title: "GRiD Internship Program",
    company: "Flipkart",
    location: "Bangalore, India",
    duration: "6 months",
    stipend: "₹60,000 per month",
    deadline: "2025-06-30",
    eligibility: ["3rd Year", "4th Year", "Computer Science", "IT", "Electrical"],
    type: "Tech",
    mode: "On-site",
    description:
      "Participate in Flipkart's flagship GRiD program focusing on e-commerce innovation, supply chain optimization, and customer experience.",
    link: "https://www.flipkartcareers.com/",
    tags: ["E-commerce", "GRiD Program", "Supply Chain", "Innovation"],
    requirements: ["Programming skills", "Problem solving", "System design"],
    category: "E-commerce Technology",
  },
  {
    id: 9,
    title: "ML Engineer Intern",
    company: "Tower Research Capital",
    location: "Gurgaon, India",
    duration: "3 months",
    stipend: "₹1,80,000 per month",
    deadline: "2025-11-15",
    eligibility: ["Final Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "On-site",
    description: "Work on algorithmic trading systems and machine learning models for quantitative finance.",
    link: "https://www.tower-research.com/careers",
    tags: ["Quant Finance", "ML", "Algorithmic Trading", "High Stipend"],
    requirements: ["Python/C++", "Machine learning", "Mathematical modeling", "Statistics"],
    category: "Quantitative Finance",
  },
  {
    id: 10,
    title: "Software Engineer Intern",
    company: "Adobe",
    location: "Bangalore, India",
    duration: "12 weeks",
    stipend: "₹80,000 per month",
    deadline: "2025-12-01",
    eligibility: ["Final Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "Hybrid",
    description: "Work on Creative Cloud applications, AI-powered tools, and digital experience platforms.",
    link: "https://www.adobe.com/careers/university.html",
    tags: ["Creative Tech", "AI Tools", "Digital Experience", "Creative Cloud"],
    requirements: ["Programming skills", "UI/UX understanding", "Creative problem solving"],
    category: "Creative Technology",
  },
  {
    id: 11,
    title: "Backend Development Intern",
    company: "Zomato",
    location: "Gurgaon, India",
    duration: "4 months",
    stipend: "₹55,000 per month",
    deadline: "2025-11-15",
    eligibility: ["2nd Year", "3rd Year", "4th Year", "Computer Science"],
    type: "Tech",
    mode: "Hybrid",
    description:
      "Build scalable backend systems for food delivery platform serving millions of orders daily with AI-powered recommendations.",
    link: "https://www.zomato.com/careers",
    tags: ["Food Tech", "Backend", "AI Recommendations", "Scale"],
    requirements: ["Java/Python/Node.js", "Database design", "API development", "System design"],
    category: "Backend Development",
  },
  {
    id: 12,
    title: "Machine Learning Intern",
    company: "Swiggy",
    location: "Bangalore, India",
    duration: "5 months",
    stipend: "₹58,000 per month",
    deadline: "2025-12-31",
    eligibility: ["Final Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "On-site",
    description:
      "Work on recommendation systems, demand forecasting, and delivery optimization algorithms with GenAI integration.",
    link: "https://careers.swiggy.com/",
    tags: ["Food Tech", "ML", "GenAI", "Optimization"],
    requirements: ["Python/R", "Machine learning algorithms", "Deep learning frameworks", "Statistics"],
    category: "Machine Learning",
  },
  {
    id: 13,
    title: "Full Stack Developer Intern",
    company: "Razorpay",
    location: "Bangalore, India",
    duration: "6 months",
    stipend: "₹65,000 per month",
    deadline: "2025-12-15",
    eligibility: ["2nd Year", "3rd Year", "4th Year", "Computer Science"],
    type: "Tech",
    mode: "On-site",
    description:
      "Build payment solutions and financial products used by millions of businesses across India with blockchain integration.",
    link: "https://razorpay.com/jobs/",
    tags: ["Fintech", "Full Stack", "Blockchain", "Payments"],
    requirements: ["JavaScript/TypeScript", "React/Node.js", "Database design", "API development"],
    category: "Full Stack Development",
  },
  {
    id: 14,
    title: "Android Developer Intern",
    company: "PhonePe",
    location: "Bangalore, India",
    duration: "5 months",
    stipend: "₹62,000 per month",
    deadline: "2025-12-01",
    eligibility: ["3rd Year", "4th Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "On-site",
    description:
      "Develop mobile payment solutions for India's fastest-growing digital payments platform with UPI innovations.",
    link: "https://www.phonepe.com/careers/",
    tags: ["Fintech", "Android", "UPI", "Digital Payments"],
    requirements: ["Java/Kotlin", "Android SDK", "Mobile app architecture", "Payment systems"],
    category: "Mobile Development",
  },
  {
    id: 15,
    title: "AI Research Intern",
    company: "OpenAI (India Office)",
    location: "Bangalore, India",
    duration: "12 weeks",
    stipend: "₹1,20,000 per month",
    deadline: "2025-10-31",
    eligibility: ["Final Year", "Computer Science", "AI/ML"],
    type: "Research",
    mode: "On-site",
    description: "Work on large language models, multimodal AI, and safety research for next-generation AI systems.",
    link: "https://openai.com/careers",
    tags: ["AI Research", "LLM", "Multimodal AI", "Safety"],
    requirements: ["Deep learning", "Python/PyTorch", "Research experience", "Mathematics"],
    category: "AI Research",
  },
  {
    id: 16,
    title: "GenAI Engineer Intern",
    company: "Anthropic (India)",
    location: "Remote, India",
    duration: "10 weeks",
    stipend: "₹1,10,000 per month",
    deadline: "2025-11-30",
    eligibility: ["Final Year", "Computer Science", "AI/ML"],
    type: "Tech",
    mode: "Remote",
    description: "Develop safe and beneficial AI systems, working on Claude and constitutional AI research.",
    link: "https://www.anthropic.com/careers",
    tags: ["GenAI", "Constitutional AI", "Safety", "Remote"],
    requirements: ["Machine learning", "NLP", "Python", "AI safety"],
    category: "Generative AI",
  },
  {
    id: 17,
    title: "Electric Vehicle Engineering Intern",
    company: "Tata Motors",
    location: "Pune, India",
    duration: "6 months",
    stipend: "₹35,000 per month",
    deadline: "2025-12-31",
    eligibility: ["3rd Year", "4th Year", "Mechanical", "Electrical"],
    type: "Engineering",
    mode: "On-site",
    description:
      "Work on electric vehicle development, battery technology, and sustainable mobility solutions for India's EV revolution.",
    link: "https://www.tatamotors.com/careers/",
    tags: ["EV", "Sustainability", "Battery Tech", "Automotive"],
    requirements: ["CAD software (SolidWorks/CATIA)", "EV systems", "Battery technology"],
    category: "Electric Vehicle Engineering",
  },
  {
    id: 18,
    title: "Renewable Energy Engineering Intern",
    company: "Adani Green Energy",
    location: "Ahmedabad, India",
    duration: "6 months",
    stipend: "₹32,000 per month",
    deadline: "2025-11-30",
    eligibility: ["3rd Year", "4th Year", "Electrical", "Mechanical"],
    type: "Engineering",
    mode: "On-site",
    description: "Work on solar and wind energy projects, grid integration, and energy storage solutions.",
    link: "https://www.adanigreenenergy.com/careers",
    tags: ["Renewable Energy", "Solar", "Wind", "Grid Integration"],
    requirements: ["Power systems", "Renewable energy systems", "Grid technology"],
    category: "Renewable Energy",
  },
  {
    id: 19,
    title: "Satellite Technology Intern",
    company: "ISRO",
    location: "Bangalore, India",
    duration: "8 weeks",
    stipend: "₹25,000 per month",
    deadline: "2025-09-30",
    eligibility: ["3rd Year", "4th Year", "Aerospace", "Electronics"],
    type: "Research",
    mode: "On-site",
    description: "Work on satellite missions, space technology, and contribute to India's space exploration programs.",
    link: "https://www.isro.gov.in/careers",
    tags: ["Space Tech", "Satellites", "ISRO", "Space Exploration"],
    requirements: ["Aerospace engineering", "Electronics", "Programming", "Space systems"],
    category: "Space Technology",
  },
  {
    id: 20,
    title: "Space Systems Engineer Intern",
    company: "Skyroot Aerospace",
    location: "Hyderabad, India",
    duration: "6 months",
    stipend: "₹45,000 per month",
    deadline: "2025-11-15",
    eligibility: ["3rd Year", "4th Year", "Aerospace", "Mechanical"],
    type: "Engineering",
    mode: "On-site",
    description: "Work on rocket propulsion systems and launch vehicle technology for India's private space industry.",
    link: "https://www.skyroot.in/careers",
    tags: ["Private Space", "Rockets", "Propulsion", "Launch Vehicles"],
    requirements: ["Aerospace systems", "Propulsion", "CAD design", "Systems engineering"],
    category: "Aerospace Engineering",
  },
  {
    id: 21,
    title: "Summer Research Fellowship",
    company: "Indian Institute of Science (IISc)",
    location: "Bangalore, India",
    duration: "8-10 weeks",
    stipend: "₹12,000 per month",
    deadline: "2025-02-28",
    eligibility: ["2nd Year", "3rd Year", "All Branches"],
    type: "Research",
    mode: "On-site",
    description:
      "Conduct cutting-edge research in science and engineering under the guidance of renowned faculty members.",
    link: "https://www.iisc.ac.in/admissions/summer-research-fellowship/",
    tags: ["Government", "Research", "IISc", "Science"],
    requirements: ["Strong academic record", "Research aptitude", "Basic programming"],
    category: "Research",
  },
  {
    id: 22,
    title: "DRDO Internship Program",
    company: "Defence Research and Development Organisation",
    location: "Multiple Cities, India",
    duration: "6-8 weeks",
    stipend: "₹15,000 per month",
    deadline: "2025-03-31",
    eligibility: ["3rd Year", "4th Year", "All Branches"],
    type: "Research",
    mode: "On-site",
    description:
      "Work on defense technology projects including aerospace, electronics, and advanced materials research.",
    link: "https://www.drdo.gov.in/careers",
    tags: ["Government", "Defense", "DRDO", "Technology"],
    requirements: ["Engineering background", "Security clearance eligible", "Technical skills"],
    category: "Defense Technology",
  },
  {
    id: 23,
    title: "Nuclear Technology Intern",
    company: "Bhabha Atomic Research Centre (BARC)",
    location: "Mumbai, India",
    duration: "12 weeks",
    stipend: "₹18,000 per month",
    deadline: "2025-04-15",
    eligibility: ["Final Year", "Mechanical", "Electrical", "Nuclear"],
    type: "Research",
    mode: "On-site",
    description: "Gain hands-on experience in nuclear technology, reactor physics, and radiation safety protocols.",
    link: "https://www.barc.gov.in/careers/",
    tags: ["Government", "Nuclear", "BARC", "Energy"],
    requirements: ["Nuclear/Mechanical engineering", "Physics background", "Safety protocols"],
    category: "Nuclear Technology",
  },
  {
    id: 24,
    title: "Railway Technology Intern",
    company: "Indian Railways (RDSO)",
    location: "Lucknow, India",
    duration: "6 months",
    stipend: "₹20,000 per month",
    deadline: "2025-05-30",
    eligibility: ["3rd Year", "4th Year", "Mechanical", "Electrical", "Civil"],
    type: "Engineering",
    mode: "On-site",
    description: "Work on railway infrastructure, signaling systems, and high-speed rail technology development.",
    link: "https://rdso.indianrailways.gov.in/",
    tags: ["Government", "Railways", "Infrastructure", "Transportation"],
    requirements: ["Engineering fundamentals", "CAD software", "Transportation systems"],
    category: "Transportation Engineering",
  },
  {
    id: 25,
    title: "Meteorological Research Intern",
    company: "India Meteorological Department",
    location: "New Delhi, India",
    duration: "10 weeks",
    stipend: "₹14,000 per month",
    deadline: "2025-03-15",
    eligibility: ["2nd Year", "3rd Year", "4th Year", "All Branches"],
    type: "Research",
    mode: "On-site",
    description:
      "Study weather patterns, climate modeling, and atmospheric sciences with advanced forecasting systems.",
    link: "https://mausam.imd.gov.in/",
    tags: ["Government", "Weather", "Climate", "Research"],
    requirements: ["Mathematics/Statistics", "Data analysis", "Programming basics"],
    category: "Atmospheric Sciences",
  },
  {
    id: 26,
    title: "Power Systems Engineering Intern",
    company: "Power Grid Corporation of India",
    location: "Gurgaon, India",
    duration: "6 months",
    stipend: "₹25,000 per month",
    deadline: "2025-06-30",
    eligibility: ["3rd Year", "4th Year", "Electrical", "Electronics"],
    type: "Engineering",
    mode: "On-site",
    description:
      "Work on national power transmission systems, smart grid technology, and renewable energy integration.",
    link: "https://www.powergridindia.com/careers",
    tags: ["PSU", "Power Systems", "Smart Grid", "Energy"],
    requirements: ["Power systems", "Electrical engineering", "Grid technology"],
    category: "Power Systems",
  },
  {
    id: 27,
    title: "Oil & Gas Technology Intern",
    company: "Oil and Natural Gas Corporation (ONGC)",
    location: "Mumbai, Dehradun",
    duration: "4 months",
    stipend: "₹30,000 per month",
    deadline: "2025-07-15",
    eligibility: ["3rd Year", "4th Year", "Petroleum", "Chemical", "Mechanical"],
    type: "Engineering",
    mode: "On-site",
    description: "Gain experience in upstream oil exploration, drilling technology, and petroleum refining processes.",
    link: "https://www.ongcindia.com/careers",
    tags: ["PSU", "Oil & Gas", "Petroleum", "Energy"],
    requirements: ["Petroleum/Chemical engineering", "Process engineering", "Safety protocols"],
    category: "Petroleum Engineering",
  },
  {
    id: 28,
    title: "Steel Technology Intern",
    company: "Steel Authority of India Limited (SAIL)",
    location: "Bhilai, Rourkela",
    duration: "5 months",
    stipend: "₹22,000 per month",
    deadline: "2025-08-31",
    eligibility: ["3rd Year", "4th Year", "Metallurgy", "Mechanical", "Chemical"],
    type: "Engineering",
    mode: "On-site",
    description: "Learn steel production processes, quality control, and advanced metallurgical techniques.",
    link: "https://www.sail.co.in/careers",
    tags: ["PSU", "Steel", "Metallurgy", "Manufacturing"],
    requirements: ["Metallurgy/Mechanical", "Materials science", "Process control"],
    category: "Metallurgical Engineering",
  },
  {
    id: 29,
    title: "Coal Mining Technology Intern",
    company: "Coal India Limited (CIL)",
    location: "Kolkata, Ranchi",
    duration: "6 months",
    stipend: "₹24,000 per month",
    deadline: "2025-09-30",
    eligibility: ["3rd Year", "4th Year", "Mining", "Mechanical", "Electrical"],
    type: "Engineering",
    mode: "On-site",
    description: "Experience modern coal mining techniques, safety systems, and environmental management.",
    link: "https://www.coalindia.in/careers",
    tags: ["PSU", "Mining", "Coal", "Safety"],
    requirements: ["Mining/Mechanical engineering", "Safety protocols", "Environmental systems"],
    category: "Mining Engineering",
  },
  {
    id: 30,
    title: "Telecommunications Engineering Intern",
    company: "Bharat Sanchar Nigam Limited (BSNL)",
    location: "New Delhi, Bangalore",
    duration: "4 months",
    stipend: "₹20,000 per month",
    deadline: "2025-10-15",
    eligibility: ["3rd Year", "4th Year", "Electronics", "Telecommunications"],
    type: "Engineering",
    mode: "On-site",
    description: "Work on telecom infrastructure, 5G technology implementation, and network optimization.",
    link: "https://www.bsnl.co.in/careers",
    tags: ["PSU", "Telecom", "5G", "Networks"],
    requirements: ["Electronics/Telecom", "Network protocols", "Communication systems"],
    category: "Telecommunications",
  },
  {
    id: 31,
    title: "Technology Analyst Intern",
    company: "JPMorgan Chase & Co.",
    location: "Mumbai, Bangalore",
    duration: "10 weeks",
    stipend: "₹80,000 per month",
    deadline: "2025-11-30",
    eligibility: ["Final Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "On-site",
    description: "Develop trading platforms, risk management systems, and blockchain solutions for global banking.",
    link: "https://careers.jpmorgan.com/students",
    tags: ["Banking", "FinTech", "Trading", "Blockchain"],
    requirements: ["Java/Python", "Financial systems", "Database design"],
    category: "Financial Technology",
  },
  {
    id: 32,
    title: "Quantitative Research Intern",
    company: "Deutsche Bank",
    location: "Mumbai, India",
    duration: "12 weeks",
    stipend: "₹75,000 per month",
    deadline: "2025-12-15",
    eligibility: ["Final Year", "Computer Science", "Mathematics"],
    type: "Research",
    mode: "On-site",
    description: "Build mathematical models for derivatives pricing, risk assessment, and algorithmic trading.",
    link: "https://careers.db.com/students",
    tags: ["Banking", "Quant", "Mathematical Modeling", "Trading"],
    requirements: ["Mathematics/Statistics", "Python/R", "Financial modeling"],
    category: "Quantitative Finance",
  },
  {
    id: 33,
    title: "Digital Banking Intern",
    company: "HDFC Bank",
    location: "Mumbai, Pune",
    duration: "6 months",
    stipend: "₹45,000 per month",
    deadline: "2025-12-31",
    eligibility: ["3rd Year", "4th Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "Hybrid",
    description: "Develop mobile banking apps, payment gateways, and digital lending platforms.",
    link: "https://www.hdfcbank.com/careers",
    tags: ["Banking", "Mobile Apps", "Digital Payments", "Lending"],
    requirements: ["Mobile development", "API integration", "Security protocols"],
    category: "Digital Banking",
  },
  {
    id: 34,
    title: "Technology Consulting Intern",
    company: "Deloitte",
    location: "Bangalore, Hyderabad",
    duration: "8 weeks",
    stipend: "₹55,000 per month",
    deadline: "2025-11-15",
    eligibility: ["Final Year", "All Branches"],
    type: "Analytics",
    mode: "Hybrid",
    description: "Work on digital transformation projects, cloud migration, and business process optimization.",
    link: "https://www2.deloitte.com/in/en/pages/careers/articles/campus-hiring.html",
    tags: ["Consulting", "Digital Transformation", "Cloud", "Process Optimization"],
    requirements: ["Analytical thinking", "Business acumen", "Technology understanding"],
    category: "Technology Consulting",
  },
  {
    id: 35,
    title: "Data Analytics Intern",
    company: "PwC India",
    location: "Mumbai, Bangalore",
    duration: "10 weeks",
    stipend: "₹50,000 per month",
    deadline: "2025-12-01",
    eligibility: ["3rd Year", "4th Year", "All Branches"],
    type: "Analytics",
    mode: "Hybrid",
    description: "Analyze business data, create insights dashboards, and support strategic decision-making.",
    link: "https://www.pwc.in/careers/campus-hiring.html",
    tags: ["Consulting", "Data Analytics", "Business Intelligence", "Strategy"],
    requirements: ["Data analysis", "Excel/SQL", "Visualization tools"],
    category: "Business Analytics",
  },
  {
    id: 36,
    title: "Management Consulting Intern",
    company: "McKinsey & Company",
    location: "Mumbai, New Delhi",
    duration: "8 weeks",
    stipend: "₹90,000 per month",
    deadline: "2025-10-31",
    eligibility: ["Final Year", "All Branches"],
    type: "Analytics",
    mode: "On-site",
    description: "Support client engagements in strategy, operations, and digital transformation across industries.",
    link: "https://www.mckinsey.com/careers/students",
    tags: ["Top Consulting", "Strategy", "Operations", "Digital"],
    requirements: ["Problem solving", "Communication", "Analytical skills"],
    category: "Strategy Consulting",
  },
  {
    id: 37,
    title: "Biomedical Engineering Intern",
    company: "Siemens Healthineers",
    location: "Bangalore, India",
    duration: "6 months",
    stipend: "₹40,000 per month",
    deadline: "2025-11-30",
    eligibility: ["3rd Year", "4th Year", "Biomedical", "Electronics"],
    type: "Engineering",
    mode: "On-site",
    description: "Develop medical imaging systems, diagnostic equipment, and healthcare AI solutions.",
    link: "https://www.siemens-healthineers.com/careers",
    tags: ["Healthcare", "Medical Devices", "AI", "Imaging"],
    requirements: ["Biomedical/Electronics", "Medical systems", "Programming"],
    category: "Biomedical Engineering",
  },
  {
    id: 38,
    title: "Pharmaceutical Research Intern",
    company: "Dr. Reddy's Laboratories",
    location: "Hyderabad, India",
    duration: "5 months",
    stipend: "₹35,000 per month",
    deadline: "2025-12-15",
    eligibility: ["3rd Year", "4th Year", "Chemical", "Biotechnology"],
    type: "Research",
    mode: "On-site",
    description: "Participate in drug discovery, formulation development, and quality control processes.",
    link: "https://www.drreddys.com/careers/",
    tags: ["Pharma", "Drug Discovery", "Quality Control", "Research"],
    requirements: ["Chemistry/Biotechnology", "Lab techniques", "Analytical skills"],
    category: "Pharmaceutical Research",
  },
  {
    id: 39,
    title: "Digital Health Intern",
    company: "Practo",
    location: "Bangalore, India",
    duration: "4 months",
    stipend: "₹48,000 per month",
    deadline: "2025-12-31",
    eligibility: ["2nd Year", "3rd Year", "4th Year", "Computer Science"],
    type: "Tech",
    mode: "Hybrid",
    description: "Build healthcare platforms, telemedicine solutions, and health data analytics systems.",
    link: "https://www.practo.com/careers",
    tags: ["HealthTech", "Telemedicine", "Healthcare Analytics", "Digital Health"],
    requirements: ["Web development", "Healthcare domain", "API integration"],
    category: "Healthcare Technology",
  },
  {
    id: 40,
    title: "Industrial Automation Intern",
    company: "Larsen & Toubro",
    location: "Mumbai, Chennai",
    duration: "6 months",
    stipend: "₹38,000 per month",
    deadline: "2025-11-15",
    eligibility: ["3rd Year", "4th Year", "Mechanical", "Electrical", "Electronics"],
    type: "Engineering",
    mode: "On-site",
    description: "Work on industrial automation systems, robotics, and smart manufacturing solutions.",
    link: "https://www.larsentoubro.com/careers/",
    tags: ["Manufacturing", "Automation", "Robotics", "Industry 4.0"],
    requirements: ["Automation systems", "PLC programming", "Industrial engineering"],
    category: "Industrial Automation",
  },
  {
    id: 41,
    title: "Process Engineering Intern",
    company: "Reliance Industries",
    location: "Jamnagar, Mumbai",
    duration: "6 months",
    stipend: "₹42,000 per month",
    deadline: "2025-12-31",
    eligibility: ["3rd Year", "4th Year", "Chemical", "Petroleum"],
    type: "Engineering",
    mode: "On-site",
    description: "Optimize refinery processes, petrochemical production, and develop sustainable technologies.",
    link: "https://www.ril.com/careers",
    tags: ["Petrochemicals", "Refinery", "Process Optimization", "Sustainability"],
    requirements: ["Chemical/Petroleum engineering", "Process design", "Safety systems"],
    category: "Process Engineering",
  },
  {
    id: 42,
    title: "Quality Engineering Intern",
    company: "Mahindra & Mahindra",
    location: "Pune, Chennai",
    duration: "5 months",
    stipend: "₹36,000 per month",
    deadline: "2025-11-30",
    eligibility: ["3rd Year", "4th Year", "Mechanical", "Industrial"],
    type: "Engineering",
    mode: "On-site",
    description: "Implement quality control systems, Six Sigma methodologies, and lean manufacturing practices.",
    link: "https://www.mahindra.com/careers",
    tags: ["Automotive", "Quality Control", "Six Sigma", "Lean Manufacturing"],
    requirements: ["Quality systems", "Statistical analysis", "Manufacturing processes"],
    category: "Quality Engineering",
  },
  {
    id: 43,
    title: "Blockchain Developer Intern",
    company: "Polygon Technology",
    location: "Bangalore, India",
    duration: "4 months",
    stipend: "₹70,000 per month",
    deadline: "2025-12-15",
    eligibility: ["3rd Year", "4th Year", "Computer Science"],
    type: "Tech",
    mode: "Remote",
    description: "Develop decentralized applications, smart contracts, and blockchain infrastructure solutions.",
    link: "https://polygon.technology/careers",
    tags: ["Blockchain", "Web3", "Smart Contracts", "DeFi"],
    requirements: ["Solidity", "JavaScript", "Blockchain concepts", "Cryptography"],
    category: "Blockchain Development",
  },
  {
    id: 44,
    title: "Cybersecurity Intern",
    company: "Quick Heal Technologies",
    location: "Pune, India",
    duration: "6 months",
    stipend: "₹32,000 per month",
    deadline: "2025-12-31",
    eligibility: ["3rd Year", "4th Year", "Computer Science", "IT"],
    type: "Tech",
    mode: "On-site",
    description: "Work on threat detection, malware analysis, and cybersecurity solution development.",
    link: "https://www.quickheal.com/careers",
    tags: ["Cybersecurity", "Threat Detection", "Malware Analysis", "Security"],
    requirements: ["Network security", "Ethical hacking", "Security tools", "Programming"],
    category: "Cybersecurity",
  },
  {
    id: 45,
    title: "IoT Solutions Intern",
    company: "Tata Consultancy Services",
    location: "Pune, Bangalore",
    duration: "6 months",
    stipend: "₹28,000 per month",
    deadline: "2025-12-31",
    eligibility: ["2nd Year", "3rd Year", "4th Year", "Electronics", "Computer Science"],
    type: "Tech",
    mode: "Hybrid",
    description: "Develop IoT platforms, sensor networks, and connected device solutions for smart cities.",
    link: "https://www.tcs.com/careers/students-and-graduates",
    tags: ["IoT", "Smart Cities", "Sensors", "Connected Devices"],
    requirements: ["Embedded systems", "Sensor technology", "Cloud platforms", "Programming"],
    category: "IoT Development",
  },
  {
    id: 46,
    title: "Materials Science Research Intern",
    company: "Indian Institute of Technology (IIT) Bombay",
    location: "Mumbai, India",
    duration: "8 weeks",
    stipend: "₹15,000 per month",
    deadline: "2025-03-31",
    eligibility: ["3rd Year", "4th Year", "Materials", "Mechanical", "Chemical"],
    type: "Research",
    mode: "On-site",
    description: "Conduct research on advanced materials, nanotechnology, and sustainable material development.",
    link: "https://www.iitb.ac.in/academic/internships",
    tags: ["Research", "Materials Science", "Nanotechnology", "IIT"],
    requirements: ["Materials science", "Lab techniques", "Research methodology"],
    category: "Materials Research",
  },
  {
    id: 47,
    title: "AI Ethics Research Intern",
    company: "Indian Institute of Technology (IIT) Delhi",
    location: "New Delhi, India",
    duration: "10 weeks",
    stipend: "₹16,000 per month",
    deadline: "2025-04-15",
    eligibility: ["Final Year", "Computer Science", "Philosophy"],
    type: "Research",
    mode: "On-site",
    description: "Research AI ethics, algorithmic bias, and responsible AI development practices.",
    link: "https://home.iitd.ac.in/internship.php",
    tags: ["Research", "AI Ethics", "Algorithmic Bias", "IIT"],
    requirements: ["AI/ML knowledge", "Ethics background", "Research skills"],
    category: "AI Ethics Research",
  },
  {
    id: 48,
    title: "Clean Energy Research Intern",
    company: "Indian Institute of Science (IISc) Bangalore",
    location: "Bangalore, India",
    duration: "12 weeks",
    stipend: "₹18,000 per month",
    deadline: "2025-02-28",
    eligibility: ["3rd Year", "4th Year", "Electrical", "Chemical", "Environmental"],
    type: "Research",
    mode: "On-site",
    description: "Research solar cells, fuel cells, and energy storage technologies for sustainable energy solutions.",
    link: "https://www.iisc.ac.in/admissions/summer-research-fellowship/",
    tags: ["Research", "Clean Energy", "Solar", "Energy Storage"],
    requirements: ["Energy systems", "Materials science", "Electrochemistry"],
    category: "Clean Energy Research",
  },
]

export default function InternshipsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedYear, setSelectedYear] = useState("all")
  const [selectedBranch, setSelectedBranch] = useState("all")
  const [selectedType, setSelectedType] = useState("all")
  const [selectedMode, setSelectedMode] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const filteredInternships = useMemo(() => {
    return internships.filter((internship) => {
      const matchesSearch =
        internship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        internship.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        internship.description.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesYear =
        selectedYear === "all" ||
        internship.eligibility.includes(selectedYear) ||
        internship.eligibility.includes("All Years")

      const matchesBranch =
        selectedBranch === "all" ||
        internship.eligibility.includes(selectedBranch) ||
        internship.eligibility.includes("All Branches")

      const matchesType = selectedType === "all" || internship.type === selectedType

      const matchesMode = selectedMode === "all" || internship.mode === selectedMode

      const matchesCategory = selectedCategory === "all" || internship.category === selectedCategory

      return matchesSearch && matchesYear && matchesBranch && matchesType && matchesMode && matchesCategory
    })
  }, [searchTerm, selectedYear, selectedBranch, selectedType, selectedMode, selectedCategory])

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 dark:from-gray-900 dark:via-orange-900 dark:to-purple-900">
      {/* Navigation */}
      <nav className="border-b bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-orange-600 to-pink-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-orange-600 dark:text-orange-400">EduOpportunity</span>
              </Link>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-600 dark:text-gray-300 hover:text-orange-600 transition-colors">
                Home
              </Link>
              <Link
                href="/scholarships"
                className="text-gray-600 dark:text-gray-300 hover:text-orange-600 transition-colors"
              >
                Scholarships
              </Link>
              <Link
                href="/internships"
                className="text-gray-900 dark:text-white hover:text-orange-600 transition-colors font-medium"
              >
                Internships
              </Link>
              <Link
                href="/state-scholarships"
                className="text-gray-600 dark:text-gray-300 hover:text-orange-600 transition-colors"
              >
                State Scholarships
              </Link>
              <Link href="/about" className="text-gray-600 dark:text-gray-300 hover:text-orange-600 transition-colors">
                About
              </Link>
            </div>

            <Button
              asChild
              variant="outline"
              className="border-orange-300 text-orange-700 hover:bg-orange-50 bg-transparent"
            >
              <Link href="/scholarships">Browse Scholarships</Link>
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <Badge className="mb-4 bg-gradient-to-r from-orange-100 to-pink-100 text-orange-800 border-orange-200">
            <Sparkles className="w-4 h-4 mr-1" />
            Premium Internship Opportunities
          </Badge>
          <h1 className="text-3xl md:text-4xl font-bold text-orange-600 dark:text-orange-400 mb-4">
            Internships for B.Tech Students
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Explore {internships.length}+ internship opportunities from FAANG, unicorns, and top companies
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg border border-orange-200 p-6 mb-8 shadow-lg">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
            {/* Search */}
            <div className="lg:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-orange-500 w-4 h-4" />
                <Input
                  placeholder="Search internships..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-orange-200 focus:border-orange-400"
                />
              </div>
            </div>

            {/* Year Filter */}
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="border-orange-200">
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Years</SelectItem>
                <SelectItem value="1st Year">1st Year</SelectItem>
                <SelectItem value="2nd Year">2nd Year</SelectItem>
                <SelectItem value="3rd Year">3rd Year</SelectItem>
                <SelectItem value="4th Year">4th Year</SelectItem>
                <SelectItem value="Final Year">Final Year</SelectItem>
              </SelectContent>
            </Select>

            {/* Branch Filter */}
            <Select value={selectedBranch} onValueChange={setSelectedBranch}>
              <SelectTrigger className="border-orange-200">
                <SelectValue placeholder="Branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                <SelectItem value="Computer Science">Computer Science</SelectItem>
                <SelectItem value="IT">Information Technology</SelectItem>
                <SelectItem value="Mechanical">Mechanical</SelectItem>
                <SelectItem value="Electrical">Electrical</SelectItem>
                <SelectItem value="Civil">Civil</SelectItem>
                <SelectItem value="Aerospace">Aerospace</SelectItem>
                <SelectItem value="Electronics">Electronics</SelectItem>
              </SelectContent>
            </Select>

            {/* Type Filter */}
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="border-orange-200">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Tech">Tech</SelectItem>
                <SelectItem value="Product">Product</SelectItem>
                <SelectItem value="Engineering">Engineering</SelectItem>
                <SelectItem value="Research">Research</SelectItem>
                <SelectItem value="Design">Design</SelectItem>
                <SelectItem value="Analytics">Analytics</SelectItem>
              </SelectContent>
            </Select>

            {/* Mode Filter */}
            <Select value={selectedMode} onValueChange={setSelectedMode}>
              <SelectTrigger className="border-orange-200">
                <SelectValue placeholder="Mode" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Modes</SelectItem>
                <SelectItem value="On-site">On-site</SelectItem>
                <SelectItem value="Remote">Remote</SelectItem>
                <SelectItem value="Hybrid">Hybrid</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Category Filter Row */}
          <div className="mt-4">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="border-orange-200 max-w-xs">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Software Development">Software Development</SelectItem>
                <SelectItem value="Data Science">Data Science</SelectItem>
                <SelectItem value="Frontend Development">Frontend Development</SelectItem>
                <SelectItem value="Backend Development">Backend Development</SelectItem>
                <SelectItem value="Mobile Development">Mobile Development</SelectItem>
                <SelectItem value="Product Management">Product Management</SelectItem>
                <SelectItem value="Machine Learning">Machine Learning</SelectItem>
                <SelectItem value="DevOps">DevOps</SelectItem>
                <SelectItem value="Research">Research</SelectItem>
                <SelectItem value="Engineering">Engineering</SelectItem>
                <SelectItem value="Financial Technology">Financial Technology</SelectItem>
                <SelectItem value="Payment Technology">Payment Technology</SelectItem>
                <SelectItem value="E-commerce Technology">E-commerce Technology</SelectItem>
                <SelectItem value="Quantitative Finance">Quantitative Finance</SelectItem>
                <SelectItem value="Creative Technology">Creative Technology</SelectItem>
                <SelectItem value="AI Research">AI Research</SelectItem>
                <SelectItem value="Generative AI">Generative AI</SelectItem>
                <SelectItem value="Electric Vehicle Engineering">Electric Vehicle Engineering</SelectItem>
                <SelectItem value="Renewable Energy">Renewable Energy</SelectItem>
                <SelectItem value="Space Technology">Space Technology</SelectItem>
                <SelectItem value="Aerospace Engineering">Aerospace Engineering</SelectItem>
                <SelectItem value="Defense Technology">Defense Technology</SelectItem>
                <SelectItem value="Nuclear Technology">Nuclear Technology</SelectItem>
                <SelectItem value="Transportation Engineering">Transportation Engineering</SelectItem>
                <SelectItem value="Atmospheric Sciences">Atmospheric Sciences</SelectItem>
                <SelectItem value="Power Systems">Power Systems</SelectItem>
                <SelectItem value="Petroleum Engineering">Petroleum Engineering</SelectItem>
                <SelectItem value="Metallurgical Engineering">Metallurgical Engineering</SelectItem>
                <SelectItem value="Mining Engineering">Mining Engineering</SelectItem>
                <SelectItem value="Telecommunications">Telecommunications</SelectItem>
                <SelectItem value="Digital Banking">Digital Banking</SelectItem>
                <SelectItem value="Technology Consulting">Technology Consulting</SelectItem>
                <SelectItem value="Business Analytics">Business Analytics</SelectItem>
                <SelectItem value="Strategy Consulting">Strategy Consulting</SelectItem>
                <SelectItem value="Biomedical Engineering">Biomedical Engineering</SelectItem>
                <SelectItem value="Pharmaceutical Research">Pharmaceutical Research</SelectItem>
                <SelectItem value="Healthcare Technology">Healthcare Technology</SelectItem>
                <SelectItem value="Industrial Automation">Industrial Automation</SelectItem>
                <SelectItem value="Process Engineering">Process Engineering</SelectItem>
                <SelectItem value="Quality Engineering">Quality Engineering</SelectItem>
                <SelectItem value="Blockchain Development">Blockchain Development</SelectItem>
                <SelectItem value="Cybersecurity">Cybersecurity</SelectItem>
                <SelectItem value="IoT Development">IoT Development</SelectItem>
                <SelectItem value="Materials Research">Materials Research</SelectItem>
                <SelectItem value="AI Ethics Research">AI Ethics Research</SelectItem>
                <SelectItem value="Clean Energy Research">Clean Energy Research</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between mt-4 pt-4 border-t border-orange-200">
            <div className="text-sm text-gray-600 dark:text-gray-300">
              Showing {filteredInternships.length} of {internships.length} internships
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSearchTerm("")
                setSelectedYear("all")
                setSelectedBranch("all")
                setSelectedType("all")
                setSelectedMode("all")
                setSelectedCategory("all")
              }}
              className="border-orange-300 text-orange-700 hover:bg-orange-50"
            >
              Clear Filters
            </Button>
          </div>
        </div>

        {/* Internship Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredInternships.map((internship) => (
            <Card
              key={internship.id}
              className="hover:shadow-xl transition-all duration-300 hover:scale-105 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg"
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg mb-2 text-balance text-gray-900 dark:text-white">
                      {internship.title}
                    </CardTitle>
                    <CardDescription className="flex items-center text-sm mb-2 text-gray-600 dark:text-gray-300">
                      <Building className="w-4 h-4 mr-1" />
                      {internship.company}
                    </CardDescription>
                  </div>
                  <Badge
                    variant={
                      internship.mode === "Remote" ? "secondary" : internship.mode === "Hybrid" ? "outline" : "default"
                    }
                    className={
                      internship.mode === "Remote"
                        ? "bg-gradient-to-r from-green-500 to-teal-500 text-white"
                        : internship.mode === "Hybrid"
                          ? "bg-gradient-to-r from-blue-500 to-indigo-500 text-white"
                          : "bg-gradient-to-r from-orange-500 to-red-500 text-white"
                    }
                  >
                    {internship.mode}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-4">
                  <p className="text-sm text-gray-600 dark:text-gray-300 text-pretty">{internship.description}</p>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center text-green-600 font-semibold">
                      <IndianRupee className="w-4 h-4 mr-1" />
                      {internship.stipend}
                    </div>
                    <div className="flex items-center text-blue-600">
                      <Clock className="w-4 h-4 mr-1" />
                      {internship.duration}
                    </div>
                    <div className="flex items-center text-purple-600 col-span-2">
                      <MapPin className="w-4 h-4 mr-1" />
                      {internship.location}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">Eligibility:</div>
                    <div className="flex flex-wrap gap-1">
                      {internship.eligibility.map((item, index) => (
                        <Badge key={index} variant="outline" className="text-xs border-orange-200 text-orange-700">
                          {item}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">Key Requirements:</div>
                    <ul className="text-xs text-gray-600 dark:text-gray-300 space-y-1">
                      {internship.requirements.slice(0, 2).map((req, index) => (
                        <li key={index} className="flex items-start">
                          <span className="w-1 h-1 bg-orange-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {internship.tags.map((tag, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="text-xs bg-gradient-to-r from-pink-100 to-purple-100 text-pink-700"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-orange-100">
                    <div className="flex items-center text-xs text-orange-600">
                      <Calendar className="w-3 h-3 mr-1" />
                      Deadline: {new Date(internship.deadline).toLocaleDateString()}
                    </div>
                  </div>

                  <Button
                    asChild
                    className="w-full bg-gradient-to-r from-orange-600 to-pink-600 hover:from-orange-700 hover:to-pink-700 text-white"
                  >
                    <a href={internship.link} target="_blank" rel="noopener noreferrer" className="text-white">
                      Apply Now
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredInternships.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-orange-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">No internships found</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Try adjusting your filters or search terms to find more opportunities.
            </p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchTerm("")
                setSelectedYear("all")
                setSelectedBranch("all")
                setSelectedType("all")
                setSelectedMode("all")
                setSelectedCategory("all")
              }}
              className="border-orange-300 text-orange-700 hover:bg-orange-50"
            >
              Clear All Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
