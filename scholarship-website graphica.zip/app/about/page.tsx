import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BookOpen, Users, Target, Eye, Heart, Award, TrendingUp, Shield, Sparkles, GraduationCap } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/20">
      {/* Navigation */}
      <nav className="glassmorphism bg-card/60 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">EduOpportunity</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/scholarships" className="text-muted-foreground hover:text-primary transition-colors">
                Scholarships
              </Link>
              <Link href="/internships" className="text-muted-foreground hover:text-primary transition-colors">
                Internships
              </Link>
              <Link href="/state-scholarships" className="text-muted-foreground hover:text-primary transition-colors">
                State Scholarships
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors font-medium">
                About Us
              </Link>
            </div>

            <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg pulse-glow">
              <Link href="/scholarships">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-r from-primary/30 to-purple-500/30 rounded-full blur-3xl float-animation"></div>
          <div
            className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-r from-cyan-400/30 to-blue-500/30 rounded-full blur-3xl float-animation"
            style={{ animationDelay: "2s" }}
          ></div>
        </div>

        <div className="max-w-4xl mx-auto text-center relative">
          <Badge
            variant="secondary"
            className="mb-6 glassmorphism bg-primary/80 text-white border-primary/20 pulse-glow"
          >
            <Heart className="w-4 h-4 mr-1" />
            About EduOpportunity
          </Badge>

          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Empowering Students
            <span className="block text-primary mt-2">Through Opportunities</span>
          </h1>

          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty">
            At EduOpportunity, we believe that every student deserves equal access to the best opportunities. Our
            mission is to simplify the journey of finding scholarships, internships, and state-sponsored programs by
            bringing them all together in one easy-to-use platform.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            {/* Our Story */}
            <Card className="glassmorphism bg-card/60 border-primary/20 shadow-xl">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-primary to-purple-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-2xl text-primary">Our Story</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  We understand how time-consuming and overwhelming it can be for students to search across multiple
                  websites. That's why we've built a centralized hub tailored for B.Tech students—where opportunities
                  meet ambition.
                </p>
                <br />
                <p className="text-muted-foreground leading-relaxed">
                  With 1000+ scholarships, 500+ internships, and regular updates, EduOpportunity is not just a platform
                  but a gateway to success. Whether you are in your first year exploring options or in your final year
                  preparing for your career, we've got you covered.
                </p>
              </CardContent>
            </Card>

            {/* Statistics */}
            <div className="grid grid-cols-2 gap-6">
              <Card className="glassmorphism bg-card/60 border-primary/20 shadow-xl text-center p-6">
                <div className="text-4xl font-bold text-primary mb-2">1000+</div>
                <div className="text-sm text-muted-foreground">Scholarships Available</div>
              </Card>
              <Card className="glassmorphism bg-card/60 border-orange-500/20 shadow-xl text-center p-6">
                <div className="text-4xl font-bold text-orange-500 mb-2">500+</div>
                <div className="text-sm text-muted-foreground">Internship Opportunities</div>
              </Card>
              <Card className="glassmorphism bg-card/60 border-cyan-500/20 shadow-xl text-center p-6">
                <div className="text-4xl font-bold text-cyan-500 mb-2">50K+</div>
                <div className="text-sm text-muted-foreground">Students Helped</div>
              </Card>
              <Card className="glassmorphism bg-card/60 border-green-500/20 shadow-xl text-center p-6">
                <div className="text-4xl font-bold text-green-500 mb-2">24/7</div>
                <div className="text-sm text-muted-foreground">Platform Updates</div>
              </Card>
            </div>
          </div>

          {/* Vision & Mission */}
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            <Card className="glassmorphism bg-card/60 border-cyan-500/20 shadow-xl">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                  <Eye className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-2xl text-cyan-600 dark:text-cyan-400">Our Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed text-lg">
                  To empower students by making education and career opportunities more accessible, transparent, and
                  organized.
                </p>
              </CardContent>
            </Card>

            <Card className="glassmorphism bg-card/60 border-orange-500/20 shadow-xl">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-2xl text-orange-600 dark:text-orange-400">Our Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed text-lg">
                  To connect students with the right opportunities at the right time—helping them achieve their academic
                  and professional goals with confidence.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* What Makes Us Different */}
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What Makes Us Different</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We're not just another opportunity platform - we're your dedicated partner in academic and career success.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="glassmorphism bg-card/60 border-primary/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-primary to-purple-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                  <GraduationCap className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-primary">B.Tech Focused</CardTitle>
                <CardDescription>
                  Specifically curated for B.Tech students across all branches and years of study.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="glassmorphism bg-card/60 border-green-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-green-600 dark:text-green-400">Always Updated</CardTitle>
                <CardDescription>
                  Fresh opportunities added daily with real-time notifications and deadline reminders.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="glassmorphism bg-card/60 border-pink-500/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-rose-600 rounded-xl flex items-center justify-center mb-4 pulse-glow">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-pink-600 dark:text-pink-400">Verified & Trusted</CardTitle>
                <CardDescription>
                  All opportunities are verified and constantly monitored for authenticity and relevance.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-purple-600/10 to-cyan-600/10"></div>
        <div className="max-w-4xl mx-auto text-center relative">
          <div className="glassmorphism bg-card/40 p-12 rounded-3xl shadow-2xl">
            <Sparkles className="w-16 h-16 text-primary mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Ready to Start Your Journey?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join thousands of B.Tech students who have already discovered their perfect opportunities through our
              platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                asChild
                className="text-lg px-8 bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl pulse-glow"
              >
                <Link href="/scholarships">
                  <Award className="w-5 h-5 mr-2" />
                  Explore Scholarships
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="text-lg px-8 glassmorphism border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground shadow-xl bg-transparent"
              >
                <Link href="/internships">
                  <Users className="w-5 h-5 mr-2" />
                  Find Internships
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="glassmorphism bg-card/60 border-t border-border/50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-foreground">EduOpportunity</span>
              </div>
              <p className="text-muted-foreground">Your one-stop platform for B.Tech scholarships and internships.</p>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link href="/scholarships" className="block text-muted-foreground hover:text-primary transition-colors">
                  Scholarships
                </Link>
                <Link href="/internships" className="block text-muted-foreground hover:text-primary transition-colors">
                  Internships
                </Link>
                <Link href="/about" className="block text-muted-foreground hover:text-primary transition-colors">
                  About Us
                </Link>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-4">Categories</h3>
              <div className="space-y-2">
                <div className="text-muted-foreground">Merit-based</div>
                <div className="text-muted-foreground">Need-based</div>
                <div className="text-muted-foreground">Research</div>
                <div className="text-muted-foreground">Industry</div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-4">Support</h3>
              <div className="space-y-2">
                <div className="text-muted-foreground">Help Center</div>
                <div className="text-muted-foreground">Contact Us</div>
                <div className="text-muted-foreground">Privacy Policy</div>
                <div className="text-muted-foreground">Terms of Service</div>
              </div>
            </div>
          </div>

          <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2025 EduOpportunity. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
