"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import {
  BookOpen,
  CalendarIcon,
  Clock,
  Bell,
  AlertTriangle,
  CheckCircle,
  Plus,
  Download,
  Mail,
  MessageSquare,
  Smartphone,
  Settings,
  Filter,
  Search,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface Deadline {
  id: string
  title: string
  type: "scholarship" | "internship"
  deadline: Date
  daysLeft: number
  status: "upcoming" | "urgent" | "overdue" | "completed"
  reminderSet: boolean
  description: string
  requirements: string[]
  amount?: string
  company?: string
}

export default function DeadlinesPage() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [notificationSettings, setNotificationSettings] = useState({
    email: true,
    sms: false,
    whatsapp: true,
    push: true,
  })

  const [deadlines, setDeadlines] = useState<Deadline[]>([
    {
      id: "1",
      title: "Google AI Research Scholarship",
      type: "scholarship",
      deadline: new Date("2025-02-15"),
      daysLeft: 33,
      status: "upcoming",
      reminderSet: true,
      description: "Application deadline for Google AI Research Scholarship program",
      requirements: ["Research proposal", "Academic transcripts", "Recommendation letters"],
      amount: "₹2,00,000",
    },
    {
      id: "2",
      title: "Microsoft Internship Program",
      type: "internship",
      deadline: new Date("2025-01-30"),
      daysLeft: 17,
      status: "urgent",
      reminderSet: true,
      description: "Summer internship application deadline",
      requirements: ["Resume", "Cover letter", "Portfolio"],
      company: "Microsoft",
    },
    {
      id: "3",
      title: "Amazon Web Services Scholarship",
      type: "scholarship",
      deadline: new Date("2025-02-28"),
      daysLeft: 46,
      status: "upcoming",
      reminderSet: false,
      description: "AWS Cloud Computing Scholarship deadline",
      requirements: ["Online assessment", "Project submission"],
      amount: "₹1,50,000",
    },
    {
      id: "4",
      title: "Tesla Engineering Internship",
      type: "internship",
      deadline: new Date("2025-01-10"),
      daysLeft: -3,
      status: "overdue",
      reminderSet: false,
      description: "Engineering internship application (missed)",
      requirements: ["Technical interview", "Portfolio"],
      company: "Tesla",
    },
  ])

  const toggleReminder = (id: string) => {
    setDeadlines((prev) =>
      prev.map((deadline) => (deadline.id === id ? { ...deadline, reminderSet: !deadline.reminderSet } : deadline)),
    )
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "urgent":
        return "text-red-600 bg-red-100 dark:bg-red-900/20"
      case "upcoming":
        return "text-blue-600 bg-blue-100 dark:bg-blue-900/20"
      case "overdue":
        return "text-gray-600 bg-gray-100 dark:bg-gray-900/20"
      case "completed":
        return "text-green-600 bg-green-100 dark:bg-green-900/20"
      default:
        return "text-gray-600 bg-gray-100 dark:bg-gray-900/20"
    }
  }

  const upcomingDeadlines = deadlines.filter((d) => d.status === "upcoming" || d.status === "urgent")
  const overdueDeadlines = deadlines.filter((d) => d.status === "overdue")
  const urgentDeadlines = deadlines.filter((d) => d.status === "urgent")

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/20">
      {/* Navigation */}
      <nav className="glassmorphism bg-card/60 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">EduOpportunity</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/dashboard" className="text-muted-foreground hover:text-primary transition-colors">
                Dashboard
              </Link>
              <Link href="/deadlines" className="text-foreground hover:text-primary transition-colors font-medium">
                Deadlines
              </Link>
            </div>

            <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg pulse-glow">
              <Link href="/dashboard">Dashboard</Link>
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Deadline Manager</h1>
          <p className="text-muted-foreground">
            Never miss an opportunity again with smart reminders and calendar integration.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar - Calendar & Settings */}
          <div className="lg:col-span-1 space-y-6">
            {/* Calendar */}
            <Card className="glassmorphism bg-card/60 border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <CalendarIcon className="w-5 h-5 mr-2 text-primary" />
                  Calendar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border-0"
                />
                <div className="mt-4 space-y-2">
                  <Button size="sm" className="w-full bg-primary hover:bg-primary/90">
                    <Download className="w-4 h-4 mr-2" />
                    Export to Google Calendar
                  </Button>
                  <Button variant="outline" size="sm" className="w-full bg-transparent">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Custom Deadline
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Notification Settings */}
            <Card className="glassmorphism bg-card/60">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Bell className="w-5 h-5 mr-2 text-primary" />
                  Notifications
                </CardTitle>
                <CardDescription>Configure your reminder preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Mail className="w-4 h-4 text-primary" />
                    <Label htmlFor="email">Email</Label>
                  </div>
                  <Switch
                    id="email"
                    checked={notificationSettings.email}
                    onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, email: checked }))}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Smartphone className="w-4 h-4 text-primary" />
                    <Label htmlFor="sms">SMS</Label>
                  </div>
                  <Switch
                    id="sms"
                    checked={notificationSettings.sms}
                    onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, sms: checked }))}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="w-4 h-4 text-primary" />
                    <Label htmlFor="whatsapp">WhatsApp</Label>
                  </div>
                  <Switch
                    id="whatsapp"
                    checked={notificationSettings.whatsapp}
                    onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, whatsapp: checked }))}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Bell className="w-4 h-4 text-primary" />
                    <Label htmlFor="push">Push Notifications</Label>
                  </div>
                  <Switch
                    id="push"
                    checked={notificationSettings.push}
                    onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, push: checked }))}
                  />
                </div>
                <Button variant="outline" size="sm" className="w-full bg-transparent">
                  <Settings className="w-4 h-4 mr-2" />
                  Advanced Settings
                </Button>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="glassmorphism bg-card/60">
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Active Deadlines</span>
                  <span className="font-medium">{upcomingDeadlines.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Urgent (&lt; 7 days)</span>
                  <span className="font-medium text-red-600">{urgentDeadlines.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Reminders Set</span>
                  <span className="font-medium text-green-600">{deadlines.filter((d) => d.reminderSet).length}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="upcoming" className="space-y-6">
              <div className="flex items-center justify-between">
                <TabsList className="glassmorphism bg-card/60">
                  <TabsTrigger value="upcoming" className="flex items-center space-x-2">
                    <Clock className="w-4 h-4" />
                    <span>Upcoming</span>
                  </TabsTrigger>
                  <TabsTrigger value="overdue" className="flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Overdue</span>
                  </TabsTrigger>
                  <TabsTrigger value="completed" className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4" />
                    <span>Completed</span>
                  </TabsTrigger>
                </TabsList>

                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" size="sm">
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                </div>
              </div>

              <TabsContent value="upcoming" className="space-y-4">
                {upcomingDeadlines.map((deadline) => (
                  <Card
                    key={deadline.id}
                    className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <Badge variant={deadline.type === "scholarship" ? "default" : "secondary"}>
                              {deadline.type}
                            </Badge>
                            <Badge className={getStatusColor(deadline.status)}>
                              {deadline.status === "urgent" ? "Urgent" : "Upcoming"}
                            </Badge>
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">
                                {deadline.daysLeft > 0 ? `${deadline.daysLeft} days left` : "Due today"}
                              </span>
                            </div>
                          </div>
                          <h3 className="text-xl font-semibold text-foreground mb-2">{deadline.title}</h3>
                          <p className="text-muted-foreground mb-3">{deadline.description}</p>
                          <div className="text-sm text-muted-foreground mb-3">
                            <strong>Deadline:</strong> {deadline.deadline.toLocaleDateString()}
                          </div>
                          <div className="text-sm">
                            <p className="font-medium mb-1">Requirements:</p>
                            <ul className="text-muted-foreground space-y-1">
                              {deadline.requirements.map((req, index) => (
                                <li key={index} className="flex items-center space-x-1">
                                  <div className="w-1 h-1 bg-primary rounded-full"></div>
                                  <span>{req}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        <div className="flex flex-col items-end space-y-2 ml-4">
                          {deadline.amount && (
                            <div className="text-lg font-semibold text-green-600">{deadline.amount}</div>
                          )}
                          {deadline.company && <div className="text-sm text-muted-foreground">{deadline.company}</div>}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <Switch
                              checked={deadline.reminderSet}
                              onCheckedChange={() => toggleReminder(deadline.id)}
                            />
                            <Label className="text-sm">{deadline.reminderSet ? "Reminder set" : "Set reminder"}</Label>
                          </div>
                          {deadline.reminderSet && (
                            <div className="flex items-center space-x-1 text-green-600">
                              <Bell className="w-4 h-4" />
                              <span className="text-sm">Active</span>
                            </div>
                          )}
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                          <Button size="sm" className="bg-primary hover:bg-primary/90">
                            Apply Now
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="overdue" className="space-y-4">
                {overdueDeadlines.map((deadline) => (
                  <Card
                    key={deadline.id}
                    className="glassmorphism bg-card/60 opacity-75 hover:shadow-xl transition-all duration-300"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <Badge variant={deadline.type === "scholarship" ? "default" : "secondary"}>
                              {deadline.type}
                            </Badge>
                            <Badge className={getStatusColor(deadline.status)}>Overdue</Badge>
                            <div className="flex items-center space-x-1">
                              <AlertTriangle className="w-4 h-4 text-red-500" />
                              <span className="text-sm text-red-500">{Math.abs(deadline.daysLeft)} days overdue</span>
                            </div>
                          </div>
                          <h3 className="text-xl font-semibold text-foreground mb-2">{deadline.title}</h3>
                          <p className="text-muted-foreground mb-3">{deadline.description}</p>
                          <div className="text-sm text-muted-foreground">
                            <strong>Deadline was:</strong> {deadline.deadline.toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-muted-foreground">This opportunity has passed its deadline</div>
                        <Button variant="outline" size="sm" disabled>
                          Expired
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="completed">
                <Card className="glassmorphism bg-card/60">
                  <CardContent className="p-8 text-center">
                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No Completed Applications Yet</h3>
                    <p className="text-muted-foreground">
                      Applications you've successfully submitted will appear here.
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
