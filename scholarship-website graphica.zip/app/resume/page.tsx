"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import {
  BookOpen,
  User,
  Download,
  Share2,
  Eye,
  Edit,
  Plus,
  Trash2,
  FileText,
  Linkedin,
  Sparkles,
  Zap,
  CheckCircle,
  Settings,
  Bell,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface ResumeData {
  personalInfo: {
    name: string
    email: string
    phone: string
    location: string
    linkedinUrl: string
    portfolioUrl: string
    summary: string
  }
  education: Array<{
    id: string
    institution: string
    degree: string
    field: string
    startDate: string
    endDate: string
    cgpa: string
    achievements: string[]
  }>
  experience: Array<{
    id: string
    company: string
    position: string
    startDate: string
    endDate: string
    description: string
    skills: string[]
  }>
  projects: Array<{
    id: string
    name: string
    description: string
    technologies: string[]
    githubUrl: string
    liveUrl: string
  }>
  skills: {
    technical: string[]
    soft: string[]
    languages: string[]
  }
  certifications: Array<{
    id: string
    name: string
    issuer: string
    date: string
    credentialUrl: string
  }>
}

export default function ResumePage() {
  const [resumeData, setResumeData] = useState<ResumeData>({
    personalInfo: {
      name: "Alex Kumar",
      email: "alex.kumar@email.com",
      phone: "+91 9876543210",
      location: "Mumbai, India",
      linkedinUrl: "https://linkedin.com/in/alexkumar",
      portfolioUrl: "https://alexkumar.dev",
      summary:
        "Passionate Computer Science student with expertise in AI/ML and web development. Seeking opportunities to apply technical skills in innovative projects.",
    },
    education: [
      {
        id: "1",
        institution: "Indian Institute of Technology, Mumbai",
        degree: "Bachelor of Technology",
        field: "Computer Science and Engineering",
        startDate: "2022",
        endDate: "2026",
        cgpa: "8.5",
        achievements: ["Dean's List", "Best Project Award", "Coding Competition Winner"],
      },
    ],
    experience: [
      {
        id: "1",
        company: "TechCorp Solutions",
        position: "Software Development Intern",
        startDate: "2024-06",
        endDate: "2024-08",
        description:
          "Developed web applications using React and Node.js, collaborated with cross-functional teams, and implemented new features that improved user engagement by 25%.",
        skills: ["React", "Node.js", "MongoDB", "Git"],
      },
    ],
    projects: [
      {
        id: "1",
        name: "AI-Powered Study Assistant",
        description:
          "Built an intelligent study assistant using machine learning to help students optimize their learning patterns.",
        technologies: ["Python", "TensorFlow", "Flask", "React"],
        githubUrl: "https://github.com/alexkumar/study-assistant",
        liveUrl: "https://study-assistant.vercel.app",
      },
    ],
    skills: {
      technical: ["Python", "JavaScript", "React", "Node.js", "MongoDB", "TensorFlow", "Git"],
      soft: ["Leadership", "Communication", "Problem Solving", "Team Collaboration"],
      languages: ["English", "Hindi", "Marathi"],
    },
    certifications: [
      {
        id: "1",
        name: "AWS Cloud Practitioner",
        issuer: "Amazon Web Services",
        date: "2024-03",
        credentialUrl: "https://aws.amazon.com/verification",
      },
    ],
  })

  const [selectedTemplate, setSelectedTemplate] = useState("modern")
  const [linkedinSyncEnabled, setLinkedinSyncEnabled] = useState(false)
  const [autoUpdateEnabled, setAutoUpdateEnabled] = useState(true)

  const templates = [
    { id: "modern", name: "Modern Professional", preview: "/modern-resume-template.png" },
    { id: "classic", name: "Classic Formal", preview: "/classic-resume-template.png" },
    { id: "creative", name: "Creative Design", preview: "/creative-resume-template.png" },
    { id: "minimal", name: "Minimal Clean", preview: "/minimal-resume-template.png" },
  ]

  const handleLinkedInSync = () => {
    // Simulate LinkedIn API integration
    setLinkedinSyncEnabled(!linkedinSyncEnabled)
    if (!linkedinSyncEnabled) {
      // Simulate data sync from LinkedIn
      console.log("Syncing data from LinkedIn...")
    }
  }

  const generateAIResume = () => {
    // Simulate AI-powered resume generation
    console.log("Generating AI-optimized resume...")
  }

  const exportResume = (format: string) => {
    console.log(`Exporting resume as ${format}`)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/20">
      {/* Navigation */}
      <nav className="glassmorphism bg-card/60 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">EduOpportunity</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/dashboard" className="text-muted-foreground hover:text-primary transition-colors">
                Dashboard
              </Link>
              <Link href="/resume" className="text-foreground hover:text-primary transition-colors font-medium">
                Resume Builder
              </Link>
              <Link href="/applications" className="text-muted-foreground hover:text-primary transition-colors">
                Applications
              </Link>
              <Link href="/community" className="text-muted-foreground hover:text-primary transition-colors">
                Community
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Resume Builder & LinkedIn Integration</h1>
          <p className="text-muted-foreground">
            Create professional resumes with AI assistance and sync with your LinkedIn profile.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar - Tools & Settings */}
          <div className="lg:col-span-1 space-y-6">
            {/* LinkedIn Integration */}
            <Card className="glassmorphism bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-200 dark:border-blue-800">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center">
                    <Linkedin className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-blue-700 dark:text-blue-300">LinkedIn Sync</CardTitle>
                    <CardDescription className="text-blue-600 dark:text-blue-400">
                      Auto-sync profile data
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="linkedin-sync" className="text-sm">
                    Enable Sync
                  </Label>
                  <Switch id="linkedin-sync" checked={linkedinSyncEnabled} onCheckedChange={handleLinkedInSync} />
                </div>
                {linkedinSyncEnabled ? (
                  <div className="flex items-center space-x-2 text-sm text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span>Connected</span>
                  </div>
                ) : (
                  <Button
                    onClick={handleLinkedInSync}
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                  >
                    <Linkedin className="w-4 h-4 mr-2" />
                    Connect LinkedIn
                  </Button>
                )}
                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-update" className="text-sm">
                    Auto Update
                  </Label>
                  <Switch id="auto-update" checked={autoUpdateEnabled} onCheckedChange={setAutoUpdateEnabled} />
                </div>
              </CardContent>
            </Card>

            {/* AI Tools */}
            <Card className="glassmorphism bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border-purple-200 dark:border-purple-800">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center pulse-glow">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-purple-700 dark:text-purple-300">AI Assistant</CardTitle>
                    <CardDescription className="text-purple-600 dark:text-purple-400">
                      Smart resume optimization
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={generateAIResume}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  AI Optimize
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Improve Content
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  ATS Check
                </Button>
              </CardContent>
            </Card>

            {/* Export Options */}
            <Card className="glassmorphism bg-card/60">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Download className="w-5 h-5 mr-2 text-primary" />
                  Export Resume
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={() => exportResume("pdf")}
                  className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
                <Button onClick={() => exportResume("docx")} variant="outline" className="w-full bg-transparent">
                  <FileText className="w-4 h-4 mr-2" />
                  Download DOCX
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Link
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="builder" className="space-y-6">
              <TabsList className="glassmorphism bg-card/60">
                <TabsTrigger value="builder" className="flex items-center space-x-2">
                  <Edit className="w-4 h-4" />
                  <span>Builder</span>
                </TabsTrigger>
                <TabsTrigger value="templates" className="flex items-center space-x-2">
                  <FileText className="w-4 h-4" />
                  <span>Templates</span>
                </TabsTrigger>
                <TabsTrigger value="preview" className="flex items-center space-x-2">
                  <Eye className="w-4 h-4" />
                  <span>Preview</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="builder" className="space-y-6">
                {/* Personal Information */}
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <User className="w-5 h-5 mr-2 text-primary" />
                      Personal Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={resumeData.personalInfo.name}
                          onChange={(e) =>
                            setResumeData((prev) => ({
                              ...prev,
                              personalInfo: { ...prev.personalInfo, name: e.target.value },
                            }))
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={resumeData.personalInfo.email}
                          onChange={(e) =>
                            setResumeData((prev) => ({
                              ...prev,
                              personalInfo: { ...prev.personalInfo, email: e.target.value },
                            }))
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          value={resumeData.personalInfo.phone}
                          onChange={(e) =>
                            setResumeData((prev) => ({
                              ...prev,
                              personalInfo: { ...prev.personalInfo, phone: e.target.value },
                            }))
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="location">Location</Label>
                        <Input
                          id="location"
                          value={resumeData.personalInfo.location}
                          onChange={(e) =>
                            setResumeData((prev) => ({
                              ...prev,
                              personalInfo: { ...prev.personalInfo, location: e.target.value },
                            }))
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="linkedin">LinkedIn URL</Label>
                        <Input
                          id="linkedin"
                          value={resumeData.personalInfo.linkedinUrl}
                          onChange={(e) =>
                            setResumeData((prev) => ({
                              ...prev,
                              personalInfo: { ...prev.personalInfo, linkedinUrl: e.target.value },
                            }))
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="portfolio">Portfolio URL</Label>
                        <Input
                          id="portfolio"
                          value={resumeData.personalInfo.portfolioUrl}
                          onChange={(e) =>
                            setResumeData((prev) => ({
                              ...prev,
                              personalInfo: { ...prev.personalInfo, portfolioUrl: e.target.value },
                            }))
                          }
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="summary">Professional Summary</Label>
                      <Textarea
                        id="summary"
                        rows={4}
                        value={resumeData.personalInfo.summary}
                        onChange={(e) =>
                          setResumeData((prev) => ({
                            ...prev,
                            personalInfo: { ...prev.personalInfo, summary: e.target.value },
                          }))
                        }
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Education */}
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center">
                        <BookOpen className="w-5 h-5 mr-2 text-primary" />
                        Education
                      </CardTitle>
                      <Button size="sm" variant="outline" className="bg-transparent">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Education
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {resumeData.education.map((edu) => (
                      <div key={edu.id} className="p-4 border rounded-lg bg-background/50">
                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <Label>Institution</Label>
                            <Input
                              value={edu.institution}
                              onChange={(e) => {
                                const updatedEducation = resumeData.education.map((item) =>
                                  item.id === edu.id ? { ...item, institution: e.target.value } : item,
                                )
                                setResumeData((prev) => ({ ...prev, education: updatedEducation }))
                              }}
                            />
                          </div>
                          <div>
                            <Label>Degree</Label>
                            <Input
                              value={edu.degree}
                              onChange={(e) => {
                                const updatedEducation = resumeData.education.map((item) =>
                                  item.id === edu.id ? { ...item, degree: e.target.value } : item,
                                )
                                setResumeData((prev) => ({ ...prev, education: updatedEducation }))
                              }}
                            />
                          </div>
                          <div>
                            <Label>Field of Study</Label>
                            <Input
                              value={edu.field}
                              onChange={(e) => {
                                const updatedEducation = resumeData.education.map((item) =>
                                  item.id === edu.id ? { ...item, field: e.target.value } : item,
                                )
                                setResumeData((prev) => ({ ...prev, education: updatedEducation }))
                              }}
                            />
                          </div>
                          <div>
                            <Label>CGPA/Percentage</Label>
                            <Input
                              value={edu.cgpa}
                              onChange={(e) => {
                                const updatedEducation = resumeData.education.map((item) =>
                                  item.id === edu.id ? { ...item, cgpa: e.target.value } : item,
                                )
                                setResumeData((prev) => ({ ...prev, education: updatedEducation }))
                              }}
                            />
                          </div>
                          <div>
                            <Label>Start Date</Label>
                            <Input
                              value={edu.startDate}
                              onChange={(e) => {
                                const updatedEducation = resumeData.education.map((item) =>
                                  item.id === edu.id ? { ...item, startDate: e.target.value } : item,
                                )
                                setResumeData((prev) => ({ ...prev, education: updatedEducation }))
                              }}
                            />
                          </div>
                          <div>
                            <Label>End Date</Label>
                            <Input
                              value={edu.endDate}
                              onChange={(e) => {
                                const updatedEducation = resumeData.education.map((item) =>
                                  item.id === edu.id ? { ...item, endDate: e.target.value } : item,
                                )
                                setResumeData((prev) => ({ ...prev, education: updatedEducation }))
                              }}
                            />
                          </div>
                        </div>
                        <div>
                          <Label>Achievements</Label>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {edu.achievements.map((achievement, index) => (
                              <Badge key={index} variant="secondary">
                                {achievement}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex justify-end mt-4">
                          <Button size="sm" variant="ghost" className="text-red-500">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Skills */}
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Zap className="w-5 h-5 mr-2 text-primary" />
                      Skills
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Technical Skills</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {resumeData.skills.technical.map((skill, index) => (
                          <Badge key={index} variant="default">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label>Soft Skills</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {resumeData.skills.soft.map((skill, index) => (
                          <Badge key={index} variant="secondary">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label>Languages</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {resumeData.skills.languages.map((language, index) => (
                          <Badge key={index} variant="outline">
                            {language}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="templates" className="space-y-6">
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle>Choose a Template</CardTitle>
                    <CardDescription>
                      Select a professional template that matches your style and industry.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                      {templates.map((template) => (
                        <div
                          key={template.id}
                          className={`cursor-pointer rounded-lg border-2 p-4 transition-all ${
                            selectedTemplate === template.id
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/50"
                          }`}
                          onClick={() => setSelectedTemplate(template.id)}
                        >
                          <img
                            src={template.preview || "/placeholder.svg"}
                            alt={template.name}
                            className="w-full h-48 object-cover rounded-md mb-3"
                          />
                          <h3 className="font-medium text-center">{template.name}</h3>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="preview" className="space-y-6">
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle>Resume Preview</CardTitle>
                    <CardDescription>Preview how your resume will look to employers.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-white p-8 rounded-lg shadow-lg min-h-[800px]">
                      <div className="text-center mb-6">
                        <h1 className="text-3xl font-bold text-gray-900">{resumeData.personalInfo.name}</h1>
                        <p className="text-gray-600 mt-2">
                          {resumeData.personalInfo.email} | {resumeData.personalInfo.phone} |{" "}
                          {resumeData.personalInfo.location}
                        </p>
                        <p className="text-gray-600">
                          {resumeData.personalInfo.linkedinUrl} | {resumeData.personalInfo.portfolioUrl}
                        </p>
                      </div>

                      <div className="mb-6">
                        <h2 className="text-xl font-semibold text-gray-900 border-b-2 border-gray-300 pb-2 mb-3">
                          Professional Summary
                        </h2>
                        <p className="text-gray-700">{resumeData.personalInfo.summary}</p>
                      </div>

                      <div className="mb-6">
                        <h2 className="text-xl font-semibold text-gray-900 border-b-2 border-gray-300 pb-2 mb-3">
                          Education
                        </h2>
                        {resumeData.education.map((edu) => (
                          <div key={edu.id} className="mb-4">
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="font-semibold text-gray-900">
                                  {edu.degree} in {edu.field}
                                </h3>
                                <p className="text-gray-700">{edu.institution}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-gray-600">
                                  {edu.startDate} - {edu.endDate}
                                </p>
                                <p className="text-gray-600">CGPA: {edu.cgpa}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="mb-6">
                        <h2 className="text-xl font-semibold text-gray-900 border-b-2 border-gray-300 pb-2 mb-3">
                          Technical Skills
                        </h2>
                        <p className="text-gray-700">{resumeData.skills.technical.join(", ")}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
