"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  BookOpen,
  Trophy,
  Star,
  Target,
  Crown,
  Medal,
  Award,
  TrendingUp,
  Users,
  CheckCircle,
  Lock,
  Gift,
  Flame,
  Sparkles,
  Brain,
  Heart,
  Share2,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  category: "applications" | "community" | "learning" | "milestones"
  points: number
  rarity: "common" | "rare" | "epic" | "legendary"
  isUnlocked: boolean
  unlockedAt?: Date
  progress?: number
  maxProgress?: number
}

interface UserStats {
  totalPoints: number
  level: number
  rank: number
  streak: number
  totalApplications: number
  successfulApplications: number
  communityPosts: number
  helpfulAnswers: number
}

interface LeaderboardUser {
  id: string
  name: string
  avatar: string
  points: number
  level: number
  rank: number
  badge: string
}

export default function AchievementsPage() {
  const [activeTab, setActiveTab] = useState("overview")

  const [userStats, setUserStats] = useState<UserStats>({
    totalPoints: 2450,
    level: 12,
    rank: 156,
    streak: 7,
    totalApplications: 15,
    successfulApplications: 8,
    communityPosts: 23,
    helpfulAnswers: 12,
  })

  const [achievements, setAchievements] = useState<Achievement[]>([
    {
      id: "1",
      title: "First Steps",
      description: "Complete your first scholarship application",
      icon: "🎯",
      category: "applications",
      points: 100,
      rarity: "common",
      isUnlocked: true,
      unlockedAt: new Date("2025-01-05"),
    },
    {
      id: "2",
      title: "Application Master",
      description: "Submit 10 scholarship applications",
      icon: "📝",
      category: "applications",
      points: 500,
      rarity: "rare",
      isUnlocked: true,
      unlockedAt: new Date("2025-01-10"),
    },
    {
      id: "3",
      title: "Community Helper",
      description: "Help 5 students with their questions",
      icon: "🤝",
      category: "community",
      points: 300,
      rarity: "common",
      isUnlocked: true,
      unlockedAt: new Date("2025-01-08"),
    },
    {
      id: "4",
      title: "Scholarship Winner",
      description: "Win your first scholarship",
      icon: "🏆",
      category: "milestones",
      points: 1000,
      rarity: "epic",
      isUnlocked: true,
      unlockedAt: new Date("2025-01-12"),
    },
    {
      id: "5",
      title: "Knowledge Seeker",
      description: "Complete 20 learning modules",
      icon: "📚",
      category: "learning",
      points: 400,
      rarity: "rare",
      isUnlocked: false,
      progress: 12,
      maxProgress: 20,
    },
    {
      id: "6",
      title: "Streak Master",
      description: "Maintain a 30-day activity streak",
      icon: "🔥",
      category: "milestones",
      points: 750,
      rarity: "epic",
      isUnlocked: false,
      progress: 7,
      maxProgress: 30,
    },
    {
      id: "7",
      title: "Legend",
      description: "Reach the top 10 on the leaderboard",
      icon: "👑",
      category: "milestones",
      points: 2000,
      rarity: "legendary",
      isUnlocked: false,
      progress: 156,
      maxProgress: 10,
    },
  ])

  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([
    {
      id: "1",
      name: "Priya Sharma",
      avatar: "/avatars/priya.jpg",
      points: 5420,
      level: 18,
      rank: 1,
      badge: "Scholar Supreme",
    },
    {
      id: "2",
      name: "Rahul Kumar",
      avatar: "/avatars/rahul.jpg",
      points: 4890,
      level: 16,
      rank: 2,
      badge: "Application Expert",
    },
    {
      id: "3",
      name: "Ananya Patel",
      avatar: "/avatars/ananya.jpg",
      points: 4320,
      level: 15,
      rank: 3,
      badge: "Community Leader",
    },
    {
      id: "4",
      name: "Vikram Singh",
      avatar: "/avatars/vikram.jpg",
      points: 3890,
      level: 14,
      rank: 4,
      badge: "Rising Star",
    },
    {
      id: "5",
      name: "Sneha Reddy",
      avatar: "/avatars/sneha.jpg",
      points: 3450,
      level: 13,
      rank: 5,
      badge: "Knowledge Seeker",
    },
  ])

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common":
        return "text-gray-600 bg-gray-100 dark:bg-gray-900/20 border-gray-300"
      case "rare":
        return "text-blue-600 bg-blue-100 dark:bg-blue-900/20 border-blue-300"
      case "epic":
        return "text-purple-600 bg-purple-100 dark:bg-purple-900/20 border-purple-300"
      case "legendary":
        return "text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 border-yellow-300"
      default:
        return "text-gray-600 bg-gray-100 dark:bg-gray-900/20 border-gray-300"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "applications":
        return <Target className="w-4 h-4" />
      case "community":
        return <Users className="w-4 h-4" />
      case "learning":
        return <Brain className="w-4 h-4" />
      case "milestones":
        return <Trophy className="w-4 h-4" />
      default:
        return <Star className="w-4 h-4" />
    }
  }

  const getNextLevelPoints = () => {
    return (userStats.level + 1) * 250
  }

  const getCurrentLevelPoints = () => {
    return userStats.level * 250
  }

  const getProgressToNextLevel = () => {
    const currentLevelPoints = getCurrentLevelPoints()
    const nextLevelPoints = getNextLevelPoints()
    const pointsInCurrentLevel = userStats.totalPoints - currentLevelPoints
    const pointsNeededForLevel = nextLevelPoints - currentLevelPoints
    return (pointsInCurrentLevel / pointsNeededForLevel) * 100
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-cyan-50/30 dark:from-slate-900 dark:via-purple-900/20 dark:to-cyan-900/20">
      {/* Navigation */}
      <nav className="glassmorphism bg-card/60 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center pulse-glow">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">EduOpportunity</span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/dashboard" className="text-muted-foreground hover:text-primary transition-colors">
                Dashboard
              </Link>
              <Link href="/achievements" className="text-foreground hover:text-primary transition-colors font-medium">
                Achievements
              </Link>
            </div>

            <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg pulse-glow">
              <Link href="/dashboard">Dashboard</Link>
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Achievements & Progress</h1>
          <p className="text-muted-foreground">
            Track your journey, unlock achievements, and compete with fellow students.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar - User Stats & Level */}
          <div className="lg:col-span-1 space-y-6">
            {/* User Level Card */}
            <Card className="glassmorphism bg-gradient-to-br from-primary/10 to-purple-600/10 border-primary/20">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-purple-600 rounded-full flex items-center justify-center pulse-glow">
                    <Crown className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl">Level {userStats.level}</CardTitle>
                    <CardDescription className="text-primary font-medium">
                      {userStats.totalPoints.toLocaleString()} points
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Progress to Level {userStats.level + 1}</span>
                    <span>{Math.round(getProgressToNextLevel())}%</span>
                  </div>
                  <Progress value={getProgressToNextLevel()} className="h-3" />
                  <p className="text-xs text-muted-foreground mt-1">
                    {getNextLevelPoints() - userStats.totalPoints} points to next level
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-orange-600">#{userStats.rank}</div>
                    <div className="text-xs text-muted-foreground">Global Rank</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-red-600 flex items-center justify-center">
                      <Flame className="w-5 h-5 mr-1" />
                      {userStats.streak}
                    </div>
                    <div className="text-xs text-muted-foreground">Day Streak</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="glassmorphism bg-card/60">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-primary" />
                  Your Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Applications</span>
                  <span className="font-medium">{userStats.totalApplications}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Success Rate</span>
                  <span className="font-medium text-green-600">
                    {Math.round((userStats.successfulApplications / userStats.totalApplications) * 100)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Community Posts</span>
                  <span className="font-medium">{userStats.communityPosts}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Helpful Answers</span>
                  <span className="font-medium text-blue-600">{userStats.helpfulAnswers}</span>
                </div>
              </CardContent>
            </Card>

            {/* Recent Achievement */}
            <Card className="glassmorphism bg-card/60 border-yellow-500/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Sparkles className="w-5 h-5 mr-2 text-yellow-500" />
                  Latest Achievement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-3">
                  <div className="text-3xl">🏆</div>
                  <div>
                    <p className="font-medium">Scholarship Winner</p>
                    <p className="text-sm text-muted-foreground">+1000 points</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="glassmorphism bg-card/60">
                <TabsTrigger value="overview" className="flex items-center space-x-2">
                  <Trophy className="w-4 h-4" />
                  <span>Overview</span>
                </TabsTrigger>
                <TabsTrigger value="achievements" className="flex items-center space-x-2">
                  <Medal className="w-4 h-4" />
                  <span>Achievements</span>
                </TabsTrigger>
                <TabsTrigger value="leaderboard" className="flex items-center space-x-2">
                  <Crown className="w-4 h-4" />
                  <span>Leaderboard</span>
                </TabsTrigger>
                <TabsTrigger value="rewards" className="flex items-center space-x-2">
                  <Gift className="w-4 h-4" />
                  <span>Rewards</span>
                </TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                {/* Achievement Categories */}
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-105">
                    <CardContent className="p-4 text-center">
                      <Target className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                      <h3 className="font-semibold mb-1">Applications</h3>
                      <p className="text-2xl font-bold text-blue-600">
                        {achievements.filter((a) => a.category === "applications" && a.isUnlocked).length}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        /{achievements.filter((a) => a.category === "applications").length} unlocked
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-105">
                    <CardContent className="p-4 text-center">
                      <Users className="w-8 h-8 text-green-600 mx-auto mb-2" />
                      <h3 className="font-semibold mb-1">Community</h3>
                      <p className="text-2xl font-bold text-green-600">
                        {achievements.filter((a) => a.category === "community" && a.isUnlocked).length}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        /{achievements.filter((a) => a.category === "community").length} unlocked
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-105">
                    <CardContent className="p-4 text-center">
                      <Brain className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <h3 className="font-semibold mb-1">Learning</h3>
                      <p className="text-2xl font-bold text-purple-600">
                        {achievements.filter((a) => a.category === "learning" && a.isUnlocked).length}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        /{achievements.filter((a) => a.category === "learning").length} unlocked
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="glassmorphism bg-card/60 hover:shadow-xl transition-all duration-300 hover:scale-105">
                    <CardContent className="p-4 text-center">
                      <Trophy className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                      <h3 className="font-semibold mb-1">Milestones</h3>
                      <p className="text-2xl font-bold text-yellow-600">
                        {achievements.filter((a) => a.category === "milestones" && a.isUnlocked).length}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        /{achievements.filter((a) => a.category === "milestones").length} unlocked
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Recent Achievements */}
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Star className="w-5 h-5 mr-2 text-primary" />
                      Recent Achievements
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {achievements
                        .filter((a) => a.isUnlocked)
                        .sort((a, b) => (b.unlockedAt?.getTime() || 0) - (a.unlockedAt?.getTime() || 0))
                        .slice(0, 3)
                        .map((achievement) => (
                          <div key={achievement.id} className="flex items-center space-x-4 p-3 rounded-lg bg-muted/50">
                            <div className="text-3xl">{achievement.icon}</div>
                            <div className="flex-1">
                              <h4 className="font-semibold">{achievement.title}</h4>
                              <p className="text-sm text-muted-foreground">{achievement.description}</p>
                            </div>
                            <div className="text-right">
                              <Badge className={getRarityColor(achievement.rarity)}>{achievement.rarity}</Badge>
                              <p className="text-sm font-medium text-green-600 mt-1">+{achievement.points} pts</p>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Progress Tracking */}
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Target className="w-5 h-5 mr-2 text-primary" />
                      In Progress
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {achievements
                        .filter((a) => !a.isUnlocked && a.progress !== undefined)
                        .map((achievement) => (
                          <div key={achievement.id} className="p-4 rounded-lg border">
                            <div className="flex items-center space-x-4 mb-3">
                              <div className="text-2xl opacity-50">{achievement.icon}</div>
                              <div className="flex-1">
                                <h4 className="font-semibold">{achievement.title}</h4>
                                <p className="text-sm text-muted-foreground">{achievement.description}</p>
                              </div>
                              <Badge className={getRarityColor(achievement.rarity)}>{achievement.rarity}</Badge>
                            </div>
                            <div>
                              <div className="flex justify-between text-sm mb-1">
                                <span>Progress</span>
                                <span>
                                  {achievement.progress}/{achievement.maxProgress}
                                </span>
                              </div>
                              <Progress
                                value={((achievement.progress || 0) / (achievement.maxProgress || 1)) * 100}
                                className="h-2"
                              />
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* All Achievements Tab */}
              <TabsContent value="achievements" className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  {achievements.map((achievement) => (
                    <Card
                      key={achievement.id}
                      className={`glassmorphism transition-all duration-300 hover:scale-105 ${
                        achievement.isUnlocked ? "bg-card/60 hover:shadow-xl" : "bg-card/30 opacity-75"
                      }`}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className={`text-4xl ${!achievement.isUnlocked ? "grayscale opacity-50" : ""}`}>
                            {achievement.isUnlocked ? (
                              achievement.icon
                            ) : (
                              <Lock className="w-10 h-10 text-muted-foreground" />
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="font-semibold text-lg">{achievement.title}</h3>
                              {achievement.isUnlocked && <CheckCircle className="w-5 h-5 text-green-600" />}
                            </div>
                            <p className="text-muted-foreground mb-3">{achievement.description}</p>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <Badge className={getRarityColor(achievement.rarity)}>{achievement.rarity}</Badge>
                                <Badge variant="outline">
                                  {getCategoryIcon(achievement.category)}
                                  <span className="ml-1 capitalize">{achievement.category}</span>
                                </Badge>
                              </div>
                              <div className="text-right">
                                <p className="font-semibold text-primary">+{achievement.points} pts</p>
                                {achievement.unlockedAt && (
                                  <p className="text-xs text-muted-foreground">
                                    {achievement.unlockedAt.toLocaleDateString()}
                                  </p>
                                )}
                              </div>
                            </div>
                            {!achievement.isUnlocked && achievement.progress !== undefined && (
                              <div className="mt-3">
                                <div className="flex justify-between text-sm mb-1">
                                  <span>Progress</span>
                                  <span>
                                    {achievement.progress}/{achievement.maxProgress}
                                  </span>
                                </div>
                                <Progress
                                  value={((achievement.progress || 0) / (achievement.maxProgress || 1)) * 100}
                                  className="h-2"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Leaderboard Tab */}
              <TabsContent value="leaderboard" className="space-y-6">
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Crown className="w-5 h-5 mr-2 text-yellow-500" />
                      Global Leaderboard
                    </CardTitle>
                    <CardDescription>Top performers this month</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {leaderboard.map((user, index) => (
                        <div
                          key={user.id}
                          className={`flex items-center space-x-4 p-4 rounded-lg transition-all duration-300 hover:scale-105 ${
                            index < 3
                              ? "bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border border-yellow-200 dark:border-yellow-800"
                              : "bg-muted/50"
                          }`}
                        >
                          <div className="flex items-center space-x-3">
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                                index === 0
                                  ? "bg-yellow-500 text-white"
                                  : index === 1
                                    ? "bg-gray-400 text-white"
                                    : index === 2
                                      ? "bg-orange-500 text-white"
                                      : "bg-muted text-muted-foreground"
                              }`}
                            >
                              {index < 3 ? (
                                index === 0 ? (
                                  <Crown className="w-4 h-4" />
                                ) : index === 1 ? (
                                  <Medal className="w-4 h-4" />
                                ) : (
                                  <Award className="w-4 h-4" />
                                )
                              ) : (
                                user.rank
                              )}
                            </div>
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={user.avatar || "/placeholder.svg"} />
                              <AvatarFallback>
                                {user.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold">{user.name}</h4>
                            <p className="text-sm text-muted-foreground">{user.badge}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-primary">{user.points.toLocaleString()} pts</p>
                            <p className="text-sm text-muted-foreground">Level {user.level}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Your Position */}
                <Card className="glassmorphism bg-gradient-to-r from-primary/10 to-purple-600/10 border-primary/20">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                        #{userStats.rank}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">Your Position</h3>
                        <p className="text-muted-foreground">
                          You're ranked #{userStats.rank} globally with {userStats.totalPoints.toLocaleString()} points
                        </p>
                      </div>
                      <Button variant="outline" className="bg-transparent">
                        <Share2 className="w-4 h-4 mr-2" />
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Rewards Tab */}
              <TabsContent value="rewards" className="space-y-6">
                <Card className="glassmorphism bg-card/60">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Gift className="w-5 h-5 mr-2 text-primary" />
                      Available Rewards
                    </CardTitle>
                    <CardDescription>Redeem your points for exclusive rewards</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <Card className="border-2 border-dashed border-primary/30 hover:border-primary/60 transition-colors">
                        <CardContent className="p-4 text-center">
                          <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                            <BookOpen className="w-6 h-6 text-blue-600" />
                          </div>
                          <h4 className="font-semibold mb-2">Premium Course Access</h4>
                          <p className="text-sm text-muted-foreground mb-3">Unlock premium learning content</p>
                          <p className="font-bold text-blue-600 mb-3">1,000 points</p>
                          <Button size="sm" className="w-full">
                            Redeem
                          </Button>
                        </CardContent>
                      </Card>
                      <Card className="border-2 border-dashed border-green-300 hover:border-green-500 transition-colors">
                        <CardContent className="p-4 text-center">
                          <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                            <Heart className="w-6 h-6 text-green-600" />
                          </div>
                          <h4 className="font-semibold mb-2">1-on-1 Mentorship</h4>
                          <p className="text-sm text-muted-foreground mb-3">Personal guidance from experts</p>
                          <p className="font-bold text-green-600 mb-3">2,500 points</p>
                          <Button size="sm" variant="outline" className="w-full bg-transparent" disabled>
                            Not Enough Points
                          </Button>
                        </CardContent>
                      </Card>
                      <Card className="border-2 border-dashed border-purple-300 hover:border-purple-500 transition-colors">
                        <CardContent className="p-4 text-center">
                          <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                            <Trophy className="w-6 h-6 text-purple-600" />
                          </div>
                          <h4 className="font-semibold mb-2">Exclusive Badge</h4>
                          <p className="text-sm text-muted-foreground mb-3">Special profile badge</p>
                          <p className="font-bold text-purple-600 mb-3">500 points</p>
                          <Button size="sm" className="w-full">
                            Redeem
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
