"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Calendar, IndianRupee, ExternalLink, BookOpen, Users, Sparkles } from "lucide-react"
import Link from "next/link"

const scholarships = [
  // Featured Scholarships from Home Page
  {
    id: 1,
    title: "Merit-based Scholarship",
    provider: "Educational Institution",
    amount: "₹50,000",
    deadline: "2025-03-15",
    eligibility: ["All Years", "All Branches"],
    type: "Merit-based",
    description: "For students with CGPA > 8.0 demonstrating academic excellence.",
    link: "https://scholarships.gov.in/",
    tags: ["Merit", "Academic Excellence", "2025"],
    category: "Academic Excellence",
  },
  {
    id: 2,
    title: "Need-based Financial Aid",
    provider: "Educational Institution",
    amount: "₹75,000",
    deadline: "2025-04-10",
    eligibility: ["All Years", "All Branches"],
    type: "Need-based",
    description: "Financial support for students from families with income less than ₹3L annually.",
    link: "https://scholarships.gov.in/",
    tags: ["Need-based", "Financial Support", "2025"],
    category: "Financial Support",
  },
  {
    id: 3,
    title: "Research Excellence Grant",
    provider: "Research Foundation",
    amount: "₹1,00,000",
    deadline: "2025-05-20",
    eligibility: ["All Years", "All Branches"],
    type: "Research",
    description: "For students with research publications and innovative project work.",
    link: "https://scholarships.gov.in/",
    tags: ["Research", "Innovation", "Publications", "2025"],
    category: "Innovation",
  },

  // Government Scholarships
  {
    id: 4,
    title: "National Scholarship Portal (NSP)",
    provider: "Ministry of Education, Govt of India",
    amount: "₹12,000 - ₹2,00,000",
    deadline: "2025-03-31",
    eligibility: ["All Years", "All Branches"],
    type: "Government",
    description: "Comprehensive scholarship scheme for all categories with income-based eligibility criteria.",
    link: "https://scholarships.gov.in/",
    tags: ["Government", "Central", "All Categories", "2025"],
    category: "Central Government",
  },
  {
    id: 5,
    title: "AICTE Pragati Scholarship",
    provider: "All India Council for Technical Education",
    amount: "₹30,000/year",
    deadline: "2025-02-28",
    eligibility: ["All Years", "All Branches", "Girls"],
    type: "Government",
    description: "Scholarship for girl students pursuing technical education with family income less than ₹8L.",
    link: "https://www.aicte-india.org/",
    tags: ["AICTE", "Girls", "Technical", "2025"],
    category: "Women Empowerment",
  },
  {
    id: 6,
    title: "AICTE Saksham Scholarship",
    provider: "All India Council for Technical Education",
    amount: "₹50,000/year",
    deadline: "2025-02-28",
    eligibility: ["All Years", "All Branches", "Disabled"],
    type: "Government",
    description: "Support for differently abled students pursuing technical education.",
    link: "https://www.aicte-india.org/",
    tags: ["AICTE", "Disabled", "Technical", "2025"],
    category: "Disability Support",
  },
  {
    id: 7,
    title: "UGC Merit Scholarship",
    provider: "University Grants Commission",
    amount: "₹500/month",
    deadline: "2025-04-15",
    eligibility: ["All Years", "All Branches"],
    type: "Government",
    description: "For students who secured top 2% marks in Class XII examination.",
    link: "https://scholarships.gov.in/",
    tags: ["UGC", "Merit", "Class XII", "2025"],
    category: "Merit Based",
  },
  {
    id: 8,
    title: "INSPIRE Scholarship (DST)",
    provider: "Department of Science & Technology",
    amount: "₹80,000/year + ₹20,000 Mentorship",
    deadline: "2025-07-31",
    eligibility: ["All Years", "Science & Engineering"],
    type: "Government",
    description: "For top 1% students in Class XII Science pursuing higher education in natural and basic sciences.",
    link: "https://online-inspire.gov.in/",
    tags: ["DST", "Science", "Top 1%", "Mentorship", "2025"],
    category: "Science Excellence",
  },
  {
    id: 9,
    title: "Post Matric Scholarship SC/ST",
    provider: "Ministry of Social Justice & Empowerment",
    amount: "₹2,30,000/year",
    deadline: "2025-03-31",
    eligibility: ["All Years", "All Branches", "SC/ST"],
    type: "Government",
    description: "For SC/ST students with family income less than ₹2.5L pursuing higher education.",
    link: "https://scholarships.gov.in/",
    tags: ["Government", "SC/ST", "Social Welfare", "2025"],
    category: "Social Welfare",
  },
  {
    id: 10,
    title: "OBC Post Matric Scholarship",
    provider: "Ministry of Social Justice & Empowerment",
    amount: "₹1,60,000/year",
    deadline: "2025-03-31",
    eligibility: ["All Years", "All Branches", "OBC"],
    type: "Government",
    description: "For OBC students with family income less than ₹1L pursuing post-matriculation courses.",
    link: "https://scholarships.gov.in/",
    tags: ["Government", "OBC", "Social Welfare", "2025"],
    category: "Social Welfare",
  },
  {
    id: 11,
    title: "Minority Affairs Scholarship",
    provider: "Ministry of Minority Affairs",
    amount: "₹1,20,000/year",
    deadline: "2024-12-31",
    eligibility: ["All Years", "All Branches", "Minorities"],
    type: "Government",
    description: "For students belonging to minority communities pursuing higher education.",
    link: "https://scholarships.gov.in/",
    tags: ["Government", "Minorities", "Community", "2025"],
    category: "Minority Welfare",
  },
  {
    id: 12,
    title: "KVPY Fellowship",
    provider: "Department of Science & Technology",
    amount: "₹7,000/month + ₹28,000 Annual",
    deadline: "2025-09-15",
    eligibility: ["All Years", "Science & Engineering"],
    type: "Government",
    description: "For students with aptitude for research in basic sciences through national level examination.",
    link: "https://kvpy.iisc.ac.in/",
    tags: ["Government", "Research", "Fellowship", "Science", "2025"],
    category: "Research Excellence",
  },
  {
    id: 13,
    title: "Prime Minister's Scholarship",
    provider: "Ministry of Home Affairs",
    amount: "₹25,000/year",
    deadline: "2025-06-30",
    eligibility: ["All Years", "All Branches", "Armed Forces"],
    type: "Government",
    description:
      "For children and widows of armed forces personnel, central armed police forces and railway protection force.",
    link: "https://scholarships.gov.in/",
    tags: ["Government", "Armed Forces", "PM Scheme", "2025"],
    category: "Defense Personnel",
  },

  // Private Scholarships - Corporate
  {
    id: 14,
    title: "Tata Scholarship Program",
    provider: "Tata Trusts",
    amount: "₹2,00,000/year",
    deadline: "2025-05-31",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description:
      "For meritorious students from economically disadvantaged backgrounds with family income less than ₹4L.",
    link: "https://www.tatatrusts.org/",
    tags: ["Corporate", "Tata", "High Amount", "Merit", "2025"],
    category: "Corporate CSR",
  },
  {
    id: 15,
    title: "Reliance Foundation Scholarship",
    provider: "Reliance Foundation",
    amount: "₹2,00,000/year",
    deadline: "2025-04-30",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description:
      "For JEE Advanced qualified students with family income less than ₹6L pursuing undergraduate engineering.",
    link: "https://www.scholarships.reliancefoundation.org/",
    tags: ["Corporate", "Reliance", "JEE Advanced", "High Amount", "2025"],
    category: "Corporate CSR",
  },
  {
    id: 16,
    title: "Aditya Birla Scholarship",
    provider: "Aditya Birla Group",
    amount: "₹1,75,000/year",
    deadline: "2025-06-15",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description:
      "For top students from premier IITs and NITs demonstrating academic excellence and leadership potential.",
    link: "https://www.adityabirla.com/",
    tags: ["Corporate", "Aditya Birla", "IIT/NIT", "Leadership", "2025"],
    category: "Corporate CSR",
  },
  {
    id: 17,
    title: "Bajaj Auto Scholarship",
    provider: "Bajaj Auto Limited",
    amount: "₹1,50,000/year",
    deadline: "2025-03-15",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description: "Merit-based scholarship for engineering students demonstrating academic excellence and innovation.",
    link: "https://www.bajajauto.com/",
    tags: ["Corporate", "Bajaj", "Merit", "Innovation", "2025"],
    category: "Corporate CSR",
  },
  {
    id: 18,
    title: "L&T Build India Scholarship",
    provider: "Larsen & Toubro",
    amount: "₹1,50,000/year",
    deadline: "2025-07-31",
    eligibility: ["All Years", "Civil", "Mechanical"],
    type: "Private",
    description: "For students pursuing Civil and Mechanical Engineering with focus on infrastructure development.",
    link: "https://www.larsentoubro.com/",
    tags: ["Corporate", "L&T", "Infrastructure", "Civil/Mechanical", "2025"],
    category: "Industry Specific",
  },
  {
    id: 19,
    title: "Infosys Foundation Scholarship",
    provider: "Infosys Foundation",
    amount: "₹1,00,000/year",
    deadline: "2025-08-31",
    eligibility: ["All Years", "Computer Science", "IT"],
    type: "Private",
    description: "For Computer Science and IT students demonstrating excellence in technology and innovation.",
    link: "https://www.infosys.com/infosys-foundation/",
    tags: ["Corporate", "Infosys", "Technology", "CS/IT", "2025"],
    category: "Technology Focus",
  },
  {
    id: 20,
    title: "TCS Scholarship Program",
    provider: "Tata Consultancy Services",
    amount: "₹80,000/year",
    deadline: "2025-09-30",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description: "For engineering students across all branches with focus on academic excellence and leadership.",
    link: "https://www.tcs.com/",
    tags: ["Corporate", "TCS", "All Branches", "Leadership", "2025"],
    category: "Technology Focus",
  },
  {
    id: 21,
    title: "Wipro Scholarship",
    provider: "Wipro Limited",
    amount: "₹1,20,000/year",
    deadline: "2025-06-30",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description: "For STEM students demonstrating merit and financial need with focus on technology innovation.",
    link: "https://www.wipro.com/",
    tags: ["Corporate", "Wipro", "STEM", "Technology", "2025"],
    category: "Technology Focus",
  },
  {
    id: 22,
    title: "HDFC Bank Educational Crisis Scholarship",
    provider: "HDFC Bank",
    amount: "₹75,000/year",
    deadline: "2024-12-31",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description:
      "For students facing financial crisis due to unforeseen circumstances while maintaining academic merit.",
    link: "https://www.hdfcbank.com/",
    tags: ["Corporate", "HDFC", "Crisis Support", "Financial Aid", "2025"],
    category: "Financial Support",
  },
  {
    id: 23,
    title: "Mahindra Scholarship",
    provider: "Mahindra Group",
    amount: "₹2,00,000/year",
    deadline: "2025-05-15",
    eligibility: ["All Years", "Mechanical", "Automotive"],
    type: "Private",
    description: "For students pursuing Automotive and Mechanical Engineering with focus on sustainable mobility.",
    link: "https://www.mahindra.com/",
    tags: ["Corporate", "Mahindra", "Automotive", "Sustainability", "2025"],
    category: "Industry Specific",
  },

  // Private Scholarships - Foundations
  {
    id: 24,
    title: "Kishore Vaigyanik Protsahan Yojana",
    provider: "Indian Institute of Science",
    amount: "₹7,000/month",
    deadline: "2024-11-30",
    eligibility: ["All Years", "Science & Engineering"],
    type: "Private",
    description: "For students with aptitude for research in basic sciences through national level fellowship program.",
    link: "https://kvpy.iisc.ac.in/",
    tags: ["Research", "Science", "Fellowship", "IISc", "2025"],
    category: "Research Foundation",
  },
  {
    id: 25,
    title: "JN Tata Endowment Scholarship",
    provider: "JN Tata Endowment",
    amount: "Up to ₹10,00,000",
    deadline: "2025-03-31",
    eligibility: ["Final Year", "All Branches"],
    type: "Private",
    description: "For higher studies abroad in leading universities with focus on academic excellence and leadership.",
    link: "https://www.jntataendowment.org/",
    tags: ["International", "Higher Studies", "Abroad", "High Amount", "2025"],
    category: "International Studies",
  },
  {
    id: 26,
    title: "K.C. Mahindra Scholarship",
    provider: "K.C. Mahindra Education Trust",
    amount: "Up to ₹5,00,000",
    deadline: "2025-06-30",
    eligibility: ["Final Year", "All Branches"],
    type: "Private",
    description:
      "For post graduate studies abroad in top universities with emphasis on returning to contribute to India.",
    link: "https://www.kcmet.org/",
    tags: ["International", "Post Graduate", "Abroad", "Return to India", "2025"],
    category: "International Studies",
  },
  {
    id: 27,
    title: "Narotam Sekhsaria Foundation",
    provider: "Narotam Sekhsaria Foundation",
    amount: "₹2,00,000/year",
    deadline: "2025-04-15",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description:
      "Merit-based scholarship for engineering students demonstrating academic excellence and leadership potential.",
    link: "https://www.nsfoundation.co.in/",
    tags: ["Foundation", "Merit", "Leadership", "Excellence", "2025"],
    category: "Educational Foundation",
  },
  {
    id: 28,
    title: "Sitaram Jindal Foundation",
    provider: "Sitaram Jindal Foundation",
    amount: "₹48,000/year",
    deadline: "2025-07-31",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description: "For meritorious students across all engineering branches with focus on academic performance.",
    link: "https://www.jindalfoundation.org/",
    tags: ["Foundation", "Merit", "All Branches", "Academic", "2025"],
    category: "Educational Foundation",
  },
  {
    id: 29,
    title: "Ratan Tata Trust Scholarship",
    provider: "Ratan Tata Trust",
    amount: "₹2,00,000/year",
    deadline: "2025-05-31",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description: "For students pursuing higher education at Cornell University and other partner institutions.",
    link: "https://www.ratan-tata.com/",
    tags: ["Trust", "International", "Cornell", "Partnership", "2025"],
    category: "International Partnership",
  },
  {
    id: 30,
    title: "Inlaks Scholarship",
    provider: "Inlaks Shivdasani Foundation",
    amount: "Up to $1,00,000",
    deadline: "2025-01-31",
    eligibility: ["Final Year", "All Branches"],
    type: "Private",
    description: "For studies in USA and Europe at leading universities with focus on academic excellence.",
    link: "https://www.inlaksfoundation.org/",
    tags: ["International", "USA/Europe", "High Amount", "Excellence", "2025"],
    category: "International Studies",
  },
  {
    id: 31,
    title: "Azim Premji Foundation Scholarship",
    provider: "Azim Premji Foundation",
    amount: "₹1,20,000/year",
    deadline: "2025-06-15",
    eligibility: ["All Years", "All Branches"],
    type: "Private",
    description:
      "For students from rural backgrounds demonstrating academic merit and commitment to social development.",
    link: "https://azimpremjifoundation.org/",
    tags: ["Foundation", "Rural", "Social Impact", "Merit", "2025"],
    category: "Social Impact",
  },

  // Year-specific Scholarships
  {
    id: 32,
    title: "First Year Merit Scholarship",
    provider: "Educational Institution",
    amount: "₹25,000",
    deadline: "2024-10-31",
    eligibility: ["1st Year", "All Branches"],
    type: "Merit-based",
    description: "For first year students with JEE Main score above 95 percentile demonstrating academic excellence.",
    link: "https://scholarships.gov.in/",
    tags: ["First Year", "JEE Main", "Merit", "Excellence", "2025"],
    category: "First Year Only",
  },
  {
    id: 33,
    title: "Second Year Excellence Award",
    provider: "Educational Institution",
    amount: "₹40,000",
    deadline: "2025-08-31",
    eligibility: ["2nd Year", "All Branches"],
    type: "Merit-based",
    description:
      "For second year students with CGPA above 8.5 in first year demonstrating consistent academic performance.",
    link: "https://scholarships.gov.in/",
    tags: ["Second Year", "CGPA", "Excellence", "Performance", "2025"],
    category: "Second Year Only",
  },
  {
    id: 34,
    title: "Third Year Innovation Grant",
    provider: "Educational Institution",
    amount: "₹60,000",
    deadline: "2025-09-30",
    eligibility: ["3rd Year", "All Branches"],
    type: "Innovation",
    description: "For third year students with outstanding project work and research contributions in their field.",
    link: "https://scholarships.gov.in/",
    tags: ["Third Year", "Innovation", "Project", "Research", "2025"],
    category: "Third Year Only",
  },
  {
    id: 35,
    title: "Final Year Placement Support",
    provider: "Educational Institution",
    amount: "₹50,000",
    deadline: "2024-11-30",
    eligibility: ["Final Year", "All Branches"],
    type: "Career",
    description:
      "Support for final year students during job search and placement activities including skill development.",
    link: "https://scholarships.gov.in/",
    tags: ["Final Year", "Placement", "Career", "Skills", "2025"],
    category: "Final Year Only",
  },

  // Branch-specific Scholarships
  {
    id: 36,
    title: "Computer Science Excellence",
    provider: "Tech Industry Consortium",
    amount: "₹1,00,000/year",
    deadline: "2025-07-15",
    eligibility: ["All Years", "Computer Science", "IT"],
    type: "Branch Specific",
    description: "For CS/IT students demonstrating exceptional coding skills and software development capabilities.",
    link: "https://scholarships.gov.in/",
    tags: ["CS/IT", "Coding", "Software", "Excellence", "2025"],
    category: "Computer Science",
  },
  {
    id: 37,
    title: "Mechanical Engineering Innovation",
    provider: "Manufacturing Industry Association",
    amount: "₹80,000/year",
    deadline: "2025-08-15",
    eligibility: ["All Years", "Mechanical"],
    type: "Branch Specific",
    description: "For Mechanical Engineering students with innovative projects in manufacturing and design.",
    link: "https://scholarships.gov.in/",
    tags: ["Mechanical", "Manufacturing", "Innovation", "Design", "2025"],
    category: "Mechanical Engineering",
  },
  {
    id: 38,
    title: "Electrical Engineering Scholarship",
    provider: "Power Sector Consortium",
    amount: "₹75,000/year",
    deadline: "2025-09-15",
    eligibility: ["All Years", "Electrical", "Electronics"],
    type: "Branch Specific",
    description: "For Electrical/Electronics students focusing on power systems and renewable energy technologies.",
    link: "https://scholarships.gov.in/",
    tags: ["Electrical", "Electronics", "Power", "Renewable", "2025"],
    category: "Electrical Engineering",
  },
  {
    id: 39,
    title: "Civil Engineering Development",
    provider: "Infrastructure Development Council",
    amount: "₹70,000/year",
    deadline: "2025-06-30",
    eligibility: ["All Years", "Civil"],
    type: "Branch Specific",
    description: "For Civil Engineering students with focus on sustainable infrastructure and urban development.",
    link: "https://scholarships.gov.in/",
    tags: ["Civil", "Infrastructure", "Sustainable", "Urban", "2025"],
    category: "Civil Engineering",
  },
  {
    id: 40,
    title: "Chemical Engineering Research",
    provider: "Chemical Industry Foundation",
    amount: "₹85,000/year",
    deadline: "2025-07-31",
    eligibility: ["All Years", "Chemical"],
    type: "Branch Specific",
    description: "For Chemical Engineering students engaged in research and development in chemical processes.",
    link: "https://scholarships.gov.in/",
    tags: ["Chemical", "Research", "Process", "Development", "2025"],
    category: "Chemical Engineering",
  },

  // Latest 2025 Government Scholarships (keeping existing ones)
  {
    id: 41,
    title: "Central Sector Scheme of Scholarship for College and University Students 2025",
    provider: "Ministry of Education, Govt of India",
    amount: "₹12,000 - ₹20,000 per year",
    deadline: "2025-10-31",
    eligibility: ["All Years", "All Branches"],
    type: "Merit-based",
    description:
      "For meritorious students from economically weaker sections. ₹12,000 for first 3 years, ₹20,000 for 4th year of technical courses.",
    link: "https://scholarships.gov.in/",
    tags: ["Government", "Central", "Merit", "2025"],
    category: "National",
  },
  {
    id: 42,
    title: "PM-USP Special Scholarship Scheme for J&K & Ladakh 2025",
    provider: "Ministry of Education, Govt of India",
    amount: "₹1,25,000 tuition + ₹1,00,000 maintenance",
    deadline: "2025-09-30",
    eligibility: ["All Years", "All Branches", "J&K/Ladakh"],
    type: "Merit-based",
    description: "5000 fresh scholarships annually for students from Jammu & Kashmir and Ladakh pursuing engineering.",
    link: "https://scholarships.gov.in/",
    tags: ["Government", "J&K", "Ladakh", "High Amount", "2025"],
    category: "National",
  },
  {
    id: 43,
    title: "Prime Minister's Research Fellowship (PMRF) 2025",
    provider: "Ministry of Education",
    amount: "₹70,000 - ₹80,000 per month",
    deadline: "2025-12-31",
    eligibility: ["Final Year", "All Branches"],
    type: "Merit-based",
    description: "For pursuing PhD in IITs, IISc, and other premier institutions with enhanced fellowship amount.",
    link: "https://pmrf.in/",
    tags: ["Government", "Research", "PhD", "High Amount", "2025"],
    category: "Research",
  },
]

export default function ScholarshipsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedYear, setSelectedYear] = useState("all")
  const [selectedBranch, setSelectedBranch] = useState("all")
  const [selectedType, setSelectedType] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const filteredScholarships = useMemo(() => {
    return scholarships.filter((scholarship) => {
      const matchesSearch =
        scholarship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        scholarship.provider.toLowerCase().includes(searchTerm.toLowerCase()) ||
        scholarship.description.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesYear =
        selectedYear === "all" ||
        scholarship.eligibility.includes(selectedYear) ||
        scholarship.eligibility.includes("All Years")

      const matchesBranch =
        selectedBranch === "all" ||
        scholarship.eligibility.includes(selectedBranch) ||
        scholarship.eligibility.includes("All Branches")

      const matchesType = selectedType === "all" || scholarship.type === selectedType

      const matchesCategory = selectedCategory === "all" || scholarship.category === selectedCategory

      return matchesSearch && matchesYear && matchesBranch && matchesType && matchesCategory
    })
  }, [searchTerm, selectedYear, selectedBranch, selectedType, selectedCategory])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-purple-900">
      {/* Navigation */}
      <nav className="border-b bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  EduOpportunity
                </span>
              </Link>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 transition-colors">
                Home
              </Link>
              <Link
                href="/scholarships"
                className="text-gray-900 dark:text-white hover:text-blue-600 transition-colors font-medium"
              >
                Scholarships
              </Link>
              <Link
                href="/internships"
                className="text-gray-600 dark:text-gray-300 hover:text-blue-600 transition-colors"
              >
                Internships
              </Link>
              <Link
                href="/state-scholarships"
                className="text-gray-600 dark:text-gray-300 hover:text-blue-600 transition-colors"
              >
                State Scholarships
              </Link>
              <Link href="/about" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 transition-colors">
                About
              </Link>
            </div>

            <Button
              asChild
              variant="outline"
              className="border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
            >
              <Link href="/internships">Browse Internships</Link>
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <Badge className="mb-4 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 border-blue-200">
            <Sparkles className="w-4 h-4 mr-1" />
            Comprehensive Scholarship Database
          </Badge>
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
            Scholarships for B.Tech Students
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Discover {scholarships.length}+ scholarship opportunities from government, corporate, and international
            sources
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg border border-blue-200 p-6 mb-8 shadow-lg">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
            {/* Search */}
            <div className="lg:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-500 w-4 h-4" />
                <Input
                  placeholder="Search scholarships..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-blue-200 focus:border-blue-400"
                />
              </div>
            </div>

            {/* Year Filter */}
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="border-blue-200">
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Years</SelectItem>
                <SelectItem value="1st Year">1st Year</SelectItem>
                <SelectItem value="2nd Year">2nd Year</SelectItem>
                <SelectItem value="3rd Year">3rd Year</SelectItem>
                <SelectItem value="4th Year">4th Year</SelectItem>
                <SelectItem value="Final Year">Final Year</SelectItem>
              </SelectContent>
            </Select>

            {/* Branch Filter */}
            <Select value={selectedBranch} onValueChange={setSelectedBranch}>
              <SelectTrigger className="border-blue-200">
                <SelectValue placeholder="Branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                <SelectItem value="Computer Science">Computer Science</SelectItem>
                <SelectItem value="Mechanical">Mechanical</SelectItem>
                <SelectItem value="Electrical">Electrical</SelectItem>
                <SelectItem value="Civil">Civil</SelectItem>
                <SelectItem value="IT">Information Technology</SelectItem>
                <SelectItem value="Science & Engineering">Science & Engineering</SelectItem>
                <SelectItem value="Chemical">Chemical</SelectItem>
                <SelectItem value="Electronics">Electronics</SelectItem>
                <SelectItem value="Automotive">Automotive</SelectItem>
                <SelectItem value="Aerospace">Aerospace</SelectItem>
              </SelectContent>
            </Select>

            {/* Type Filter */}
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="border-blue-200">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Merit-based">Merit-based</SelectItem>
                <SelectItem value="Need-based">Need-based</SelectItem>
                <SelectItem value="Research">Research</SelectItem>
                <SelectItem value="Government">Government</SelectItem>
                <SelectItem value="Private">Private</SelectItem>
                <SelectItem value="Branch Specific">Branch Specific</SelectItem>
                <SelectItem value="Innovation">Innovation</SelectItem>
                <SelectItem value="Career">Career</SelectItem>
              </SelectContent>
            </Select>

            {/* Category Filter */}
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="border-blue-200">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="National">National</SelectItem>
                <SelectItem value="Corporate">Corporate</SelectItem>
                <SelectItem value="Technology">Technology</SelectItem>
                <SelectItem value="Research">Research</SelectItem>
                <SelectItem value="International">International</SelectItem>
                <SelectItem value="Diversity">Diversity</SelectItem>
                <SelectItem value="State">State</SelectItem>
                <SelectItem value="Corporate CSR">Corporate CSR</SelectItem>
                <SelectItem value="Educational Foundation">Educational Foundation</SelectItem>
                <SelectItem value="Social Impact">Social Impact</SelectItem>
                <SelectItem value="Women Empowerment">Women Empowerment</SelectItem>
                <SelectItem value="Financial Support">Financial Support</SelectItem>
                <SelectItem value="Academic Excellence">Academic Excellence</SelectItem>
                <SelectItem value="Innovation">Innovation</SelectItem>
                <SelectItem value="Industry Specific">Industry Specific</SelectItem>
                <SelectItem value="Technology Focus">Technology Focus</SelectItem>
                <SelectItem value="Computer Science">Computer Science</SelectItem>
                <SelectItem value="Mechanical Engineering">Mechanical Engineering</SelectItem>
                <SelectItem value="Electrical Engineering">Electrical Engineering</SelectItem>
                <SelectItem value="Civil Engineering">Civil Engineering</SelectItem>
                <SelectItem value="Chemical Engineering">Chemical Engineering</SelectItem>
                <SelectItem value="First Year Only">First Year Only</SelectItem>
                <SelectItem value="Second Year Only">Second Year Only</SelectItem>
                <SelectItem value="Third Year Only">Third Year Only</SelectItem>
                <SelectItem value="Final Year Only">Final Year Only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between mt-4 pt-4 border-t border-blue-200">
            <div className="text-sm text-gray-600 dark:text-gray-300">
              Showing {filteredScholarships.length} of {scholarships.length} scholarships
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSearchTerm("")
                setSelectedYear("all")
                setSelectedBranch("all")
                setSelectedType("all")
                setSelectedCategory("all")
              }}
              className="border-blue-300 text-blue-700 hover:bg-blue-50"
            >
              Clear Filters
            </Button>
          </div>
        </div>

        {/* Scholarship Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredScholarships.map((scholarship) => (
            <Card
              key={scholarship.id}
              className="hover:shadow-xl transition-all duration-300 hover:scale-105 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg"
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg mb-2 text-balance text-gray-900 dark:text-white">
                      {scholarship.title}
                    </CardTitle>
                    <CardDescription className="flex items-center text-sm mb-2 text-gray-600 dark:text-gray-300">
                      <Users className="w-4 h-4 mr-1" />
                      {scholarship.provider}
                    </CardDescription>
                  </div>
                  <Badge
                    variant={
                      scholarship.type === "Merit-based"
                        ? "default"
                        : scholarship.type === "Need-based"
                          ? "secondary"
                          : "outline"
                    }
                    className={
                      scholarship.type === "Merit-based"
                        ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                        : scholarship.type === "Need-based"
                          ? "bg-gradient-to-r from-green-500 to-teal-500 text-white"
                          : "bg-gradient-to-r from-orange-500 to-red-500 text-white"
                    }
                  >
                    {scholarship.type}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-4">
                  <p className="text-sm text-gray-600 dark:text-gray-300 text-pretty">{scholarship.description}</p>

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center text-green-600 font-semibold">
                      <IndianRupee className="w-4 h-4 mr-1" />
                      {scholarship.amount}
                    </div>
                    <div className="flex items-center text-orange-600">
                      <Calendar className="w-4 h-4 mr-1" />
                      {new Date(scholarship.deadline).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">Eligibility:</div>
                    <div className="flex flex-wrap gap-1">
                      {scholarship.eligibility.map((item, index) => (
                        <Badge key={index} variant="outline" className="text-xs border-blue-200 text-blue-700">
                          {item}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {scholarship.tags.map((tag, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="text-xs bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <Button
                    asChild
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    <a href={scholarship.link} target="_blank" rel="noopener noreferrer">
                      Apply Now
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredScholarships.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No scholarships found</h3>
            <p className="text-muted-foreground mb-4">
              Try adjusting your filters or search terms to find more opportunities.
            </p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchTerm("")
                setSelectedYear("all")
                setSelectedBranch("all")
                setSelectedType("all")
                setSelectedCategory("all")
              }}
            >
              Clear All Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
